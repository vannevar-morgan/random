LOLExec: Dynamic LOLCODE Interpreter
(c) 2008 Adrian "Sc4Freak" Tsai
Version 1.1

Contents
1. About
2. Usage
3. System Requirements
4. Performance
5. Implementation
6. Specification Ambiguities
7. Unsupported/Nonstandard Behaviour
8. Known Issues
9. Future Work
10. Known Issues


Changelog
----------------------------------------
1.1:
  - Breaking changes:
    - None. All code which worked with version 1.0 will work with 1.1.
  - Minor memory usage optimisations.
  - Minor compatibility changes to code.
  - Released source code under the GNU Lesser General Public License 2.1
  
1.0:
  - Initial Release.


[ 1 ] About
----------------------------------------
LOLExec is an interpreter for the LOLCODE programming language
(http://lolcode.com/) and is written in native C++. It is a full implementation
of the 1.2 specification of the language.


[ 2 ] Usage
----------------------------------------
Usage: lolexec Filename [switches]
Valid switches:
  -d        : Run in debug mode.
  -v or -vv : Run in verbose or more verbose mode.
  -tc       : Measure program compile time.
  -te       : Measure program execution time.
  
From Windows Explorer, you can also right-click on a LOLCODE code file, select
"Open With...", and browse for lolexec.exe. This will run the file in LOLExec.
You can also associate LOLCODE files (*.lol) with LOLExec so you can run them
by simply double-clicking on the file.


[ 3 ] System Requirements
----------------------------------------
Running the binary requires Windows XP or higher. Not tested with earlier
versions of Windows or any other platforms. Should run just fine under Wine,
though.


[ 4 ] Performance
----------------------------------------
LOLExec is a top-to-bottom solution written in C++. Everything from the
tokeniser, to the parser, to the compiler, and finally to the LOLCODE Virtual
Machine, is fully custom-written code.

However, it is currently in an unoptimised state. Development focus has been on
program correctness first, and performance was a secondary concern. From
internal testing, a program written in LOLCODE and executed in LOLExec has been
shown to be approximately 30 times slower than native compiled, optimised C++
code. See Section 9 for more information regarding future planned optimisations.


[ 5 ] Implementation
----------------------------------------
LOLExec strictly follows the 1.2 LOLCODE specification. Nonstandard behaviour is
documented in Section 7.

- Specification document:
  - http://lolcode.com/specs/1.2

- Language version:
  - Only version 1.2 of the specification is currently supported. If a value
    other than 1.2 is found after the HAI command, it is ignored and the program
    is parsed as per version 1.2 of the spec.
    
- Program correctness:
  - This implementation parses and compiles the program before executing it.
    This means that syntactic correctness is ensured before the program begins
    executing. Any syntax errors in the program will be flagged as soon as it
    starts, and not as the program executes.
  
- Whitespace:
  - Tabs (0x9) and space (0x20) characters are considered whitespace.
  - Windows newlines (CR+LF) are converted internally to newlines (LF)
  - Newlines (0xA) are statement delimiters, and are also considered whitespace.

- Scoping:
  - Variables are local to their enclosing block. Blocks are defined by loops
    (IM IN YR), switch cases (WTF?/OMG/OMGWTF), conditionals (O RLY?), and
    function definitions (HOW DUZ I). Once a block has closed, all enclosed
    variables go out of scope and are destroyed.
  - The implicit IT variable is local to the enclosing function. IT is
    initialised to an untyped value when a function is entered, and is local to
    that function. The value of the IT variable is not preserved across function
    calls, nor does modifying it from within a function modify the IT variable
    of the calling function.
    
- Loops:
  - This implementation follows strictly the rules in the 1.2 spec.
  - Loops declared only with "IM IN YR <label>" are infinite loops which must be
    broken with GTFO. Alternatively, it is also possible to return from a
    function from within a loop.
  - Iteration loops are of the form:
       IM IN YR <label> <operation> YR <variable> [TIL|WILE <expression>]
       
    The placement of the square brackets [] means that <operation> is not
    optional. This implementation follows this rule, and flags the following
    as invalid, as the operation is missing:
      IM IN YR LOOP TIL WIN
       ...
    
- Variable names:
  - Variables can contain the characters [A-Z], [a-z], [0-9] and the underscore
    (_). All other characters are invalid.
  - Variables cannot conflict with reserved language keywords except "IT".
  - Variable names must be unique within their enclosing and all parent scopes.
    Duplicate variable names are flagged as an error.

- Operators:
  - Math operators require the AN between arguments. The specification does
    not place square brackets around the AN, and thus for conformance the
    implementation will flag a missing AN as an error.
  - See the LOLCODE 1.2 specification document for more information.
  
- Functions:
  - Functions must be declared/defined at global scope. Nested functions are not
    allowed.
  - Function declarations can be placed in any order and anywhere in the
    program, so long as it is in global scope. This means that in this
    implementation, a function can be used before it is logically defined in a
    code file, and the parser will correctly find and execute the specified
    function. A consequence of this is that functions can have circular
    dependencies without the need for forward declarations.

- Implicit cast table:

                           SOURCE

          |  NOOB  | NUMBR  | NUMBAR | TROOF  |  YARN  |
   -------+--------+--------+--------+--------+--------+
   NOOB   |  N/A   | ERROR  | ERROR  | ERROR  | ERROR  |
T  -------+--------+--------+--------+--------+--------+
A  NUMBR  |   0    |  N/A   | NUMBAR | NUMBR  | NUMBR  |
R  -------+--------+--------+--------+--------+--------+
G  NUMBAR |  0.00  | NUMBAR |  N/A   | NUMBAR | NUMBAR |
E  -------+--------+--------+--------+--------+--------+
T  TROOF  |  FAIL  | TROOF  | TROOF  |  N/A   | TROOF  |
   -------+--------+--------+--------+--------+--------+
   YARN   |   ""   |  YARN  |  YARN  |  YARN  |  N/A   |
   -------+--------+--------+--------+--------+--------+

- Explicit casting logic:
  - NOOB -> NUMBR:   Numerical integer 0.
    NOOB -> NUMBAR:  Numerical floating-point 0.0.
    NOOB -> TROOF:   Boolean FAIL.
    NOOB -> YARN:    Empty string.

  - NUMBR -> NUMBAR: Converted into floating-point.
    NUMBR -> TROOF:  WIN if 0, FAIL otherwise.
    NUMBR -> YARN:   Converted into string representation.

  - NUMBAR -> NUMBR: Integer part taken, fraction part discarded.
    NUMBAR -> TROOF: FAIL if 0.00, WIN otherwise.
    NUMBAR -> YARN:  Converted into either exponential or decimal format with 2
                     decimal places, whichever is shorter.

  - TROOF -> NUMBR:  Numerical integer 1 if WIN, 0 if FAIL.
    TROOF -> NUMBAR: Numerical float 1.00 if WIN, 0.00 if FAIL.
    TROOF -> YARN:   "WIN" if WIN, "FAIL" if FAIL.

  - YARN -> NUMBR:   Converted to an integer representation. If invalid, throws
                     a runtime error.
    YARN -> NUMBAR:  Converted to a float representation. Either exponential
                     (eg. 1.20e6) or decimal format (eg. 13.5) is valid. If
                     invalid, throws a runtime error.
    YARN -> TROOF:   FAIL if string is empty, WIN otherwise.
    
- Implicit casting logic, binary math operators:
                 +
  Operand Types  | Behaviour
--------+--------+--------------------------------------------------------------
  NOOB  |  NOOB  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
  NOOB  | NUMBR  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
  NOOB  | NUMBAR | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
  NOOB  | TROOF  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
  NOOB  |  YARN  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
 NUMBR  | NUMBR  | Operation proceeds as NUMBRs.
--------+--------+--------------------------------------------------------------
 NUMBR  | NUMBAR | NUMBR is cast to NUMBAR. Operation proceeds as NUMBARs.
--------+--------+--------------------------------------------------------------
 NUMBR  | TROOF  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
 NUMBR  |  YARN  | If YARN contains a decimal point, both the YARN and the NUMBR
        |        | are cast into a NUMBARs and the operation proceeds as
        |        | NUMBARs. Otherwise, the YARN is cast into a NUMBR and the
        |        | operation proceeds as NUMBRs. If any cast from YARN should
        |        | fail, a runtime exception is thrown.
--------+--------+--------------------------------------------------------------
 NUMBAR | NUMBAR | Operation proceeds as NUMBARs.
--------+--------+--------------------------------------------------------------
 NUMBAR | TROOF  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
 NUMBAR |  YARN  | Attempt to cast YARN into NUMBAR. If successful, operation
        |        | proceeds as NUMBARs. Otherwise, runtime exception thrown.
--------+--------+--------------------------------------------------------------
 TROOF  | TROOF  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
 TROOF  |  YARN  | Runtime exception thrown.
--------+--------+--------------------------------------------------------------
 YARN   |  YARN  | If either or both strings contain a decimal point, they are
        |        | both cast to NUMBARs and the operation proceeds as NUMBARs.
        |        | Otherwise, they are both cast to NUMBRs and the operation
        |        | proceeds as NUMBRs. If any cast from YARN should fail, a
        |        | runtime exception is thrown.
--------+--------+--------------------------------------------------------------

- Implicit casting logic, binary comparison operators:
  - For binary comparison operators, no implicit casts are performed except for
    NUMBRs and NUMBARs, in which case NUMBARs take casting precedence.
                 +
  Operand Types  | Behaviour
--------+--------+--------------------------------------------------------------
  NOOB  |  NOOB  | Always equal.
--------+--------+--------------------------------------------------------------
  NOOB  | NUMBR  | Never equal.
--------+--------+--------------------------------------------------------------
  NOOB  | NUMBAR | Never equal.
--------+--------+--------------------------------------------------------------
  NOOB  | TROOF  | Never equal.
--------+--------+--------------------------------------------------------------
  NOOB  |  YARN  | Never equal.
--------+--------+--------------------------------------------------------------
 NUMBR  | NUMBR  | Integer comparison performed.
--------+--------+--------------------------------------------------------------
 NUMBR  | NUMBAR | NUMBR is cast to NUMBAR. Floating-point comparison performed.
--------+--------+--------------------------------------------------------------
 NUMBR  | TROOF  | Never equal.
--------+--------+--------------------------------------------------------------
 NUMBR  |  YARN  | Never equal.
--------+--------+--------------------------------------------------------------
 NUMBAR | NUMBAR | Floating-point comparison performed.
--------+--------+--------------------------------------------------------------
 NUMBAR | TROOF  | Never equal.
--------+--------+--------------------------------------------------------------
 NUMBAR |  YARN  | Never equal.
--------+--------+--------------------------------------------------------------
 TROOF  | TROOF  | Boolean comparison performed.
--------+--------+--------------------------------------------------------------
 TROOF  |  YARN  | Never equal.
--------+--------+--------------------------------------------------------------
 YARN   |  YARN  | String comparison performed.
--------+--------+--------------------------------------------------------------


[ 6 ] Specification Ambiguities
----------------------------------------
- The specification does not mention if conditionals should short circuit or
  not. In this implementation, comparison operators do not short circuit. This
  includes both binary and infinite arity operators.
  
- The specifciation does not mention what the initial type and value of a
  variable declared in an iteration loop is.
  For example:
      IM IN YR LOOP UPPIN YR VAR TIL BOTH SAEM VAR AN 5
      IM OUTTA YR LOOP
      
  The specification does not guarantee that VAR will be initialised to any
  particular variable when the loop is first entered. In this implmentation, VAR
  is initialised to type NUMBR and value 0.
  
- In parsing and executing switches (WTF?/OMG/OMGWTF), the specification does
  not mention if the default case (OMGWTF) must be placed at the end, after all
  case blocks (OMG). The order of blocks is important due to fall-through. This
  implementation requires that the OMGWTF block be placed at the end of the
  switch block. For example, the
  following is invalid:
      WTF?
        OMG 1
        OMGWTF
        OMG 2
      OIC

- The specification does not mention the semantics of where function
  declarations are valid. This implementation requires that all function
  declarations be placed at global scope. That is, nested function declarations
  (either from within a HAI block or a "HOW DUZ I" block) are invalid.
  
- The specification is not clear about whether HAI is a function or not.
  This implementation treats it similarly to a function, as it is effectively
  analogous to main() in C programs. As such, it is possible to return (FOUND
  YR <expression>) from HAI, which will immediately exit the program. The return
  value from HAI is ignored.
  

[ 7 ] Unsupported/Nonstandard Behaviour
----------------------------------------
- Unicode (of any sort) is unsupported. As a direct consequence, the following
  features are not supported:
    - Usage of Unicode ellipsis character (u2026) is not supported as a command
      joiner.
    - Usage of the ":(<hex>)" escape to convert the hex number into the
      corresponding Unicode code point is not supported.
    - Usage of the "[<char name>]" escape to resolve the char name to the
      corresponding Unicode normative name is not supported.
    - Any unicode characters in a code file are not supported, and their
      individual bytes will be interpreted as ANSI characters.


[ 8 ] Known Issues
----------------------------------------
- Custom unary functions as loop operations are not currently checked for
  correct parameter arguments. The implementation assumes implicitly that the
  function supplied takes only one argument. If not, the behaviour is currently
  undefined. This may be fixed in a future version.
  
  
[ 9 ] Future Work
----------------------------------------
- Performance:
  - Performance is now a primary concern, and future versions will look to
    significantly improve both compile-time and runtime performance.
  - The LOLExec compiler does not currently optimise code. Future plans include
    upgrading the LOLExec compiler into an optimising compiler.
    
- LOLCODE 1.3 Specification Conformance:
  - The 1.3 specification of LOLCODE is currently incomplete. Once it reaches
    draft stages, I will implement it in LOLExec.
    
- Backwards Compatibility (1.0 and 1.1 support):
  - There are currently no plans to support the old 1.0 and 1.1 versions of the
    language.
    

[ 10 ] Contact
----------------------------------------
Bugs? Comments? Suggestions? Email me at: adrian_tsai@microngamestudios.com

Feedback welcome!