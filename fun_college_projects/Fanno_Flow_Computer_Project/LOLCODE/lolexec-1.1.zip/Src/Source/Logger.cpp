// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Logger.h"
#include "TranslationUnit.h"
#include <iostream>
#include <boost/lexical_cast.hpp>

using boost::lexical_cast;

// Global logger object
CLogger Logger;

SDebugLogEntry::SDebugLogEntry(const CString& Message) : Message(Message)
{
    time_t t = time(NULL);
    TimeStamp = *localtime(&t);
    TimeStampString = asctime(&TimeStamp);
};

void CLogger::Log(const CString& Message)
{
    boost::mutex::scoped_lock Lock(AccessMutex);
    SDebugLogEntry e(Message);
    LogEntryArray.push_back(e);
    std::cout << e.TimeStampString << " - " << e.Message;
}

void CLogger::LogCompilerWarning(ECompileWarning Code, size_t Index, const TTranslationUnitPtr& TranslationUnit)
{
    SLocation Location = TranslationUnit->GetLocationFromIndex(Index);
    CString s = TranslationUnit->GetPath() + " (" + lexical_cast<CString>(Location.Row) + ',' +
        lexical_cast<CString>(Location.Column) + ") : warning C" + lexical_cast<CString>(Code) + ": " +
        GetCompileWarningDesc(Code);
    Log(s);
}
void CLogger::LogInfo(const CString& Message)
{
    Log(Message);
}