// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "Utils.h"
#include "RefCounted.h"

#include <boost/variant.hpp>
#include <boost/lexical_cast.hpp>

using boost::lexical_cast;

const char* GetRuntimeVarTypeDesc(ERuntimeVarType t);

enum EInstructionType
{
    InstructionType_Print,
    InstructionType_KeyboardInput,
    InstructionType_LoadVar,
    InstructionType_StoreVar,
    InstructionType_Pop,
    InstructionType_LoadInteger,
    InstructionType_LoadFloat,
    InstructionType_LoadBoolean,
    InstructionType_LoadString,
    InstructionType_LoadUntyped,
    InstructionType_Jump,
    InstructionType_JumpEqual,
    InstructionType_JumpNotEqual,
    InstructionType_Call,
    InstructionType_Return,
    InstructionType_Equals,
    InstructionType_NotEquals,
    InstructionType_Add,
    InstructionType_Subtract,
    InstructionType_Multiply,
    InstructionType_Divide,
    InstructionType_Modulus,
    InstructionType_Maximum,
    InstructionType_Minimum,
    InstructionType_Increment,
    InstructionType_Decrement,
    InstructionType_And,
    InstructionType_Or,
    InstructionType_Xor,
    InstructionType_Not,
    InstructionType_Cast,
    InstructionType_Concat,
    InstructionType_NoOp,
    InstructionTypeCount
};

class IInstruction : public IRefCounted
{
protected:
    EInstructionType Type;
    IInstruction(EInstructionType Type) : Type(Type) {}
    virtual ~IInstruction() {}

public:
    EInstructionType GetType() const {return Type;}

    virtual CString ToString() const = 0;
};

//////////////////////////////////////////////////////////////////////////
// Input/output

// Prints the operand on top of the stack, then pops it.
// Operand can be of any recognised type.
struct SPrintInstruction : public IInstruction
{
    SPrintInstruction() : IInstruction(InstructionType_Print) {}

    CString ToString() const {
        return "print";
    }
};

// Waits for keyboard input. Once the user enters data and presses [ENTER], the result is pushed onto the stack.
// The type is always string.
struct SKeyboardInputInstruction : public IInstruction
{
    SKeyboardInputInstruction() : IInstruction(InstructionType_KeyboardInput) {}

    CString ToString() const {
        return "read";
    }
};

//////////////////////////////////////////////////////////////////////////
// Load and store operations

// Loads a value from the specified address and pushes it onto the stack.
// Value can be of any recognised type.
struct SLoadVarInstruction : public IInstruction
{
    TVarIndex VarIndex;
    SLoadVarInstruction(TVarIndex VarIndex) : IInstruction(InstructionType_LoadVar),
        VarIndex(VarIndex) {}

    CString ToString() const {
        return "push [" + lexical_cast<CString>(VarIndex) + ']';
    }
};

// Stores a value from the stack into the specified address, then pops the stack.
// The previous value stored in the address is overwritten. Operand can be of any type.
struct SStoreVarInstruction : public IInstruction
{
    TVarIndex VarIndex;
    SStoreVarInstruction(TVarIndex VarIndex) : IInstruction(InstructionType_StoreVar),
        VarIndex(VarIndex) {}

    CString ToString() const {
        return "sto [" + lexical_cast<CString>(VarIndex) + ']';
    }
};

// Pops a value off the stack.
struct SPopInstruction : public IInstruction
{
    SPopInstruction() : IInstruction(InstructionType_Pop) {}

    CString ToString() const {
        return "pop";
    }
};

// Pushes an integer literal onto the stack.
// The resulting value has type Integer.
struct SLoadIntegerInstruction : public IInstruction
{
    int Value;
    SLoadIntegerInstruction(int Value) : IInstruction(InstructionType_LoadInteger), Value(Value) {}

    CString ToString() const {
        return "push " + lexical_cast<CString>(Value);
    }
};

// Pushes a floating-point literal onto the stack.
// The resulting value has type Float.
struct SLoadFloatInstruction : public IInstruction
{
    double Value;
    SLoadFloatInstruction(double Value) : IInstruction(InstructionType_LoadFloat), Value(Value) {}

    CString ToString() const {
        return "push " + lexical_cast<CString>(Value);
    }
};

// Pushes a boolean literal onto the stack.
// The resulting value has type Boolean.
struct SLoadBooleanInstruction : public IInstruction
{
    bool Value;
    SLoadBooleanInstruction(bool Value) : IInstruction(InstructionType_LoadBoolean), Value(Value) {}

    CString ToString() const {
        return "push " + lexical_cast<CString>(Value);
    }
};

// Pushes a string literal onto the stack.
// The resulting value has type String.
struct SLoadStringInstruction : public IInstruction
{
    CString Value;
    SLoadStringInstruction(const CString& Value) : IInstruction(InstructionType_LoadString), Value(Value) {}

    CString ToString() const {
        CString s = Value;
        FindAndReplaceAll("\n", "\\n", s);
        FindAndReplaceAll("\b", "\\b", s);
        return "push \"" + s + '\"';
    }
};

// Pushes an empty, untyped variable onto the stack.
// The resulting value has no type (untyped).
struct SLoadUntypedInstruction : public IInstruction
{
    SLoadUntypedInstruction() : IInstruction(InstructionType_LoadUntyped) {}

    CString ToString() const {
        return "push";
    }
};

//////////////////////////////////////////////////////////////////////////
// Flow control

// Unconditional, relative jump
struct SJumpInstruction : public IInstruction
{
protected:
    SJumpInstruction(EInstructionType InstructionType, TVarIndex Offset) : IInstruction(InstructionType),
        Offset(Offset) {}

public:
    int Offset;
    SJumpInstruction(int Offset) : IInstruction(InstructionType_Jump), Offset(Offset) {}

    virtual CString ToString() const {
        return "jmp " + lexical_cast<CString>(Offset);
    }
};
// Conditional, relative jump
// Jumps to the specified offset if the variable evaluates to TRUE. The variable must be of boolean type.
struct SJumpEqualInstruction : public SJumpInstruction
{
    SJumpEqualInstruction(int Offset) : SJumpInstruction(InstructionType_JumpEqual, Offset) {}

    CString ToString() const {
        return "je " + lexical_cast<CString>(Offset);
    }
};
// Conditional, relative jump
// Jumps to the specified offset if the variable evaluates to FALSE. The variable must be of boolean type.
struct SJumpNotEqualInstruction : public SJumpInstruction
{
    SJumpNotEqualInstruction(TVarIndex VarIndex) : SJumpInstruction(InstructionType_JumpNotEqual, Offset) {}

    CString ToString() const {
        return "jne " + lexical_cast<CString>(Offset);
    }
};
struct SCallInstruction : public SJumpInstruction
{
    size_t InitialStack;
    SCallInstruction(int Offset, size_t InitialStack) : SJumpInstruction(InstructionType_Call, Offset),
        InitialStack(InitialStack) {}

    CString ToString() const {
        return "call " + lexical_cast<CString>(Offset);
    }
};
struct SReturnInstruction : public IInstruction
{
    SReturnInstruction() : IInstruction(InstructionType_Return) {}

    CString ToString() const {
        return "ret";
    }
};

struct SEqualsInstruction : public IInstruction
{
    SEqualsInstruction() : IInstruction(InstructionType_Equals) {}

    CString ToString() const {
        return "eq";
    }
};
struct SNotEqualsInstruction : public IInstruction
{
    SNotEqualsInstruction() : IInstruction(InstructionType_NotEquals) {}

    CString ToString() const {
        return "neq";
    }
};


//////////////////////////////////////////////////////////////////////////
// Mathematical operators
struct SAddInstruction : public IInstruction
{
    SAddInstruction() : IInstruction(InstructionType_Add) {}

    CString ToString() const {
        return "add";
    }
};
struct SSubtractInstruction : public IInstruction
{
    SSubtractInstruction() : IInstruction(InstructionType_Subtract) {}

    CString ToString() const {
        return "sub";
    }
};
struct SMultiplyInstruction : public IInstruction
{
    SMultiplyInstruction() : IInstruction(InstructionType_Multiply) {}

    CString ToString() const {
        return "mul";
    }
};
struct SDivideInstruction : public IInstruction
{
    SDivideInstruction() : IInstruction(InstructionType_Divide) {}

    CString ToString() const {
        return "div";
    }
};
struct SModulusInstruction : public IInstruction
{
    SModulusInstruction() : IInstruction(InstructionType_Modulus) {}

    CString ToString() const {
        return "mod";
    }
};
struct SMinimumInstruction : public IInstruction
{
    SMinimumInstruction() : IInstruction(InstructionType_Minimum) {}

    CString ToString() const {
        return "min";
    }
};
struct SMaximumInstruction : public IInstruction
{
    SMaximumInstruction() : IInstruction(InstructionType_Maximum) {}

    CString ToString() const {
        return "max";
    }
};
struct SIncrementInstruction : public IInstruction
{
    SIncrementInstruction() : IInstruction(InstructionType_Increment) {}

    CString ToString() const {
        return "inc";
    }
};
struct SDecrementInstruction : public IInstruction
{
    SDecrementInstruction() : IInstruction(InstructionType_Decrement) {}

    CString ToString() const {
        return "dec";
    }
};

//////////////////////////////////////////////////////////////////////////
// Boolean logic operators
// For all boolean logic operators, their operands MUST be of boolean type.
struct SAndInstruction : public IInstruction
{
    SAndInstruction() : IInstruction(InstructionType_And) {}

    CString ToString() const {
        return "and";
    }
};
struct SOrInstruction : public IInstruction
{
    SOrInstruction() : IInstruction(InstructionType_Or) {}

    CString ToString() const {
        return "or";
    }
};
struct SXorInstruction : public IInstruction
{
    SXorInstruction() : IInstruction(InstructionType_Xor) {}

    CString ToString() const {
        return "xor";
    }
};
struct SNotInstruction : public IInstruction
{
    SNotInstruction() : IInstruction(InstructionType_Not) {}

    CString ToString() const {
        return "not";
    }
};

//////////////////////////////////////////////////////////////////////////
// Casts
struct SCastInstruction : public IInstruction
{
    ERuntimeVarType NewType;
    SCastInstruction(ERuntimeVarType NewType) : IInstruction(InstructionType_Cast), NewType(NewType) {}

    CString ToString() const {
        return CString("cast ") + GetRuntimeVarTypeDesc(NewType);
    }
};

//////////////////////////////////////////////////////////////////////////
// String concatenation
struct SConcatInstruction : public IInstruction
{
    SConcatInstruction() : IInstruction(InstructionType_Concat) {}

    CString ToString() const {
        return "concat";
    }
};

//////////////////////////////////////////////////////////////////////////
// No operation
struct SNoOpInstruction : public IInstruction
{
    SNoOpInstruction() : IInstruction(InstructionType_NoOp) {}

    CString ToString() const {
        return "nop";
    }
};
