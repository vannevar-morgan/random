// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "RefCounted.h"

class CTempVar;
class CBlock;

// All expressions, when emitting, guarantee that their return value will sit at the top of the stack once
// it returns.
class CExpression : public IEmittable, public IRefCounted
{
public:
    boost::intrusive_ptr<const CBlock> Parent;
    const TTranslationUnitPtr& TranslationUnit;
    size_t Index;

    CExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent);
    CExpression(const CExpression& x); // Copy constructor
    virtual ~CExpression();
};

// This expression simply represents a value.
class CValueExpression : public CExpression
{
public:
    SValue Value;

    CValueExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// Mathematical operators
class CAddExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CAddExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CSubtractExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CSubtractExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CMultiplyExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CMultiplyExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CDivideExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CDivideExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CModExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CModExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CMaxExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CMaxExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CMinExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CMinExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// Boolean operators
class CAndExpression : public CExpression
{
public:
    // Has variable arity
    CArray< boost::intrusive_ptr<CExpression> > Expressions;

    CAndExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class COrExpression : public CExpression
{
public:
    // Has variable arity
    CArray< boost::intrusive_ptr<CExpression> > Expressions;

    COrExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CXorExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CXorExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CNotExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> Arg;

    CNotExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// Comparison operators
class CEqualsExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CEqualsExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CNotEqualsExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> LHS;
    boost::intrusive_ptr<CExpression> RHS;

    CNotEqualsExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// String concatenation
class CConcatExpression : public CExpression
{
public:
    CArray< boost::intrusive_ptr<CExpression> > Expressions;

    CConcatExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// Cast
class CCastExpression : public CExpression
{
public:
    boost::intrusive_ptr<CExpression> Arg;
    CString TypeName;

    CCastExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CCastVarExpression : public CExpression
{
public:
    CString VarName;
    CString TypeName;

    CCastVarExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit,
        const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

class CFunctionCallExpression : public CExpression
{
public:
    CString FunctionName;
    CArray< boost::intrusive_ptr<CExpression> > Arguments;

    CFunctionCallExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CExpression(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};