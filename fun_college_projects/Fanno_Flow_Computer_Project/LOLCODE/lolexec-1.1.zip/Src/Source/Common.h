// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#ifdef WIN32
// This is to stop Windows.h from redefining std::min and std::max
#define NOMINMAX
#endif

#include "Array.inl"
#include "String.inl"

#include <boost/foreach.hpp>
#include <boost/intrusive_ptr.hpp>
#include <boost/shared_ptr.hpp>

#include <sstream>
#include <iomanip>

#define foreach BOOST_FOREACH

#ifdef _MSC_VER
#define FORCE_INLINE __forceinline
#else
#define FORCE_INLINE inline
#endif

typedef int TVarIndex;

static const TVarIndex InstructionPointerIndex = 0;
static const TVarIndex ITVarIndex = 1;

class CTranslationUnit;
typedef boost::shared_ptr<const CTranslationUnit> TTranslationUnitPtr;

struct SLocation
{
    int Column;
    int Row;
};

class SValue
{
public:
    bool IsStringLiteral;
    CString Data; // Could be a variable name, string literal, or a literal in string format

    SValue() : IsStringLiteral(false) {};
    SValue(bool IsStringLiteral, const CString& Data) : IsStringLiteral(IsStringLiteral), Data(Data)
    {}

    CString ToString() const {
        if(IsStringLiteral) return ('\"' + Data + '\"');
        return Data;
    }

    bool operator == (const SValue& rhs) const {
        return (IsStringLiteral == rhs.IsStringLiteral && Data == rhs.Data);
    }
};

class CEmitContext;
class IEmittable
{
public:
    virtual void Emit(CEmitContext& ec) const = 0;
};

enum ERuntimeVarType
{
    RuntimeVarType_Untyped,
    RuntimeVarType_Integer,
    RuntimeVarType_Float,
    RuntimeVarType_Boolean,
    RuntimeVarType_String,
    RuntimeVarTypeCount
};

static const char* Keywords[] = {
    "I",
    "HAS",
    "A",
    "ITZ",
    "OBTW",
    "TLDR",
    "HAI",
    "KTHXBYE",
    "NOOB",
    "NUMBR",
    "NUMBAR",
    "TROOF",
    "YARN",
    "BUKKIT",
    "WIN",
    "FAIL",
    "TYPE",
    "MKAY",
    "SUM",
    "DIFF",
    "PRODUKT",
    "QUOSHUNT",
    "MOD",
    "BIGGR",
    "SMALLR",
    "OF",
    "AN",
    "BOTH",
    "EITHER",
    "WON",
    "NOT",
    "ALL",
    "ANY",
    "SAEM",
    "DIFFRINT",
    "SMOOSH",
    "MAEK",
    "IS",
    "R",
    "VISIBLE",
    "GIMMEH",
    "IT",
    "O",
    "RLY?",
    "YA",
    "RLY",
    "NO",
    "WAI",
    "OIC",
    "WTF?",
    "OMG",
    "OMGWTF",
    "IM",
    "IN",
    "YR",
    "TIL",
    "WILE",
    "OUTTA",
    "HOW",
    "DUZ",
    "IF",
    "U",
    "SAY",
    "SO",
    "FOUND",
    "GTFO"
};
static const size_t KeywordCount = sizeof(Keywords) / sizeof(char*);

template <typename T>
inline CString ToString(T num, unsigned int Width = 0, char Fill = '0')
{
    std::ostringstream text;
    text << std::setw(Width) << std::setfill(Fill) << num;
    return text.str();
}