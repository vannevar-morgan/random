// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "Logger.h"
#include "TranslationUnit.h"

//////////////////////////////////////////////////////////////////////////
// Internal errors
class CException : public std::exception
{
protected:
    const char* Message;
    mutable CString FormattedMessage;

public:
    CException(){}
    CException(const char* Message);
    ~CException() throw() {}

    virtual const char* what() const throw();
};


//////////////////////////////////////////////////////////////////////////
// User input errors
class CArgumentException : public CException
{
public:
    CArgumentException() {}
    CArgumentException(const char* Message);
    ~CArgumentException() throw() {}
};


//////////////////////////////////////////////////////////////////////////
// Runtime execution errors
enum ERuntimeError
{
    RuntimeError_UntypedMathOp,
    RuntimeError_InvalidMathOpType,
    RuntimeError_BadCast,
    RuntimeError_InvalidInstruction,
    RuntimeErrorCount
};
const char* GetRuntimeErrorDesc(ERuntimeError Code);

class CRuntimeException : public CException
{
protected:
    ERuntimeError Code;

public:
    CRuntimeException(ERuntimeError Code);
    CRuntimeException(const char* Message, ERuntimeError Code);
    ~CRuntimeException() throw() {}

    ERuntimeError GetErrorCode() const;
    virtual const char* what() const throw();
};

class CInvalidInstructionException : public CRuntimeException
{
public:
    CInvalidInstructionException();
    CInvalidInstructionException(const char* Message);
    ~CInvalidInstructionException() throw() {}
};

//////////////////////////////////////////////////////////////////////////
// Compile errors

#include "CompileErrors.inl"

class CCompileException : public CException
{
protected:
    ECompileError Code;
    size_t Index;
    TTranslationUnitPtr TranslationUnit;
    SLocation Location;

public:
    CCompileException(ECompileError Code, size_t Index, const TTranslationUnitPtr& TranslationUnit);
    CCompileException(const char* Message, ECompileError Code, size_t Index,
        const TTranslationUnitPtr& TranslationUnit);
    ~CCompileException() throw() {}

    ECompileError GetErrorCode() const;
    const SLocation& GetLocation() const;
    size_t GetIndex() const;
    const TTranslationUnitPtr& GetTranslationUnit() const;

    virtual const char* what() const throw();
};

class CVariableNotFoundException : public CCompileException
{
private:
    CString VarName;

public:
    CVariableNotFoundException(const CString& VarName, size_t Index, const TTranslationUnitPtr& TranslationUnit)
        : CCompileException(CompileError_VariableNotFound, Index, TranslationUnit), VarName(VarName)
    {}
    ~CVariableNotFoundException() throw() {}

    virtual const char* what() const throw();
};

class CSyntaxException : public CCompileException
{
public:
    CSyntaxException(ECompileError Code, size_t Index, const TTranslationUnitPtr& TranslationUnit)
        : CCompileException(Code, Index, TranslationUnit)
    {}
    ~CSyntaxException() throw() {}

    virtual const char* what() const throw();
};

class CUnexpectedSyntaxException : public CSyntaxException
{
private:
    CString Unexpected;
    CString Expected;

public:
    CUnexpectedSyntaxException(const CString& Unexpected, size_t Index, const TTranslationUnitPtr& TranslationUnit)
        : CSyntaxException(CompileError_UnexpectedSyntax, Index, TranslationUnit), Unexpected(Unexpected)
    {}
    CUnexpectedSyntaxException(
        const CString& Unexpected,
        const CString& Expected,
        size_t Index,
        const TTranslationUnitPtr& TranslationUnit)
        : CSyntaxException(CompileError_UnexpectedSyntax, Index, TranslationUnit), Unexpected(Unexpected),
        Expected(Expected)
    {}
    ~CUnexpectedSyntaxException() throw() {}

    virtual const char* what() const throw();
};