// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Expression.h"
#include "Errors.h"
#include "Compiler.h"
#include "Block.h"

using boost::intrusive_ptr;

CExpression::CExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
    : TranslationUnit(TranslationUnit), Index(Index), Parent(Parent)
{
    assert(Parent != NULL);
}
CExpression::CExpression(const CExpression& x)
    : Parent(x.Parent), TranslationUnit(x.TranslationUnit), Index(x.Index)
{
    assert(Parent != NULL);
}

CExpression::~CExpression()
{}

void CValueExpression::Emit(CEmitContext& ec) const
{
    ERValueType Type = DetermineRValueType(Value);
    if(Type == RValueType_Variable)
    {
        size_t VarIndex = ec.GetVarIndex(Value.Data, Parent, Index, TranslationUnit);

        ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(VarIndex)));
        return;
    }
    else
    {
        switch(Type)
        {
        case RValueType_IntegerLiteral:
            {
                int v = ParseInteger(Value, Index, TranslationUnit);
                ec.AddInstruction(intrusive_ptr<SLoadIntegerInstruction>(new SLoadIntegerInstruction(v)));
            } break;
        case RValueType_FloatLiteral:
            {
                double v = ParseFloat(Value, Index, TranslationUnit);
                ec.AddInstruction(intrusive_ptr<SLoadFloatInstruction>(new SLoadFloatInstruction(v)));
            } break;
        case RValueType_BooleanLiteral:
            {
                bool v = ParseBool(Value, Index, TranslationUnit);
                ec.AddInstruction(intrusive_ptr<SLoadBooleanInstruction>(new SLoadBooleanInstruction(v)));
            } break;
        case RValueType_StringLiteral:
            {
                // This alternates between string literals and variable names
                // The first element is a string literal, the second is a variable name, then a string literal,
                // and so on. The last element is a string literal.
                CArray<CString> LiteralsAndVars;

                CString Arg(Value.Data.begin() + 1, Value.Data.end() - 1);
                while(true)
                {
                    size_t Start = Arg.find(":{");
                    if(Start == CString::npos) {
                        LiteralsAndVars.push_back(Arg);
                        break;
                    }
                    size_t End = Arg.find('}', Start);
                    if(End == CString::npos) {
                        Logger.LogCompilerWarning(CompileWarning_InvalidEscapeSequence, Index, TranslationUnit);
                        //throw CSyntaxException(CompileError_InvalidEscapeSequence, Index, TranslationUnit);
                        break;
                    }

                    LiteralsAndVars.push_back(Arg.substr(0, Start)); // String literal
                    LiteralsAndVars.push_back(Arg.substr(Start + 2, End - Start - 2)); // Variable name
                    Arg.erase(0, End + 1);
                }
                assert(!LiteralsAndVars.empty());

                // Push first literal
                {
                    SValue v = SValue(true, LiteralsAndVars[0]);
                    CString s = ParseString(v, Index, TranslationUnit);
                    ec.AddInstruction(intrusive_ptr<SLoadStringInstruction>(new SLoadStringInstruction(s)));
                }

                for(size_t i = 1 ; i < LiteralsAndVars.size() ; ++i)
                {
                    const CString& Str = LiteralsAndVars[i];
                    if(i % 2 == 0) // String literal
                    {
                        // Concatenate literal
                        SValue v = SValue(true, Str);
                        CString s = ParseString(v, Index, TranslationUnit);

                        // Push literal
                        ec.AddInstruction(intrusive_ptr<SLoadStringInstruction>(new SLoadStringInstruction(s)));

                        // Concatenate
                        ec.AddInstruction(intrusive_ptr<SConcatInstruction>(new SConcatInstruction()));
                    }
                    else // Variable name
                    {
                        size_t VarIndex = ec.GetVarIndex(Str, Parent, Index, TranslationUnit);

                        // Push the variable
                        ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(VarIndex)));

                        // Cast
                        ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_String)));

                        // Concatenate
                        ec.AddInstruction(intrusive_ptr<SConcatInstruction>(new SConcatInstruction()));
                    }
                }
            } break;
        }
    }
}

void CAddExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SAddInstruction>(new SAddInstruction()));
}

void CSubtractExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SSubtractInstruction>(new SSubtractInstruction()));
}

void CMultiplyExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SMultiplyInstruction>(new SMultiplyInstruction()));
}

void CDivideExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SDivideInstruction>(new SDivideInstruction()));
}

void CModExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SModulusInstruction>(new SModulusInstruction()));
}

void CMaxExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SMaximumInstruction>(new SMaximumInstruction()));
}

void CMinExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SMinimumInstruction>(new SMinimumInstruction()));
}

void CAndExpression::Emit(CEmitContext& ec) const
{
    typedef CArray< boost::intrusive_ptr<CExpression> > TExprContainer;
    assert(Expressions.size() >= 2);

    // Evaluate the first expression
    Expressions[0]->Emit(ec);

    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
    TExprContainer::const_iterator End = Expressions.end();
    for(TExprContainer::const_iterator it = Expressions.begin() + 1 ; it != End ; ++it)
    {
        (*it)->Emit(ec);
        ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
        ec.AddInstruction(intrusive_ptr<SAndInstruction>(new SAndInstruction()));
    }
}

void COrExpression::Emit(CEmitContext& ec) const
{
    typedef CArray< boost::intrusive_ptr<CExpression> > TExprContainer;
    assert(Expressions.size() >= 2);

    // Evaluate the first expression
    Expressions[0]->Emit(ec);

    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
    TExprContainer::const_iterator End = Expressions.end();
    for(TExprContainer::const_iterator it = Expressions.begin() + 1 ; it != End ; ++it)
    {
        (*it)->Emit(ec);
        ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
        ec.AddInstruction(intrusive_ptr<SOrInstruction>(new SOrInstruction()));
    }
}

void CXorExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
    ec.AddInstruction(intrusive_ptr<SXorInstruction>(new SXorInstruction()));
}

void CNotExpression::Emit(CEmitContext& ec) const
{
    Arg->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));
    ec.AddInstruction(intrusive_ptr<SNotInstruction>(new SNotInstruction()));
}

void CEqualsExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SEqualsInstruction>(new SEqualsInstruction()));
}

void CNotEqualsExpression::Emit(CEmitContext& ec) const
{
    LHS->Emit(ec);
    RHS->Emit(ec);
    ec.AddInstruction(intrusive_ptr<SNotEqualsInstruction>(new SNotEqualsInstruction()));
}

void CConcatExpression::Emit(CEmitContext& ec) const
{
    assert(Expressions.size() >= 2);

    // Evaluate the first expression
    Expressions[0]->Emit(ec);

    // Cast to a string
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_String)));

    typedef CArray< intrusive_ptr<CExpression> > TExpressionCont;
    TExpressionCont::const_iterator End = Expressions.end();
    for(TExpressionCont::const_iterator it = Expressions.begin() + 1 ; it != End ; ++it)
    {
        // Evaluate
        (*it)->Emit(ec);

        // Cast to a string
        ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_String)));

        // Concatenate
        ec.AddInstruction(intrusive_ptr<SConcatInstruction>(new SConcatInstruction()));
    }
}

void CCastExpression::Emit(CEmitContext& ec) const
{
    Arg->Emit(ec);

    ERuntimeVarType Type = GetRuntimeVarType(TypeName, Index, TranslationUnit);
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(Type)));
}

void CCastVarExpression::Emit(CEmitContext& ec) const
{
    size_t VarIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);

    // Push onto stack
    ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(VarIndex)));

    // Cast
    ERuntimeVarType Type = GetRuntimeVarType(TypeName, Index, TranslationUnit);
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(Type)));

    // Store into var
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(VarIndex)));
}

void CFunctionCallExpression::Emit(CEmitContext& ec) const
{
    // Clear a space for the return value
    ec.AddInstruction(intrusive_ptr<SLoadUntypedInstruction>(new SLoadUntypedInstruction()));

    // Push all arguments onto the stack in LEFT TO RIGHT order
    foreach(const boost::intrusive_ptr<CExpression>& Expr, Arguments)
    {
        Expr->Emit(ec);
    }

    // Call function
    intrusive_ptr<SCallInstruction> CallInstr(new SCallInstruction(0,0));
    ec.RegisterCallContext(ec.GetInstructionCount(), CallInstr, FunctionName, Index, TranslationUnit);
    ec.AddInstruction(CallInstr);

    // It's the callee's responsibility to cleanup after itself, but since we're the ones who pushed the
    // arguments onto the stack, it's our responsibility to clean those up.
    size_t NumArgs = Arguments.size();
    for(size_t i = 0 ; i < NumArgs ; ++i)
    {
        ec.AddInstruction(intrusive_ptr<SPopInstruction>(new SPopInstruction()));
    }
}