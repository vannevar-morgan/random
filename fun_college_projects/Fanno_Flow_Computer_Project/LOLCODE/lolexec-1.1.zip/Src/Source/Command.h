// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
//

#pragma once

#include "Common.h"
#include "ProgramElement.h"

// "Command" is analogous to "expression" in standard nomenclature. But the LOLCODE spec seems to use the 
// term "command" here and there in exchange for "expression"
class CCommand : public CStatement
{
public:
    boost::shared_ptr<CBlock> Parent;

    CCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CStatement(Index, TranslationUnit), Parent(Parent) {}

    virtual CString ToString() const = 0;
};

class CVisibleCommand : public CCommand
{
public:
    CArray<SValue> Arguments;

    CVisibleCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CCommand(Index, TranslationUnit, Parent) {}

    CString ToString() const {
        CString s = "VISIBLE";
        foreach(const SValue& v, Arguments)
            s += ", " + v.ToString();
        return s;
    }

    void Emit(CEmitContext& ec) const;
};

class CImportCommand : public CCommand
{
public:
    CString Argument;

    CImportCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CCommand(Index, TranslationUnit, Parent) {}

    CString ToString() const {return "CAN HAS, " + Argument;}

    void Emit(CEmitContext& ec) const;
};

class CDeclareVarCommand : public CCommand
{
public:
    CString VarName;
    SValue InitialValue;

    CDeclareVarCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CCommand(Index, TranslationUnit, Parent) {}

    CString ToString() const {
        CString s = "VAR " + VarName;
        if(!InitialValue.Data.empty() || InitialValue.IsStringLiteral)
            s += " = " + InitialValue.ToString();
        return s;
    }

    void Emit(CEmitContext& ec) const;
    void ResolveVars(TBlockVarMap& VarMap, const boost::shared_ptr<const CBlock>& Parent, size_t& CurrentIndex) const;
};

class CAssignVarCommand : public CCommand
{
public:
    CString VarName;
    SValue Value;

    CAssignVarCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CCommand(Index, TranslationUnit, Parent) {}

    CString ToString() const {
        return VarName + " = " + Value.ToString();
    }

    void Emit(CEmitContext& ec) const;
};

// Comparison for sameness, not assignment
class CEqualsCommand : public CCommand
{
public:
    SValue LHS;
    SValue RHS;

    CEqualsCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CCommand(Index, TranslationUnit, Parent) {}

    CString ToString() const {
        return LHS.ToString() + " == " + RHS.ToString();
    }

    void Emit(CEmitContext& ec) const;
};
class CNotEqualsCommand : public CCommand
{
public:
    SValue LHS;
    SValue RHS;

    CNotEqualsCommand(size_t Index, const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent)
        : CCommand(Index, TranslationUnit, Parent) {}

    CString ToString() const {
        return LHS.ToString() + " != " + RHS.ToString();
    }

    void Emit(CEmitContext& ec) const;
};