// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"

#ifdef _MSC_VER
// cstdint isn't shipped with MSVC for some reason
typedef __int64 int64_t;
#else
#include <stdint.h>
#endif

class ITimerBase
{
public:
    virtual void Start() = 0;
    virtual void End() = 0;

    virtual double ToSeconds() const = 0;
    virtual double ToMilliseconds() const = 0;
    virtual double ToMicroseconds() const = 0;
    virtual int64_t ToNanoseconds() const = 0;

    virtual CString ToString() const = 0;
};

#ifdef WIN32

#include <Windows.h>

// High resolution timer, only available under Windows
class CTimer : public ITimerBase
{
private:
    LARGE_INTEGER TimerClocksPerSecond;
    LARGE_INTEGER StartCounter;
    LARGE_INTEGER EndCounter;

public:
    CTimer();

    void Start();
    void End();

    double ToSeconds() const;
    double ToMilliseconds() const;
    double ToMicroseconds() const;
    int64_t ToNanoseconds() const;

    CString ToString() const;
};

#else // WIN32

#include <ctime>

// Standard timer
class CTimer : public ITimerBase
{
private:
    clock_t StartCounter;
    clock_t EndCounter;

public:
    void Start();
    void End();

    double ToSeconds() const;
    double ToMilliseconds() const;
    double ToMicroseconds() const;
    int64_t ToNanoseconds() const;

    CString ToString() const;
};

#endif // WIN32