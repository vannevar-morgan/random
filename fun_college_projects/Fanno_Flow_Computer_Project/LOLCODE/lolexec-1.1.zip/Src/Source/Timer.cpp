// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Timer.h"
#include "Errors.h"

#include <boost/lexical_cast.hpp>
#include <iomanip>

using boost::lexical_cast;

#ifdef WIN32

CTimer::CTimer()
{
    BOOL Status = QueryPerformanceFrequency(&TimerClocksPerSecond);

    if(!Status)
        throw CException("Failed to initialise timer.");
}

void CTimer::Start()
{
    BOOL Status = QueryPerformanceCounter(&StartCounter);

    if(!Status)
        throw CException("Failed to start timer.");

}
void CTimer::End()
{
    BOOL Status = QueryPerformanceCounter(&EndCounter);

    if(!Status)
        throw CException("Failed to end timer.");

}

double CTimer::ToSeconds() const
{
    return static_cast<double>(ToNanoseconds()) / 1e9;
}
double CTimer::ToMilliseconds() const
{
    return static_cast<double>(ToNanoseconds()) / 1e6;
}
double CTimer::ToMicroseconds() const
{
    return static_cast<double>(ToNanoseconds()) / 1e3;
}
int64_t CTimer::ToNanoseconds() const
{
    int64_t TimeRaw = EndCounter.QuadPart - StartCounter.QuadPart;
    return static_cast<INT64>(TimeRaw * 1e9 / TimerClocksPerSecond.QuadPart);
}

CString DoubleToString(double x)
{
    using namespace std;
    ostringstream text;
    text << fixed << showpoint << setprecision(3) << x;
    return text.str();
}

CString CTimer::ToString() const
{
    int64_t Nanoseconds = ToNanoseconds();
    if(Nanoseconds < 1000)
        return lexical_cast<CString>(Nanoseconds) + "ns";
    else if(Nanoseconds < 1000000)
        return DoubleToString(ToMicroseconds()) + "us";
    else if(Nanoseconds < 1000000000)
        return DoubleToString(ToMilliseconds()) + "ms";
    else
        return DoubleToString(ToSeconds()) + "s";
}

#else // WIN32

void CTimer::Start()
{
    StartCounter = clock();

}
void CTimer::End()
{
    EndCounter = clock();
}

double CTimer::ToSeconds() const
{
    return static_cast<double>(ToNanoseconds()) / 1e9;
}
double CTimer::ToMilliseconds() const
{
    return static_cast<double>(ToNanoseconds()) / 1e6;
}
double CTimer::ToMicroseconds() const
{
    return static_cast<double>(ToNanoseconds()) / 1e3;
}
int64_t CTimer::ToNanoseconds() const
{
    clock_t Diff = EndCounter - StartCounter;
    return static_cast<int64_t>(Diff * 1e9 / CLOCKS_PER_SEC);
}

CString DoubleToString(double x)
{
    using namespace std;
    ostringstream text;
    text << fixed << showpoint << setprecision(3) << x;
    return text.str();
}

CString CTimer::ToString() const
{
    int64_t Nanoseconds = ToNanoseconds();
    if(Nanoseconds < 1000)
        return lexical_cast<CString>(Nanoseconds) + "ns";
    else if(Nanoseconds < 1000000)
        return DoubleToString(ToMicroseconds()) + "us";
    else if(Nanoseconds < 1000000000)
        return DoubleToString(ToMilliseconds()) + "ms";
    else
        return DoubleToString(ToSeconds()) + "s";
}

#endif // WIN32
