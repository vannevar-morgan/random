// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "IfStatement.h"
#include "Errors.h"
#include "Compiler.h"
#include "Expression.h"

void CIfStatement::Emit(CEmitContext& ec) const
{
    using boost::intrusive_ptr;
    typedef std::pair< size_t, intrusive_ptr<SJumpInstruction> > TJumpToEndInstr;

    // The first element of the pair holds the instruction index, the second hold a pointer to the instruction itself
    CArray<TJumpToEndInstr> JumpToEndInstructions;

    // Push the implicit "IT" variable, and cast that to a bool.
    ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(ITVarIndex)));
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));

    // Add the jump instruction to the instruction stream, with an offset of 0. Even though this offset is wrong,
    // we can't set it right now because we don't know how far to jump (yet). The offset will be set later once
    // the TrueBlock has been emitted.
    intrusive_ptr<SJumpNotEqualInstruction> JumpInstr(new SJumpNotEqualInstruction(0));
    ec.AddInstruction(JumpInstr);

    // Record current instruction count (so we know how far to jump to get past the true block)
    size_t InstrCount = ec.GetInstructionCount();

    // Emit true block
    TrueBlock->Emit(ec);

    // Add an instruction to jump to end (if required)
    if(!ElseIfBlocks.empty() || FalseBlock != NULL)
    {
        intrusive_ptr<SJumpInstruction> JumpToEnd(new SJumpInstruction(0));
        JumpToEndInstructions.push_back(std::make_pair(ec.GetInstructionCount(), JumpToEnd));
        ec.AddInstruction(JumpToEnd);
    }

    // Set the jump instruction's offset
    size_t TrueBlockInstrCount = ec.GetInstructionCount() - InstrCount;
    JumpInstr->Offset = static_cast<int>(TrueBlockInstrCount + 1);
    
    // Emit all the else if blocks
    foreach(const intrusive_ptr<CElseIfBlock>& e, ElseIfBlocks)
    {
        e->Emit(ec);

        // Add an instruction to jump to end
        intrusive_ptr<SJumpInstruction> JumpToEnd(new SJumpInstruction(0));
        JumpToEndInstructions.push_back(std::make_pair(ec.GetInstructionCount(), JumpToEnd));
        ec.AddInstruction(JumpToEnd);
    }

    // Emit false block if it exists
    if(FalseBlock != NULL)
        FalseBlock->Emit(ec);

    // Update all those "jump to end" instructions
    InstrCount = ec.GetInstructionCount();
    foreach(const TJumpToEndInstr& i, JumpToEndInstructions)
    {
        i.second->Offset = static_cast<int>(InstrCount - i.first);
    }
}
void CIfStatement::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    TrueBlock->ResolveVars(VarMap, CurrentIndex);
    foreach(const boost::intrusive_ptr<CElseIfBlock>& e, ElseIfBlocks)
    {
        e->ResolveVars(VarMap, CurrentIndex);
    }
    if(FalseBlock != NULL) // False block can be NULL
        FalseBlock->ResolveVars(VarMap, CurrentIndex);
}

void CElseIfBlock::Emit(CEmitContext& ec) const
{
    using boost::intrusive_ptr;

    // Evaluate the conditional
    Conditional->Emit(ec);

    // Cast the result to a boolean
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));

    // Add the jump instruction (see CIfStatement::Emit for an explanation of why/how this works)
    intrusive_ptr<SJumpNotEqualInstruction> JumpInstr(new SJumpNotEqualInstruction(0));
    ec.AddInstruction(JumpInstr);

    size_t InstrCount = ec.GetInstructionCount();

    // Emit normally
    CBlock::Emit(ec);

    size_t InstrOffset = ec.GetInstructionCount() - InstrCount + 1;
    JumpInstr->Offset = InstrOffset + 1; // +1 is needed here because CIfStatement::Emit will tack on another
                                         // instruction at the end.
}