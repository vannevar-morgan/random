// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "InstructionSet.h"

#include <map>
#include <list>
#include <stack>

// Forward declarations
class CBlock;
class CProgram;
class CFunction;

typedef CArray< boost::intrusive_ptr<IInstruction> > TInstructionContainer;
typedef std::map<CString, TVarIndex> TVarIndexMap;
typedef std::map< boost::intrusive_ptr<const CBlock>, TVarIndexMap > TBlockVarMap;

class CExecutable
{
private:
    TInstructionContainer Instructions;
    size_t EntryStackSize;

public:
    CExecutable(const TInstructionContainer& Instructions, size_t EntryStackSize);

    const TInstructionContainer& GetInstructions() const;
    size_t GetEntryStackSize() const;
};

CExecutable Compile(const CProgram& Program, bool Debug);

class CEmitContext
{
private:
    TInstructionContainer Instructions;

    struct SJumpContext
    {
        size_t InstructionIndex;
        boost::intrusive_ptr<SJumpInstruction> JumpInstruction;
        boost::intrusive_ptr<const CBlock> BlockToJumpTo;
        bool JumpToBeginning; // Jumps to end if false
    };

    struct SCallContext
    {
        size_t InstructionIndex;
        boost::intrusive_ptr<SCallInstruction> CallInstruction;
        CString FunctionName;

        // Used for debugging
        size_t Index;
        TTranslationUnitPtr TranslationUnit;
    };

    struct SStackFrame
    {
        // This maps between variable names and their indices. Each block gets one of these maps, because variable scope
        // is limited to the block its contained in. Because of the way scoping works, a single variable index can
        // actually be used by many different variable names from different scopes. But the process used to generate this
        // map ensures that only a single variable name is occupying a particular variable index at any given time.
        TBlockVarMap VarMap;
        boost::intrusive_ptr<const CBlock> Function;
        size_t InitialStackUsage;
    };

    // Key is function name
    // Each function gets its own stack frame
    std::map<CString, SStackFrame> StackFrames;
    SStackFrame EntryPointStackFrame;
    SStackFrame* CurrentStackFrame;

    CArray<SJumpContext> JumpContexts;
    CArray<SCallContext> CallContexts;

    void InitialiseStackFrame(const boost::intrusive_ptr<const CBlock>& Function, SStackFrame& StackFrame);

    void ResolveJumps();
    void ResolveCalls();

public:
    CEmitContext(const CProgram& p);

    void AddInstruction(const boost::intrusive_ptr<IInstruction>& i);

    const TInstructionContainer& GetInstructions() const;
    size_t GetInstructionCount() const;

    // These functions retrieve an index for a variable. They throw CVariableNotFoundException exception if it
    // doesn't exist.
    TVarIndex GetVarIndex(const CString& VarName, const boost::intrusive_ptr<const CBlock>& Parent, size_t Index,
        const TTranslationUnitPtr& TranslationUnit) const;

    void RegisterJumpContext(size_t InstructionIndex, const boost::intrusive_ptr<SJumpInstruction>& JumpInstruction,
        const boost::intrusive_ptr<const CBlock>& BlockToJumpTo, bool JumpToBeginning = false);
    void RegisterCallContext(size_t InstructionIndex, const boost::intrusive_ptr<SCallInstruction>& CallInstruction,
        const CString& FunctionName, size_t Index, const TTranslationUnitPtr& t);

    friend CExecutable Compile(const CProgram& Program, bool Debug);
};
