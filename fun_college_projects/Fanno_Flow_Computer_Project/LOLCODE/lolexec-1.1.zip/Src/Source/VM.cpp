// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "VM.h"
#include "Errors.h"

#include "VMHelper.h"
#include "VMHelper.inl"

#include <iostream>
#include <cmath>
#include <algorithm>

// Default just uses cout and cin
class CDefaultRuntimeIO : public IRuntimeIO
{
public:
    void Print(const CString& String)
    {
        std::cout << String;
    }
    CString Read()
    {
        CString s;
        getline(std::cin, s);
        return s;
    }
};

static CDefaultRuntimeIO DefaultRuntimeIO;

CVirtualMachine::CVirtualMachine(bool Debug)
    : Debug(Debug)
{
    SetDefaultRuntimeIO();
}

FORCE_INLINE SRuntimeVar& CVirtualMachine::Fetch(TVarIndex Index)
{
    return *(FramePtr + Index);
}

void CVirtualMachine::PrintStack()
{
    using namespace std;

    SRuntimeVar* Ptr = FramePtr;
    while(Ptr <= StackPtr)
    {
        cout << Ptr - FramePtr << ": ";
        switch(Ptr->Type)
        {
        case RuntimeVarType_Untyped:
            cout << "Untyped";
            break;
        case RuntimeVarType_Integer:
            cout << Ptr->IntegerPart;
            break;
        case RuntimeVarType_Float:
            cout << Ptr->FloatPart;
            break;
        case RuntimeVarType_Boolean:
            cout << "bool " << Ptr->BooleanPart;
            break;
        case RuntimeVarType_String:
            cout << Ptr->StringPart.ToString();
            break;
        default:
            break;
        }
        cout << endl;
        ++Ptr;
    }
    cout << endl;
}

FORCE_INLINE void CopyVar(SRuntimeVar& Dest, const SRuntimeVar& Src)
{
    switch(Src.Type)
    {
    case RuntimeVarType_Integer:
        Dest.IntegerPart = Src.IntegerPart;
        Dest.Type = RuntimeVarType_Integer;
        break;
    case RuntimeVarType_Float:
        Dest.FloatPart = Src.FloatPart;
        Dest.Type = RuntimeVarType_Float;
        break;
    case RuntimeVarType_Boolean:
        Dest.BooleanPart = Src.BooleanPart;
        Dest.Type = RuntimeVarType_Boolean;
        break;
    case RuntimeVarType_String:
        Dest.StringPart.Initialise(Src.StringPart);
        Dest.Type = RuntimeVarType_String;
        break;
    case RuntimeVarType_Untyped:
        Dest.Type = RuntimeVarType_Untyped;
        break;
    default:
        throw CInvalidInstructionException("Unknown runtime variable type.");
    }
}

FORCE_INLINE void CVirtualMachine::PopStack()
{
    if(StackPtr->Type == RuntimeVarType_String)
        StackPtr->StringPart.Release();
    --StackPtr;
}

// For floating-point modulus
struct SFloatMod
{
    FORCE_INLINE double operator()(double x, double y) const {
        return fmod(x, y);
    }
};

// These are workarounds for GCC
template<typename T>
struct SMin
{
    FORCE_INLINE T operator()(T x, T y) const {
        return std::min(x, y);
    }
};
template<typename T>
struct SMax
{
    FORCE_INLINE T operator()(T x, T y) const {
        return std::max(x, y);
    }
};

void CVirtualMachine::Execute(const CExecutable& Executable)
{
    using namespace std;

    const TInstructionContainer& InstructionStream = Executable.GetInstructions();
    Memory.resize(10000); // Hack, need to replace with VirtualLock or somesuch
                          // TODO: Fix this hack

    FramePtr = &Memory[1]; // Leave one space for the return value from HAI
    StackPtr = FramePtr;

    const TInstructionContainer::value_type* End = &InstructionStream.back() + 1;

    // Push bookkeeping stuff onto the stack
    {
        SStackUnwindParams UnwindParams;
        UnwindParams.ip = End - 1;
        UnwindParams.PrevFramePtr = FramePtr;
        (FramePtr+InstructionPointerIndex)->UnwindParamsPart = UnwindParams;
        ++StackPtr; // Make space for IT variable
    }

    // Set initial stack size
    StackPtr += Executable.GetEntryStackSize();

    for(const TInstructionContainer::value_type* ip = &InstructionStream.front() ; /*ip != End*/ ; )
    {
        switch((*ip)->GetType())
        {
        case InstructionType_Print:
            {
                SPrintInstruction* i = static_cast<SPrintInstruction*>(ip->get());
                switch(StackPtr->Type)
                {
                case RuntimeVarType_Untyped:
                    // Implicit cast into a boolean
                    RuntimeIO->Print("FAIL");
                    break;
                case RuntimeVarType_Integer:
                    {
                        char Buf[MaxIntegerStringLength] = {'\0'};
                        sprintf(Buf, "%d", StackPtr->IntegerPart);
                        RuntimeIO->Print(Buf);
                    } break;
                case RuntimeVarType_Float:
                    {
                        char Buf[MaxFloatStringLength] = {'\0'};
                        double Num = StackPtr->FloatPart;
                        if(Num >= 1000000) // Print in exponent or float format, whichever is shorter
                            sprintf(Buf, "%.2e", Num);
                        else
                            sprintf(Buf, "%.2f", Num);
                        RuntimeIO->Print(Buf);
                    } break;
                    break;
                case RuntimeVarType_Boolean:
                    if(StackPtr->BooleanPart == true)
                        RuntimeIO->Print("WIN");
                    else
                        RuntimeIO->Print("FAIL");
                    break;
                case RuntimeVarType_String:
                    RuntimeIO->Print(StackPtr->StringPart.First);
                    StackPtr->StringPart.Release();
                    break;
                }
                --StackPtr;
            } break;
        case InstructionType_KeyboardInput:
            {
                SKeyboardInputInstruction* i = static_cast<SKeyboardInputInstruction*>(ip->get());
                ++StackPtr;
                StackPtr->StringPart.Initialise(RuntimeIO->Read());
                StackPtr->Type = RuntimeVarType_String;
            } break;
        case InstructionType_LoadVar:
            {
                SLoadVarInstruction* i = static_cast<SLoadVarInstruction*>(ip->get());
                ++StackPtr;
                CopyVar(*StackPtr, Fetch(i->VarIndex));
            } break;
        case InstructionType_StoreVar:
            {
                SStoreVarInstruction* i = static_cast<SStoreVarInstruction*>(ip->get());
                SRuntimeVar& Var = Fetch(i->VarIndex);
                if(Var.Type == RuntimeVarType_String) {
                    Var.StringPart.Release();
                }
                if(StackPtr->Type == RuntimeVarType_String) {
                    Var.StringPart.Initialise(StackPtr->StringPart);
                    Var.Type = RuntimeVarType_String;
                } else {
                    Var = *StackPtr;
                }
                PopStack();
            } break;
        case InstructionType_Pop:
            {
                PopStack();
            } break;
        case InstructionType_LoadInteger:
            {
                SLoadIntegerInstruction* i = static_cast<SLoadIntegerInstruction*>(ip->get());
                ++StackPtr;
                StackPtr->IntegerPart = i->Value;
                StackPtr->Type = RuntimeVarType_Integer;
            } break;
        case InstructionType_LoadFloat:
            {
                SLoadFloatInstruction* i = static_cast<SLoadFloatInstruction*>(ip->get());
                ++StackPtr;
                StackPtr->FloatPart = i->Value;
                StackPtr->Type = RuntimeVarType_Float;
            } break;
        case InstructionType_LoadBoolean:
            {
                SLoadBooleanInstruction* i = static_cast<SLoadBooleanInstruction*>(ip->get());
                ++StackPtr;
                StackPtr->BooleanPart = i->Value;
                StackPtr->Type = RuntimeVarType_Boolean;
            } break;
        case InstructionType_LoadString:
            {
                SLoadStringInstruction* i = static_cast<SLoadStringInstruction*>(ip->get());
                ++StackPtr;
                StackPtr->StringPart.Initialise(i->Value);
                StackPtr->Type = RuntimeVarType_String;
            } break;
        case InstructionType_LoadUntyped:
            {
                SLoadUntypedInstruction* i = static_cast<SLoadUntypedInstruction*>(ip->get());
                ++StackPtr;
                StackPtr->Type = RuntimeVarType_Untyped;
                // No need to set a value, untyped variables don't have one
            } break;
        case InstructionType_Jump:
            {
                SJumpInstruction* i = static_cast<SJumpInstruction*>(ip->get());
                ip += i->Offset;
                continue;
            } break;
        case InstructionType_JumpEqual:
            {
                SJumpEqualInstruction* i = static_cast<SJumpEqualInstruction*>(ip->get());
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif
                if(StackPtr->BooleanPart == true) {
                    ip += i->Offset;
                    --StackPtr;
                    continue;
                }
                --StackPtr;
            } break;
        case InstructionType_JumpNotEqual:
            {
                SJumpNotEqualInstruction* i = static_cast<SJumpNotEqualInstruction*>(ip->get());
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif
                if(StackPtr->BooleanPart == false) {
                    ip += i->Offset;
                    --StackPtr;
                    continue;
                }
                --StackPtr;
            } break;
        case InstructionType_Call:
            {
                SCallInstruction* i = static_cast<SCallInstruction*>(ip->get());

                SStackUnwindParams UnwindParams;
                UnwindParams.ip = ip;
                UnwindParams.PrevFramePtr = FramePtr;

                // Make new stack frame
                ++StackPtr;
                FramePtr = StackPtr;

                // Push bookkeeping stuff onto the stack
                StackPtr->UnwindParamsPart = UnwindParams;

                // Move up past bookkeeping stuff (make room for IT variable)
                ++StackPtr;

                // Set initial stack size
                StackPtr += i->InitialStack;

                // Jump to function
                ip += i->Offset;
                continue;
            } break;
        case InstructionType_Return:
            {
                SReturnInstruction* i = static_cast<SReturnInstruction*>(ip->get());

                // The special bookkeeping stuff is kept at the frame pointer
                const SStackUnwindParams& UnwindParams = (FramePtr + InstructionPointerIndex)->UnwindParamsPart;

                // Unwind the stack, move stack pointer back down
                // Stack pointer points to return value
                while(StackPtr != FramePtr)
                    PopStack();
                
                FramePtr = UnwindParams.PrevFramePtr;

                // Pop the bookkeeping stuff off the stack
                PopStack();

                ip = UnwindParams.ip;
                if(ip + 1 >= End)
                    return; // Stop execution
            } break;
        case InstructionType_Equals:
            {
                using std::equal_to;

                SEqualsInstruction* i = static_cast<SEqualsInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                StackPtr->BooleanPart = PerformComparisonOp<false>(*StackPtr, RHS, equal_to<bool>(), equal_to<int>(),
                    equal_to<double>(), equal_to<SRuntimeString>());
                StackPtr->Type = RuntimeVarType_Boolean;
            } break;
        case InstructionType_NotEquals:
            {
                using std::not_equal_to;

                SNotEqualsInstruction* i = static_cast<SNotEqualsInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                StackPtr->BooleanPart = PerformComparisonOp<true>(*StackPtr, RHS, not_equal_to<bool>(),
                    not_equal_to<int>(), not_equal_to<double>(), not_equal_to<SRuntimeString>());
                StackPtr->Type = RuntimeVarType_Boolean;
            } break;
        case InstructionType_Add:
            {
                SAddInstruction* i = static_cast<SAddInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, std::plus<int>(), std::plus<double>());
            } break;
        case InstructionType_Subtract:
            {
                SSubtractInstruction* i = static_cast<SSubtractInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, std::minus<int>(), std::minus<double>());
            } break;
        case InstructionType_Multiply:
            {
                SMultiplyInstruction* i = static_cast<SMultiplyInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, std::multiplies<int>(), std::multiplies<double>());
            } break;
        case InstructionType_Divide:
            {
                SDivideInstruction* i = static_cast<SDivideInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, std::divides<int>(), std::divides<double>());
            } break;
        case InstructionType_Modulus:
            {
                SModulusInstruction* i = static_cast<SModulusInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, std::modulus<int>(), SFloatMod());
            } break;
        case InstructionType_Maximum:
            {
                SMaximumInstruction* i = static_cast<SMaximumInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, SMax<int>(), SMax<double>());
            } break;
        case InstructionType_Minimum:
            {
                SMinimumInstruction* i = static_cast<SMinimumInstruction*>(ip->get());
                SRuntimeVar& RHS = *StackPtr;
                --StackPtr;
                PerformBinaryMathOp(*StackPtr, RHS, SMin<int>(), SMin<double>());
            } break;
        case InstructionType_Increment:
            {
                SIncrementInstruction* i = static_cast<SIncrementInstruction*>(ip->get());
                PerformUnaryMathOp(*StackPtr, SIncrementFunc<int>(), SIncrementFunc<double>());
            } break;
        case InstructionType_Decrement:
            {
                SDecrementInstruction* i = static_cast<SDecrementInstruction*>(ip->get());
                PerformUnaryMathOp(*StackPtr, SDecrementFunc<int>(), SDecrementFunc<double>());
            } break;
        case InstructionType_And:
            {
                SAndInstruction* i = static_cast<SAndInstruction*>(ip->get());

            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& RHS = StackPtr->BooleanPart;
                --StackPtr;
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& LHS = StackPtr->BooleanPart;
                LHS = (LHS && RHS);
            } break;
        case InstructionType_Or:
            {
                SOrInstruction* i = static_cast<SOrInstruction*>(ip->get());
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& RHS = StackPtr->BooleanPart;
                --StackPtr;
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& LHS = StackPtr->BooleanPart;
                LHS = (LHS || RHS);
            } break;
        case InstructionType_Xor:
            {
                SXorInstruction* i = static_cast<SXorInstruction*>(ip->get());
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& RHS = StackPtr->BooleanPart;
                --StackPtr;
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& LHS = StackPtr->BooleanPart;
                LHS = (LHS ^ RHS);
            } break;
        case InstructionType_Not:
            {
                SNotInstruction* i = static_cast<SNotInstruction*>(ip->get());
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_Boolean)
                    throw CInvalidInstructionException("Tried to perform boolean operation on non-boolean variable.");
            #endif

                bool& Var = StackPtr->BooleanPart;
                Var = !Var;
            } break;
        case InstructionType_Cast:
            {
                SCastInstruction* i = static_cast<SCastInstruction*>(ip->get());
                Cast(*StackPtr, i->NewType);
            } break;
        case InstructionType_Concat:
            {
                SConcatInstruction* i = static_cast<SConcatInstruction*>(ip->get());

            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_String)
                    throw CInvalidInstructionException("Cannot concatenate two non-string arguments.");
            #endif

                const SRuntimeString& RHS = StackPtr->StringPart;
                --StackPtr;
                
            #ifdef _DEBUG
                if(StackPtr->Type != RuntimeVarType_String)
                    throw CInvalidInstructionException("Cannot concatenate two non-string arguments.");
            #endif

                StackPtr->StringPart.Concatenate(RHS);
            } break;
        case InstructionType_NoOp:
            {
                // Nothing
            } break;
        default:
            throw CInvalidInstructionException("Unrecognised instruction.");
        }

        /*
        if(Debug)
        {
            cout << (*ip)->ToString() << endl;
            PrintStack();
        }
        */

        // Advance the instruction pointer.
        ++ip;
    }
}

void CVirtualMachine::SetRuntimeIO(IRuntimeIO* r)
{
    if(r == NULL)
        throw CException("Runtime IO cannot be null.");
    RuntimeIO = r;
}
IRuntimeIO* CVirtualMachine::GetRuntimeIO() const
{
    return RuntimeIO;
}
void CVirtualMachine::SetDefaultRuntimeIO()
{
    RuntimeIO = &DefaultRuntimeIO;
}
