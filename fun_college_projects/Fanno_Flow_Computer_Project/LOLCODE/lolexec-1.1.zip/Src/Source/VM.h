// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "Compiler.h"
#include "InstructionSet.h"

struct SRuntimeVar; // Forward declaration

struct SRuntimeString
{
    char* First;
    char* Last;
    char* End;

    // Initialisers
    void Initialise();
    void Initialise(const CString& Contents);
    void Initialise(const char* Contents, size_t Length);
    void Initialise(const SRuntimeString& x); // Copy constructor
    void ParseInteger(int Num);
    void ParseFloat(double Num);
    void ParseBoolean(bool Num);

    void Release();

    int ToInteger() const;
    double ToFloat() const;
    bool ToBoolean() const;
    CString ToString() const; // This is not a fast operation

    bool Empty() const;
    void Concatenate(const SRuntimeString& s2);
    size_t Length() const;

    void Resize(size_t NewLength);
};

bool operator == (const SRuntimeString& lhs, const SRuntimeString& rhs);
bool operator != (const SRuntimeString& lhs, const SRuntimeString& rhs);

// Inline function definitions for above
#include "RuntimeString.inl"

struct SStackUnwindParams
{
    const TInstructionContainer::value_type* ip;
    SRuntimeVar* PrevFramePtr;
};

struct SRuntimeVar
{
    ERuntimeVarType Type;
    union {
        int IntegerPart;
        double FloatPart;
        bool BooleanPart;
        SRuntimeString StringPart;
        SStackUnwindParams UnwindParamsPart;
    };
};

// If you want to override CVirtualMachine's default input/output routines, derive from this class
// and give your custom class to CVirtualMachine
class IRuntimeIO
{
public:
    virtual void Print(const CString& String) = 0;
    virtual CString Read() = 0;
};

class CVirtualMachine
{
private:
    bool Debug;

    CArray<SRuntimeVar> Memory;
    SRuntimeVar* StackPtr;
    SRuntimeVar* FramePtr;

    IRuntimeIO* RuntimeIO;

    SRuntimeVar& Fetch(TVarIndex Index);
    void PopStack();

    void PrintStack();

public:
    CVirtualMachine(bool Debug);

    void SetRuntimeIO(IRuntimeIO* r);
    void SetDefaultRuntimeIO();
    IRuntimeIO* GetRuntimeIO() const;

    void Execute(const CExecutable& Executable);
};
