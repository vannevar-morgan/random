// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
//

#include "Command.h"
#include "Errors.h"
#include "Compiler.h"

#include <boost\variant.hpp>

// Performs no validation at all (is just a dumb check)
ERValueType DetermineRValueType(const SValue& v)
{
    if(v.IsStringLiteral)
        return RValueType_StringLiteral;
    if(v.Data == "WIN" || v.Data == "FAIL")
        return RValueType_BooleanLiteral;
    if(v.Data.find('.') != CString::npos && v.Data.find_first_not_of(".-1234567890") == CString::npos)
        return RValueType_FloatLiteral;
    if(v.Data.find_first_not_of("-1234567890") == CString::npos)
        return RValueType_IntegerLiteral;
    return RValueType_Variable;
}

SLiteral ParseLiteral(const SValue& v, ERValueType Type, size_t Index, const CTranslationUnit& t)
{
    assert(DetermineRValueType(v) == Type);

    SLiteral l;
    l.Type = Type;
    try
    {
        switch(Type)
        {
        case RValueType_IntegerLiteral:
            l.Value = boost::lexical_cast<int>(v.Data);
            break;
        case RValueType_FloatLiteral:
            l.Value = boost::lexical_cast<double>(v.Data);
            break;
        case RValueType_BooleanLiteral:
            if(v.Data == "WIN")
                l.Value = true;
            else if(v.Data == "FAIL")
                l.Value = false;
            else
                throw CSyntaxException(CompileError_NoDesc, Index, t);
            break;
        case RValueType_StringLiteral:
            l.Value = v.Data;
            break;
        default:
            // oops, this isn't a literal
            throw CException("Value is not a recognised literal type.");
        }
    }
    catch(const boost::bad_lexical_cast&)
    {
        throw CSyntaxException(CompileError_NoDesc, Index, t);
    }

    return l;
}

void ValidateVariableName(const CString& Name, size_t Index, const CTranslationUnit& t)
{
    if(Name.empty())
        return;
    if(isdigit(Name[0]))
        throw CSyntaxException(CompileError_NoDesc, Index, t);
    foreach(char c, Name)
    {
        if(!isalnum(c) && c != '_')
            throw CSyntaxException(CompileError_NoDesc, Index, t);
    }
}

void CVisibleCommand::Emit(CEmitContext& ec) const
{
    foreach(const SValue& v, Arguments)
    {
        bool IsLast = (&v == &Arguments.back());
        bool TerminateWithNewLine = false;
        if(IsLast && v.Data.back() != '!')
            TerminateWithNewLine = true;

        if(v.IsStringLiteral)
        {
            CString Arg = v.Data;
            FindAndReplaceAll(":)", "\n", Arg); // newline
            FindAndReplaceAll(":>", "\t", Arg); // tab
            FindAndReplaceAll(":o", "\b", Arg); // beep
            FindAndReplaceAll(":\"", "\"", Arg); // double quote
            FindAndReplaceAll("::", ":", Arg); // colon
            if(Arg.find(':') != CString::npos) // Unrecognised escape sequence
            {
                // Something (warning, maybe?)
            }
            if(TerminateWithNewLine)
                Arg += '\n';
            ec.AddInstruction(boost::shared_ptr<SPrintLiteralInstruction>(new SPrintLiteralInstruction(Arg)));
        }
        else
        {
            ERValueType Type = DetermineRValueType(v);
            if(Type == RValueType_Variable)
            {
                CString VarName = v.Data;
                if(IsLast && !TerminateWithNewLine)
                    VarName.pop_back(); // Remove trailing '!'

                ValidateVariableName(VarName, Index, TranslationUnit);

                // Perform a lookup for the variable name to get the variable's index
                const TBlockVarMap& VarMap = ec.GetVarMap();
                TBlockVarMap::const_iterator MyBlockIter = VarMap.find(Parent);
                assert(MyBlockIter != VarMap.end());

                const TVarIndexMap& MyBlockVarMap = MyBlockIter->second;
                TVarIndexMap::const_iterator SrcVar = MyBlockVarMap.find(VarName);
                assert(SrcVar != MyBlockVarMap.end());

                size_t Index = SrcVar->second;
                boost::shared_ptr<SPrintVarInstruction> i(new SPrintVarInstruction(Index));
                ec.AddInstruction(i);

                if(TerminateWithNewLine)
                    ec.AddInstruction(boost::shared_ptr<SPrintLiteralInstruction>(new SPrintLiteralInstruction("\n")));
            }
            else
            {
                SValue Val = v;
                if(IsLast && !TerminateWithNewLine)
                    Val.Data.pop_back(); // Remove trailing '!'

                // Attempt to parse the literal. It may seem roundabout to parse a string representation of a number,
                // then lexical_cast it back to a string. But there's a good reason for it: ParseLiteral does extra
                // stuff like validate the literal, and may do other formatting stuff under the hood.
                SLiteral l = ParseLiteral(Val, Type, Index, TranslationUnit);

                CString Arg;
                switch(Type)
                {
                case RValueType_IntegerLiteral:
                    Arg = boost::lexical_cast<CString>(boost::get<int>(l.Value));
                    break;
                case RValueType_FloatLiteral:
                    // TODO: Truncation of this value
                    Arg = boost::lexical_cast<CString>(boost::get<double>(l.Value));
                    break;
                case RValueType_BooleanLiteral:
                    if(boost::get<bool>(l.Value) == true)
                        Arg = "WIN";
                    else
                        Arg = "FAIL";
                    break;
                default:
                    // oops, this isn't a literal
                    throw CException("Value is not a recognised literal type.");
                }

                ec.AddInstruction(boost::shared_ptr<SPrintLiteralInstruction>(new SPrintLiteralInstruction(Arg)));

                if(TerminateWithNewLine)
                    ec.AddInstruction(boost::shared_ptr<SPrintLiteralInstruction>(new SPrintLiteralInstruction("\n")));
            }
        }
    }
}

void CImportCommand::Emit(CEmitContext& ec) const
{
    // There's not really any point in emitting a no-op
    //ec.AddInstruction(boost::shared_ptr<SNoOpInstruction>(new SNoOpInstruction()));
}
void CDeclareVarCommand::Emit(CEmitContext& ec) const
{
    size_t DestIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);

    boost::shared_ptr<SDeclareVarInstruction> i1(new SDeclareVarInstruction(DestIndex));
    ec.AddInstruction(i1);

    if(!InitialValue.Data.empty() || InitialValue.IsStringLiteral)
    {
        // There's a declaration with this definition - assign its value to the variable
        ERValueType Type = DetermineRValueType(InitialValue);
        if(Type == RValueType_Variable)
        {
            ValidateVariableName(VarName, Index, TranslationUnit);
            size_t SrcIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);
            boost::shared_ptr<SAssignVarInstruction> i2(new SAssignVarInstruction(SrcIndex, DestIndex));
            ec.AddInstruction(i2);
        }
        else
        {
            SLiteral l = ParseLiteral(InitialValue, Type, Index, TranslationUnit);
            boost::shared_ptr<SAssignLiteralToVarInstruction> i2(new SAssignLiteralToVarInstruction(DestIndex, l));
            ec.AddInstruction(i2);
        }
    }
}
void CDeclareVarCommand::ResolveVars(TBlockVarMap& VarMap,
                                     const boost::shared_ptr<const CBlock>& Parent,
                                     size_t& CurrentIndex) const
{
    // Ensure that the parent block has already been added
    assert(VarMap.find(Parent) != VarMap.end());

    // Ensure that this variable name is not already in use
    if(VarMap[Parent].find(VarName) != VarMap[Parent].end())
        throw CSyntaxException(CompileError_NoDesc, Index, TranslationUnit);

    VarMap[Parent][VarName] = CurrentIndex;
    ++CurrentIndex;
}

void CAssignVarCommand::Emit(CEmitContext& ec) const
{
    size_t DestIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);

    ERValueType Type = DetermineRValueType(Value);
    if(Type == RValueType_Variable)
    {
        ValidateVariableName(Value.Data, Index, TranslationUnit);
        size_t SrcIndex = ec.GetVarIndex(Value.Data, Parent, Index, TranslationUnit);
        boost::shared_ptr<SAssignVarInstruction> i(new SAssignVarInstruction(SrcIndex, DestIndex));
        ec.AddInstruction(i);
    }
    else
    {
        SLiteral l = ParseLiteral(Value, Type, Index, TranslationUnit);
        boost::shared_ptr<SAssignLiteralToVarInstruction> i(new SAssignLiteralToVarInstruction(DestIndex, l));
        ec.AddInstruction(i);
    }
}

// Returns true if both literals are equal
bool CompareLiterals(const SLiteral& lhs, const SLiteral& rhs)
{
    switch(lhs.Type)
    {
    case RValueType_IntegerLiteral:
        switch(rhs.Type)
        {
        case RValueType_IntegerLiteral:
            return (boost::get<int>(lhs.Value) == boost::get<int>(rhs.Value));
        case RValueType_FloatLiteral: // Implicit conversion int -> float
            return (static_cast<double>(boost::get<int>(lhs.Value)) == boost::get<double>(rhs.Value));
        default:
            return false;
        }
    case RValueType_FloatLiteral:
        switch(rhs.Type)
        {
        case RValueType_IntegerLiteral: // Implicit conversion int -> float
            return (boost::get<double>(lhs.Value) == static_cast<double>(boost::get<int>(rhs.Value)));
        case RValueType_FloatLiteral:
            return (boost::get<double>(lhs.Value) == boost::get<double>(rhs.Value));
        default:
            return false;
        }
    case RValueType_BooleanLiteral:
        return (rhs.Type == RValueType_BooleanLiteral && boost::get<bool>(lhs.Value) == boost::get<bool>(rhs.Value));
    case RValueType_StringLiteral:
        return (rhs.Type == RValueType_StringLiteral && boost::get<CString>(lhs.Value) == boost::get<CString>(rhs.Value));
    default:
        throw CException("Invalid literal type.");
    }
}

// Set IsEquals to true to emit an equals instruction. Otherwise, set it to false to emit a NOT equals instruction.
void EmitComparisonCommand(CEmitContext& ec, const SValue& LHS, const SValue& RHS, size_t Index,
    const CTranslationUnit& TranslationUnit, const boost::shared_ptr<CBlock>& Parent, bool IsEquals)
{
    ERValueType LHSType = DetermineRValueType(LHS);
    ERValueType RHSType = DetermineRValueType(RHS);
    if(LHSType == RValueType_Variable)
    {
        ValidateVariableName(LHS.Data, Index, TranslationUnit);
        size_t LHSIndex = ec.GetVarIndex(LHS.Data, Parent, Index, TranslationUnit);
        if(RHSType == RValueType_Variable)
        {
            // Both variables
            ValidateVariableName(RHS.Data, Index, TranslationUnit);

            size_t RHSIndex = ec.GetVarIndex(RHS.Data, Parent, Index, TranslationUnit);
            if(IsEquals) {
                boost::shared_ptr<SEqualsInstruction> i(new SEqualsInstruction(LHSIndex, RHSIndex));
                ec.AddInstruction(i);
            } else {
                boost::shared_ptr<SNotEqualsInstruction> i(new SNotEqualsInstruction(LHSIndex, RHSIndex));
                ec.AddInstruction(i);
            }
        }
        else
        {
            // LHS is a variable, RHS is a literal
            size_t LHSIndex = ec.GetVarIndex(LHS.Data, Parent, Index, TranslationUnit);
            SLiteral l = ParseLiteral(RHS, LHSType, Index, TranslationUnit);
            if(IsEquals) {
                boost::shared_ptr<SEqualsLiteralInstruction> i(new SEqualsLiteralInstruction(LHSIndex, l));
                ec.AddInstruction(i);
            } else {
                boost::shared_ptr<SNotEqualsLiteralInstruction> i(new SNotEqualsLiteralInstruction(LHSIndex, l));
                ec.AddInstruction(i);
            }
        }
    }
    else
    {
        SLiteral LHSLiteral = ParseLiteral(RHS, LHSType, Index, TranslationUnit);
        if(RHSType == RValueType_Variable)
        {
            // LHS is a literal, RHS is a variable
            ValidateVariableName(RHS.Data, Index, TranslationUnit);

            // This operation is commutative, so it's OK to switch around operands
            size_t RHSIndex = ec.GetVarIndex(RHS.Data, Parent, Index, TranslationUnit);
            if(IsEquals) {
                boost::shared_ptr<SEqualsLiteralInstruction> i(new SEqualsLiteralInstruction(RHSIndex, LHSLiteral));
                ec.AddInstruction(i);
            } else {
                boost::shared_ptr<SNotEqualsLiteralInstruction> i(new SNotEqualsLiteralInstruction(RHSIndex, LHSLiteral));
                ec.AddInstruction(i);
            }
        }
        else
        {
            // LHS is a literal, RHS is a literal
            // Both operands are literals: we can resolve this statically now at compile time
            bool Cond = CompareLiterals(LHSLiteral, ParseLiteral(RHS, RHSType, Index, TranslationUnit));
            if(IsEquals)
                Cond = !Cond;
            boost::shared_ptr<SSetCondInstruction> i(new SSetCondInstruction(Cond));
            ec.AddInstruction(i);
        }
    }
}

void CEqualsCommand::Emit(CEmitContext& ec) const
{
    EmitComparisonCommand(ec, LHS, RHS, Index, TranslationUnit, Parent, true);
}
void CNotEqualsCommand::Emit(CEmitContext& ec) const
{
    EmitComparisonCommand(ec, LHS, RHS, Index, TranslationUnit, Parent, false);
}
