// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Main.h"
#include "Errors.h"

#include "TranslationUnit.h"
#include "Tokeniser.h"
#include "Preprocessor.h"
#include "Parser.h"
#include "Compiler.h"
#include "VM.h"
#include "Timer.h"

#include <iostream>
#include <fstream>
#include <algorithm>

#include <boost/scoped_array.hpp>
#include <boost/scoped_ptr.hpp>

void DisplayHelp()
{
    using namespace std;
    cout << "(c) Adrian \"Sc4Freak\" Tsai 2008" << endl;
    cout << "LOLExec: Dynamic LOLCODE Interpreter ver 1.00" << endl;
    cout << "Usage: lolexec Filename [switches]" << endl;
    cout << "Valid switches:" << endl;
    cout << "  -d        : Run in debug mode." << endl;
    cout << "  -v or -vv : Run in verbose or more verbose mode." << endl;
    cout << "  -tc       : Measure program compile time." << endl;
    cout << "  -te       : Measure program execution time." << endl;
}

struct SOptions
{
    CString Filename;
    bool Debug;
    int Verbosity;

    bool TimeCompile;
    bool TimeExecution;

    bool PauseAtEnd;

    SOptions() : Debug(false), Verbosity(0), TimeCompile(false), TimeExecution(false), PauseAtEnd(true) {}
};

SOptions Options;

void Exit()
{
    if(Options.PauseAtEnd)
    {
        std::cout << "Press ENTER to continue...";
        std::cin.get();
    }
    exit(0);
}

CString ReadCodeFromFile(const CString& Filename)
{
    using std::ifstream;

    try
    {
        ifstream ifs;
        ifs.exceptions(ifstream::badbit | ifstream::failbit | ifstream::eofbit);
        ifs.open(Filename.c_str(), ifstream::binary);

        ifs.seekg(0, ifstream::end);
        size_t Length = ifs.tellg();
        ifs.seekg(0);

        boost::scoped_array<char> Data(new char[Length]);
        ifs.read(Data.get(), Length);
        return CString(Data.get(), Length);
    }
    catch(const ifstream::failure&)
    {
        throw CException("Could not load file.");
    }
}

bool IsSwitchEqual(const CString& Argument, const CString& Switch)
{
    return (Argument == "-" + Switch || Argument == "/" + Switch);
}

#ifndef UNIT_TEST
int main(int argc, char** argv)
{
    using namespace std;
    try
    {
        CArray<CString> Arguments;
        for(int i = 0 ; i < argc ; ++i)
            Arguments.push_back(argv[i]);

        try
        {
            CArray<CString>::const_iterator it = Arguments.begin() + 1;
            if(it == Arguments.end())
                throw CArgumentException("No file specified.");
            if(IsSwitchEqual(*it, "?"))
            {
                DisplayHelp();
                Exit();
            }
            Options.Filename = *it;
            ++it;
            for( ; it != Arguments.end() ; ++it)
            {
                if(it->empty())
                    continue;
                if(IsSwitchEqual(*it, "d")) {
                    Options.Debug = true;
                } else if(IsSwitchEqual(*it, "v")) {
                    Options.Verbosity = std::max(Options.Verbosity, 1);
                } else if(IsSwitchEqual(*it, "vv")) {
                    Options.Verbosity = std::max(Options.Verbosity, 2);
                } else if(IsSwitchEqual(*it, "tc")) {
                    Options.TimeCompile = true;
                } else if(IsSwitchEqual(*it, "te")) {
                    Options.TimeExecution = true;
                } else {
                    DisplayHelp();
                    Exit();
                }
            }
        }
        catch(const CArgumentException& e)
        {
            cout << "Error: " << e.what() << endl;
            Exit();
        }

        CTimer CompileTimer;
        CTimer ExecutionTimer;

        CompileTimer.Start();

        CString Code = ReadCodeFromFile(Options.Filename);
        boost::shared_ptr<CTranslationUnit> TranslationUnit(new CTranslationUnit(Code));
        Preprocess(*TranslationUnit, Options.Debug);
        TTokenContainer Tokens = Tokenise(TranslationUnit, Options.Debug);

        if(Options.Verbosity >= 2)
        {
            cout << "Tokens:\n";
            foreach(const SToken& t, Tokens)
            {
                cout << t.Lexeme << " " << t.Type << '\n';
            }
            cout << "\n";
        }

        CProgram Program = Parse(TranslationUnit, Tokens, Options.Debug);
        CExecutable Executable = Compile(Program, Options.Debug);

        CompileTimer.End();

        if(Options.Verbosity >= 1)
        {
            cout << "Instruction stream: " << Executable.GetInstructions().size() << '\n';
            size_t InstrNum = 0;
            int Fill = lexical_cast<CString>(Executable.GetInstructions().size()).length();
            foreach(const boost::intrusive_ptr<IInstruction>& i, Executable.GetInstructions())
            {
                cout << ToString(InstrNum, Fill, ' ') << ": " << i->ToString() << '\n';
                ++InstrNum;
            }
            cout << '\n';
        }

        if(Options.TimeCompile)
        {
            cout << "\n\nCompile took: " << CompileTimer.ToString() << '\n';
        }

        if(Options.Verbosity >= 1)
            cout << "Execution output:" << '\n';

        CVirtualMachine VM(Options.Debug);
        ExecutionTimer.Start();
        VM.Execute(Executable);
        ExecutionTimer.End();

        if(Options.TimeExecution)
        {
            cout << "\n\nExecution took: " << ExecutionTimer.ToString() << '\n';
        }
    }
    catch(const CCompileException& e)
    {
        cout << e.what() << endl;
        Exit();
    }
    catch(const CRuntimeException& e)
    {
        cout << e.what() << endl;
        Exit();
    }
    catch(const std::exception& e)
    {
        cout << "INTERNAL COMPILER ERROR: " << e.what() << endl;
        Exit();
    }

    Exit();
    return 0;
}
#endif