// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Function.h"
#include "Errors.h"
#include "Compiler.h"
#include "Expression.h"

void CFunction::Emit(CEmitContext& ec) const
{
    using boost::intrusive_ptr;

    InstrStartIndex = ec.GetInstructionCount();

    Body->Emit(ec);

    size_t NumArgs = Arguments.size();

    // Emit return instruction
    // Return implicit "IT" variable - push it onto the stack, then store it in the return value
    ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(ITVarIndex)));
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(-NumArgs - 1)));
    ec.AddInstruction(intrusive_ptr<SReturnInstruction>(new SReturnInstruction()));

    InstrEndIndex = ec.GetInstructionCount();
}
void CFunction::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    size_t OriginalIndex = CurrentIndex;

    // Ensure that we haven't already been added to the map
    assert(VarMap.find(Body) == VarMap.end());
    assert(Parent == NULL); // Must be a top-level block

    // Add to map
    TBlockVarMap::iterator it = VarMap.insert(std::make_pair(Body, TVarIndexMap())).first;

    // Function arguments are pushed onto the stack in LEFT TO RIGHT order. Once the function is called, the frame
    // pointer moves up to the top of the stack, then the stack grows to accommodate the function. This means that
    // the function arguments actually lie *below* the frame pointer. Since all variable accesses are made relative
    // to the frame pointer, that means we need an index that is negative.
    size_t ArgumentCount = Arguments.size();
    for(size_t i = 0 ; i < ArgumentCount ; ++i)
    {
        const CString& VarName = Arguments[i];

        ValidateVariableName(VarName, Index, TranslationUnit);

        // Ensure that this variable name is not already in use
        if(VarMap[Body].find(VarName) != VarMap[Body].end())
            throw CSyntaxException(CompileError_VarNameInUse, Index, TranslationUnit);

        // Remember, left to right order.
        // eg. if there are 3 arguments, then the first argument will sit at index of -3.
        VarMap[Body][VarName] = i - ArgumentCount;
    }

    // This is a top-level block - which means that we need to add the implicit "IT" variable
    assert(it->second.find("IT") == it->second.end());
    it->second["IT"] = ITVarIndex;

    // Resolve body
    foreach(const boost::intrusive_ptr<CStatement>& s, Body->Statements)
    {
        s->ResolveVars(VarMap, CurrentIndex);
    }

    // Let vars go out of scope
    CurrentIndex = OriginalIndex;
}