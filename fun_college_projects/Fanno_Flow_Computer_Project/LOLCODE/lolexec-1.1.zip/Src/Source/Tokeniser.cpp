// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Tokeniser.h"
#include "Errors.h"
#include "TranslationUnit.h"

bool operator== (const SToken& lhs, const SToken& rhs)
{
    return (lhs.Lexeme == rhs.Lexeme && lhs.Type == rhs.Type && lhs.Index == rhs.Index);
}

bool IsWhitespace(CTranslationUnit::const_iterator it)
{
    return (*it == ' ' || *it == '   ');
}

bool IsNewLine(CTranslationUnit::const_iterator it)
{
    return (*it == '\n');
}

bool IsCommandSeparator(CTranslationUnit::const_iterator it)
{
    return (*it == ',');
}

bool IsStringLiteral(CTranslationUnit::const_iterator it)
{
    return (*it == '\"');
}

bool IsCommandJoiner(CTranslationUnit::const_iterator it, CTranslationUnit::const_iterator end)
{
    if(std::distance(it, end) < 3)
        return false;
    return (*it == '.' && *(it+1) == '.' && *(it+2) == '.');
}

bool IsTokenDelimiter(CTranslationUnit::const_iterator it, CTranslationUnit::const_iterator end)
{
    return (IsWhitespace(it) || IsNewLine(it) || IsCommandSeparator(it) || IsCommandJoiner(it, end) ||
        IsStringLiteral(it));
}

TTokenContainer Tokenise(const TTranslationUnitPtr& t, bool Debug)
{
    TTokenContainer Tokens;
    CTranslationUnit::const_iterator TokenBegin;
    CTranslationUnit::const_iterator TokenEnd;
    bool JoinCommand = false;
    bool JustJoinedACommand = false;

    for(CTranslationUnit::const_iterator it = t->begin() ; it != t->end() ; )
    {
        if(IsWhitespace(it))
        {
            ++it;
            continue;
        }

        TokenBegin = it;

        // Error checking: it's not legal to have a command joiner that's not followed by a newline
        if(JoinCommand && !IsNewLine(it))
            throw CSyntaxException(CompileError_InvalidCommandJoinerMidLine, std::distance(t->begin(), TokenBegin), t);

        // It's illegal to have a command joiner followed by a blank line
        if(JustJoinedACommand && IsNewLine(it))
            throw CSyntaxException(CompileError_InvalidCommandJoinerEmptyLine, std::distance(t->begin(), TokenBegin), t);
        JustJoinedACommand = false;

        // Command separators, command joiners, and string literals act as both token delimiters and tokens themselves.
        // They need special treatment.
        if(IsNewLine(it) || IsCommandSeparator(it))
        {
            if(!JoinCommand) {
                // Is a command separator. Add to token list and continue.
                Tokens.push_back(SToken(std::distance(t->begin(), it), TokenType_StatementDelimiter));
            }
            else {
                JoinCommand = false;
                JustJoinedACommand = true;
            }
            ++it;
            continue;
        }
        else if(IsCommandJoiner(it, t->end()))
        {
            // This is a command joiner. Signal that we need to ignore the next newline.
            JoinCommand = true;
            it += 3;
            continue;
        }
        else if(IsStringLiteral(it))
        {
            // This is the beginning of a string literal. Scan through and find the end of the string literal.
            // String literal tokens don't include the quotes.
            ++it;
            TokenBegin = it;
            it = std::find(it, t->end(), '\"');

            if(it == t->end())
                throw CSyntaxException(CompileError_MissingStringLiteralEnd, std::distance(t->begin(), TokenBegin), t);

            // Add the string literal as a token
            Tokens.push_back(
                SToken(CString(TokenBegin-1, it+1), std::distance(t->begin(), TokenBegin), TokenType_StringLiteral)
                );
            ++it;
            continue;
        }
        else
        {
            // Not a "special" token. Search for end of token.
            ++it;
            while(it != t->end() && !IsTokenDelimiter(it, t->end()))
                ++it;
            TokenEnd = it;

            CString Lexeme(TokenBegin, TokenEnd);
            if(Lexeme == "BTW")
            {
                // Is a single-line comment
                // Find the next newline (or EOF), and that's when the comment ends
                // All we do here is skip the entire comment. Comments are useless as tokens as the parser will have
                // to just ignore them anyway.
                it = std::find(it, t->end(), '\n');
                continue;
            }
            else if(Lexeme == "OBTW")
            {
                // Is a multi-line comment
                // Find the next "TLDR", that's when the comment ends. If it's not found, that's an error.
                // Like single-line comments, we just discard multi-line comments right here.
                size_t Index = std::distance(t->begin(), it);
                size_t i = t->find("TLDR", Index);
                if(i == CTranslationUnit::npos)
                    throw CSyntaxException(CompileError_MissingCommentBlockEnd, Index, t);

                // Test for nesting
                size_t j = t->find("OBTW", Index + 1);
                if(j != CTranslationUnit::npos && j < i)
                    throw CSyntaxException(CompileError_NestedCommentBlock, Index, t);

                it = t->begin() + i + 4; // The +4 here is to pass over the "TLDR" as well.
                continue;
            }
            else
            {
                // This is a regular old token. Add it to the token list.
                Tokens.push_back(SToken(Lexeme, std::distance(t->begin(), it), TokenType_Other));
            }
            it = TokenEnd;
        }
    }
    return Tokens;
}