// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "TranslationUnit.h"

enum ETokenType
{
    TokenType_StringLiteral,

    // These are no longer used. The tokeniser now just discards comments as it comes across them.
    //TokenType_CommentSingle, // Single-line comment
    //TokenType_CommentMulti, // Multi-line comment

    TokenType_StatementDelimiter, // Separates statements
    TokenType_Other,
    TokenTypeCount
};

struct SToken
{
    CString Lexeme;
    ETokenType Type;
    size_t Index;

    SToken(const CString& Lexeme, size_t Index, ETokenType Type)
        : Lexeme(Lexeme), Index(Index), Type(Type) {}
    SToken(size_t Index, ETokenType Type)
        : Index(Index), Type(Type) {}
    SToken(const CString& Lexeme, ETokenType Type)
        : Lexeme(Lexeme), Index(0), Type(Type) {}
};
bool operator== (const SToken& lhs, const SToken& rhs);

typedef CArray<SToken> TTokenContainer;

// Expects that the translation unit has been preprocessed
TTokenContainer Tokenise(const TTranslationUnitPtr& t, bool Debug);
