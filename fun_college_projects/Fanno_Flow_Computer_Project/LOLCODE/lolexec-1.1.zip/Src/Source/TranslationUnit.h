// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include <boost/iterator/iterator_facade.hpp>

class CTranslationUnit
{
private:
    CString Path;
    const CString OriginalCode; // Never changes
    CString Code;

    // This maps between characters in the Code string to characters in the OriginalCode string.
    // The elements of this array are indices into the Code string.
    typedef CArray<size_t> TCodeRemap;
    TCodeRemap CodeRemap; // CodeRemap.size() == Code.length()

    // These just allow conversion between iterators
    TCodeRemap::iterator RemapIter(CString::iterator it);
    TCodeRemap::const_iterator RemapIter(CString::const_iterator it) const;

public:
    typedef CString::iterator iterator;
    typedef CString::const_iterator const_iterator;
    typedef CString::size_type size_type;
    static const size_type npos;

    explicit CTranslationUnit(const CString& OriginalCode, const CString& Path = "");

    const CString& GetPath() const;
    SLocation GetLocationFromIndex(size_t Index) const;

    char operator[] (int Index) const;

    iterator begin();
    const_iterator begin() const;
    iterator end();
    const_iterator end() const;

    bool empty() const;

    size_type find(const CString& str, size_type index = 0) const;
    size_type find(const char* str, size_type index = 0) const;
    size_type find(const char* str, size_type index, size_type length) const;
    size_type find(char ch, size_type index = 0) const;

    iterator erase(iterator loc);
    iterator erase(iterator start, iterator end);
    CTranslationUnit& erase(size_type index = 0, size_type num = npos);

    CTranslationUnit& insert(size_type index, const CString& str);
    template<typename InputIterator>
    void insert(iterator it, InputIterator start, InputIterator end)
    {
        assert(CodeRemap.size() == Code.length());
        size_t Index = std::distance(CodeRemap.begin(), RemapIter(it));
        CodeRemap.insert(RemapIter(it), std::distance(start, end), CodeRemap[Index]);
        Code.insert(it, start, end);
    }

    CTranslationUnit& replace(size_type index, size_type num, const CString& str);

    size_type length() const;
};
