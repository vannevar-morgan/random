// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "../Common.h"

#include "../TranslationUnit.h"
#include "../Tokeniser.h"
#include "../Preprocessor.h"
#include "../Parser.h"
#include "../Compiler.h"
#include "../VM.h"
#include "../Main.h"

#include <boost/tokenizer.hpp>

class CRuntimeFixture
{
private:
    class CRuntimeIO : public IRuntimeIO
    {
    private:
        CString Data;

    public:
        void Print(const CString& s) {
            Data += s;
        }
        CString Read() {
            throw CException("Error. User input not supported in automated tests.");
        }

        const CString& Get() const {return Data;}
        void Flush() {Data.clear();}
    };

    CVirtualMachine* VM;
    CRuntimeIO RuntimeIO;

protected:
    void Initialise()
    {
        VM = new CVirtualMachine(false);
        VM->SetRuntimeIO(&RuntimeIO);
    }
    void Release()
    {
        delete VM;
    }

    void ExecuteFile(const CString& Filename)
    {
        CString Code = ReadCodeFromFile(Filename);
        boost::shared_ptr<CTranslationUnit> TranslationUnit(new CTranslationUnit(Code, Filename));
        Preprocess(*TranslationUnit, false);
        TTokenContainer Tokens = Tokenise(TranslationUnit, false);
        CProgram Program = Parse(TranslationUnit, Tokens, false);
        CExecutable Executable = Compile(Program, false);
        VM->Execute(Executable);
    }

    // This ignores token indexes, and only takes into account lexemes and token types
    // Statement delimiters at the beginning of a file are ignored
    void TokeniseTest(const CString& Filename, const SToken* TokenArray, size_t TokenCount)
    {
        CString Code = ReadCodeFromFile(Filename + ".lol");
        boost::shared_ptr<CTranslationUnit> TranslationUnit(new CTranslationUnit(Code, Filename));
        Preprocess(*TranslationUnit, false);
        TTokenContainer Tokens = Tokenise(TranslationUnit, false);

        TTokenContainer::iterator it = Tokens.begin();
        while(it != Tokens.end() && it->Type == TokenType_StatementDelimiter)
            ++it;

        for(size_t i = 0 ; i < TokenCount ; ++i)
        {
            CPPUNIT_ASSERT(it != Tokens.end());
            CPPUNIT_ASSERT_EQUAL(TokenArray[i].Type, it->Type);
            if(it->Type != TokenType_StatementDelimiter) {
                CPPUNIT_ASSERT_EQUAL(TokenArray[i].Lexeme, it->Lexeme);
            }
            ++it;
        }

        while(it != Tokens.end() && it->Type == TokenType_StatementDelimiter)
            ++it;

        CPPUNIT_ASSERT(it == Tokens.end());
    }

    void ExecuteTest(const CString& TestName)
    {
        RuntimeIO.Flush();
        ExecuteFile(TestName + ".lol");
    }
    void ExecuteTest(const CString& TestName, const CString& Expected)
    {
        RuntimeIO.Flush();
        ExecuteFile(TestName + ".lol");
        CPPUNIT_ASSERT_EQUAL(Expected, RuntimeIO.Get());
    }
};