// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "../Common.h"

#include "../TranslationUnit.h"

class CTranslationUnitTest : public CppUnit::TestFixture
{
    CPPUNIT_TEST_SUITE(CTranslationUnitTest);

    // Test with just a regular unmodified translation unit
    CPPUNIT_TEST(TestIndexing);
    CPPUNIT_TEST(TestIterationDereference);
    CPPUNIT_TEST(TestIterationAddition);
    CPPUNIT_TEST(TestIterationSubtraction);
    CPPUNIT_TEST(TestIterationIncrement);
    CPPUNIT_TEST(TestIterationDecrement);
    CPPUNIT_TEST(TestLength);
    CPPUNIT_TEST(TestFind);

    // Test with a translation unit which has had stuff removed
    CPPUNIT_TEST(TestRemovalIndexing);
    CPPUNIT_TEST(TestRemovalIterationDereference);
    CPPUNIT_TEST(TestRemovalIterationAddition);
    CPPUNIT_TEST(TestRemovalIterationSubtraction);
    CPPUNIT_TEST(TestRemovalIterationIncrement);
    CPPUNIT_TEST(TestRemovalIterationDecrement);
    CPPUNIT_TEST(TestRemovalLength);
    CPPUNIT_TEST(TestRemovalFind);

    CPPUNIT_TEST(TestErasure1);
    CPPUNIT_TEST(TestErasure2);
    CPPUNIT_TEST(TestErasure3);
    CPPUNIT_TEST(TestInsert);
    CPPUNIT_TEST(TestReplace);

    CPPUNIT_TEST_SUITE_END();

private:
    const CTranslationUnit* t1;
    const CTranslationUnit* t2;

public:
    void setUp()
    {
        t1 = new CTranslationUnit("abc123123");

        // The same as t1, except stuff has been removed
        t2 = new CTranslationUnit("abc alpha beta charlie 123123");
        const_cast<CTranslationUnit*>(t2)->erase(3, 20);
    }

    void tearDown()
    {
        delete t1;
        delete t2;
    }

    // Basic iteration/indexing with just a regular unmodified translation unit
    void TestIndexing() {
        CPPUNIT_ASSERT_EQUAL('a', (*t1)[0]);
        CPPUNIT_ASSERT_EQUAL('b', (*t1)[1]);
    }
    void TestIterationDereference() {
        CTranslationUnit::const_iterator it = (*t1).begin();
        CPPUNIT_ASSERT_EQUAL('a', *it);
    }
    void TestIterationAddition() {
        CTranslationUnit::const_iterator it = (*t1).begin();
        it += 2;
        CPPUNIT_ASSERT_EQUAL('c', *it);
    }
    void TestIterationSubtraction() {
        CTranslationUnit::const_iterator it = (*t1).end();
        it -= 2;
        CPPUNIT_ASSERT_EQUAL('2', *it);
    }
    void TestIterationIncrement() {
        CTranslationUnit::const_iterator it = (*t1).begin();
        it++;
        CPPUNIT_ASSERT_EQUAL('b', *it);
    }
    void TestIterationDecrement() {
        CTranslationUnit::const_iterator it = (*t1).end();
        --it;
        CPPUNIT_ASSERT_EQUAL('3', *it);
    }
    void TestLength() {
        CPPUNIT_ASSERT_EQUAL((size_t)9, t1->length());
    }
    void TestFind() {
        CPPUNIT_ASSERT_EQUAL((size_t)3, t1->find('1'));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t1->find('1', 4));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t1->find('1', 7));

        CPPUNIT_ASSERT_EQUAL((size_t)3, t1->find("12"));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t1->find("12", 4));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t1->find("12", 7));

        CPPUNIT_ASSERT_EQUAL((size_t)3, t1->find("123456", 0, 2));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t1->find("123456", 4, 2));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t1->find("123456", 7, 2));

        CString str = "12";
        CPPUNIT_ASSERT_EQUAL((size_t)3, t1->find(str));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t1->find(str, 4));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t1->find(str, 7));
    }

    // Iteration/indexing with a translation unit which has had stuff removed
    void TestRemovalIndexing() {
        CPPUNIT_ASSERT_EQUAL('a', (*t2)[0]);
        CPPUNIT_ASSERT_EQUAL('b', (*t2)[1]);
    }
    void TestRemovalIterationDereference() {
        CTranslationUnit::const_iterator it = (*t2).begin();
        CPPUNIT_ASSERT_EQUAL('a', *it);
    }
    void TestRemovalIterationAddition() {
        CTranslationUnit::const_iterator it = (*t2).begin();
        it += 2;
        CPPUNIT_ASSERT_EQUAL('c', *it);
    }
    void TestRemovalIterationSubtraction() {
        CTranslationUnit::const_iterator it = (*t2).end();
        it -= 2;
        CPPUNIT_ASSERT_EQUAL('2', *it);
    }
    void TestRemovalIterationIncrement() {
        CTranslationUnit::const_iterator it = (*t2).begin();
        it++;
        CPPUNIT_ASSERT_EQUAL('b', *it);
    }
    void TestRemovalIterationDecrement() {
        CTranslationUnit::const_iterator it = (*t2).end();
        --it;
        CPPUNIT_ASSERT_EQUAL('3', *it);
    }
    void TestRemovalLength() {
        CPPUNIT_ASSERT_EQUAL((size_t)9, t2->length());
    }
    void TestRemovalFind() {
        CPPUNIT_ASSERT_EQUAL((size_t)3, t2->find('1'));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t2->find('1', 4));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t2->find('1', 7));

        CPPUNIT_ASSERT_EQUAL((size_t)3, t2->find("12"));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t2->find("12", 4));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t2->find("12", 7));

        CPPUNIT_ASSERT_EQUAL((size_t)3, t2->find("123456", 0, 2));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t2->find("123456", 4, 2));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t2->find("123456", 7, 2));

        CString str = "12";
        CPPUNIT_ASSERT_EQUAL((size_t)3, t2->find(str));
        CPPUNIT_ASSERT_EQUAL((size_t)6, t2->find(str, 4));
        CPPUNIT_ASSERT_EQUAL(CTranslationUnit::npos, t2->find(str, 7));
    }

    void TestErasure1() {
        CTranslationUnit t("abc123");
        t.erase(t.begin() + 1, t.end() - 1);
        CPPUNIT_ASSERT_EQUAL((size_t)2, t.length());
        CPPUNIT_ASSERT_EQUAL('a', t[0]);
        CPPUNIT_ASSERT_EQUAL('3', t[1]);
    }
    void TestErasure2() {
        CTranslationUnit t("abc");
        t.erase(t.begin() + 1);
        CPPUNIT_ASSERT_EQUAL((size_t)2, t.length());
        CPPUNIT_ASSERT_EQUAL('a', t[0]);
        CPPUNIT_ASSERT_EQUAL('c', t[1]);
    }
    void TestErasure3() {
        CTranslationUnit t("abc123");
        t.erase(1, 4);
        CPPUNIT_ASSERT_EQUAL((size_t)2, t.length());
        CPPUNIT_ASSERT_EQUAL('a', t[0]);
        CPPUNIT_ASSERT_EQUAL('3', t[1]);
    }
    void TestInsert() {
        CTranslationUnit t("a3");
        t.insert(1, "bc12");
        CPPUNIT_ASSERT_EQUAL((size_t)6, t.length());
        CPPUNIT_ASSERT_EQUAL('a', t[0]);
        CPPUNIT_ASSERT_EQUAL('b', t[1]);
        CPPUNIT_ASSERT_EQUAL('c', t[2]);
        CPPUNIT_ASSERT_EQUAL('1', t[3]);
        CPPUNIT_ASSERT_EQUAL('2', t[4]);
        CPPUNIT_ASSERT_EQUAL('3', t[5]);
    }
    void TestReplace() {
        {
            CTranslationUnit t("abcdef");
            t.replace(3, 3, "123");
            CPPUNIT_ASSERT_EQUAL((size_t)6, t.length());
            CPPUNIT_ASSERT_EQUAL('a', t[0]);
            CPPUNIT_ASSERT_EQUAL('b', t[1]);
            CPPUNIT_ASSERT_EQUAL('c', t[2]);
            CPPUNIT_ASSERT_EQUAL('1', t[3]);
            CPPUNIT_ASSERT_EQUAL('2', t[4]);
            CPPUNIT_ASSERT_EQUAL('3', t[5]);
        }
        {
            CTranslationUnit t("abx23");
            t.replace(2, 1, "c1");
            CPPUNIT_ASSERT_EQUAL((size_t)6, t.length());
            CPPUNIT_ASSERT_EQUAL('a', t[0]);
            CPPUNIT_ASSERT_EQUAL('b', t[1]);
            CPPUNIT_ASSERT_EQUAL('c', t[2]);
            CPPUNIT_ASSERT_EQUAL('1', t[3]);
            CPPUNIT_ASSERT_EQUAL('2', t[4]);
            CPPUNIT_ASSERT_EQUAL('3', t[5]);
        }
        {
            CTranslationUnit t("abXYZ23");
            t.replace(2, 3, "c1");
            CPPUNIT_ASSERT_EQUAL((size_t)6, t.length());
            CPPUNIT_ASSERT_EQUAL('a', t[0]);
            CPPUNIT_ASSERT_EQUAL('b', t[1]);
            CPPUNIT_ASSERT_EQUAL('c', t[2]);
            CPPUNIT_ASSERT_EQUAL('1', t[3]);
            CPPUNIT_ASSERT_EQUAL('2', t[4]);
            CPPUNIT_ASSERT_EQUAL('3', t[5]);
        }
        {
            CTranslationUnit t("abc\r\n123");
            t.replace(3, 2, "\n");
            CPPUNIT_ASSERT_EQUAL((size_t)7, t.length());
            CPPUNIT_ASSERT_EQUAL('a', t[0]);
            CPPUNIT_ASSERT_EQUAL('b', t[1]);
            CPPUNIT_ASSERT_EQUAL('c', t[2]);
            CPPUNIT_ASSERT_EQUAL('\n', t[3]);
            CPPUNIT_ASSERT_EQUAL('1', t[4]);
            CPPUNIT_ASSERT_EQUAL('2', t[5]);
            CPPUNIT_ASSERT_EQUAL('3', t[6]);
        }
    }
};
