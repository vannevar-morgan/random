// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "../Common.h"

#include "Runtime.h"

class CExecutionTest : public CppUnit::TestFixture, public CRuntimeFixture
{
    CPPUNIT_TEST_SUITE(CExecutionTest);

    CPPUNIT_TEST(TestSyntax1);
    CPPUNIT_TEST(TestSyntax2);
    CPPUNIT_TEST(TestSyntax3);
    CPPUNIT_TEST(TestSyntax4);
    CPPUNIT_TEST(TestSyntax5);
    CPPUNIT_TEST(TestSyntax6);
    CPPUNIT_TEST(TestSyntax7);
    CPPUNIT_TEST(TestSyntax8);
    CPPUNIT_TEST(TestSyntax9);
    CPPUNIT_TEST(TestSyntax10);
    /*CPPUNIT_TEST(TestSyntax11); // TODO: Write me
    CPPUNIT_TEST(TestSyntax12);
    CPPUNIT_TEST(TestSyntax13);
    CPPUNIT_TEST(TestSyntax14);
    CPPUNIT_TEST(TestSyntax15);
    CPPUNIT_TEST(TestSyntax16);
    CPPUNIT_TEST(TestSyntax17);*/

    CPPUNIT_TEST(TestConditionals1);
    CPPUNIT_TEST(TestConditionals2);
    CPPUNIT_TEST(TestConditionals3);
    CPPUNIT_TEST(TestConditionals4);
    CPPUNIT_TEST(TestConditionals5);
    CPPUNIT_TEST(TestConditionals6);
    CPPUNIT_TEST(TestConditionals7);

    CPPUNIT_TEST(TestFunctions1);
    CPPUNIT_TEST(TestFunctions2);
    CPPUNIT_TEST(TestFunctions3);
    CPPUNIT_TEST(TestFunctions4);
    CPPUNIT_TEST(TestFunctions5);
    CPPUNIT_TEST(TestFunctions6);
    CPPUNIT_TEST(TestFunctions7);
    CPPUNIT_TEST(TestFunctions8);

    CPPUNIT_TEST(TestLoops1);
    CPPUNIT_TEST(TestLoops2);
    CPPUNIT_TEST(TestLoops3);
    CPPUNIT_TEST(TestLoops4);
    CPPUNIT_TEST(TestLoops5);
    CPPUNIT_TEST(TestLoops6);
    CPPUNIT_TEST(TestLoops7);
    CPPUNIT_TEST(TestLoops8);
    CPPUNIT_TEST(TestLoops9);
    CPPUNIT_TEST(TestLoops10);
    CPPUNIT_TEST(TestLoops11);

    CPPUNIT_TEST(TestSwitch1);
    CPPUNIT_TEST(TestSwitch2);
    CPPUNIT_TEST(TestSwitch3);
    CPPUNIT_TEST(TestSwitch4);
    CPPUNIT_TEST(TestSwitch5);
    CPPUNIT_TEST(TestSwitch6);

    CPPUNIT_TEST(TestVisible1);
    CPPUNIT_TEST(TestVisible2);
    CPPUNIT_TEST(TestVisible3);
    CPPUNIT_TEST(TestVisible4);
    CPPUNIT_TEST(TestVisible5);
    CPPUNIT_TEST(TestVisible6);

    CPPUNIT_TEST(TestCast1);
    CPPUNIT_TEST(TestCast2);
    CPPUNIT_TEST(TestCast3);
    CPPUNIT_TEST(TestCast4);
    CPPUNIT_TEST(TestCast5);
    CPPUNIT_TEST(TestCast6);
    CPPUNIT_TEST(TestCast7);
    CPPUNIT_TEST(TestCast8);
    CPPUNIT_TEST(TestCast9);
    CPPUNIT_TEST(TestCast10);
    CPPUNIT_TEST(TestCast11);
    CPPUNIT_TEST(TestCast12);
    CPPUNIT_TEST(TestCast13);
    CPPUNIT_TEST(TestCast14);
    CPPUNIT_TEST(TestCast15);
    CPPUNIT_TEST(TestCast16);
    CPPUNIT_TEST(TestCast17);
    CPPUNIT_TEST(TestCast18);
    CPPUNIT_TEST(TestCast19);
    CPPUNIT_TEST(TestCast20);
    CPPUNIT_TEST(TestCast21);
    CPPUNIT_TEST(TestCast22);
    CPPUNIT_TEST(TestCast23);
    CPPUNIT_TEST(TestCast24);

    CPPUNIT_TEST(TestSmoosh1);
    CPPUNIT_TEST(TestSmoosh2);

    CPPUNIT_TEST(TestMath1);
    CPPUNIT_TEST(TestMath2);
    CPPUNIT_TEST(TestMath3);
    CPPUNIT_TEST(TestMath4);
    CPPUNIT_TEST(TestMath5);
    CPPUNIT_TEST(TestMath6);
    CPPUNIT_TEST(TestMath7);
    CPPUNIT_TEST(TestMath8);
    CPPUNIT_TEST(TestMath9);
    CPPUNIT_TEST(TestMath10);
    CPPUNIT_TEST(TestMath11);
    CPPUNIT_TEST(TestMath12);
    CPPUNIT_TEST(TestMath13);
    CPPUNIT_TEST(TestMath14);
    CPPUNIT_TEST(TestMath15);
    CPPUNIT_TEST(TestMath16);
    CPPUNIT_TEST(TestMath17);
    CPPUNIT_TEST(TestMath18);
    CPPUNIT_TEST(TestMath19);
    CPPUNIT_TEST(TestMath20);
    CPPUNIT_TEST(TestMath21);

    CPPUNIT_TEST(TestBooleanOp1);
    CPPUNIT_TEST(TestBooleanOp2);
    CPPUNIT_TEST(TestBooleanOp3);
    CPPUNIT_TEST(TestBooleanOp4);
    CPPUNIT_TEST(TestBooleanOp5);
    CPPUNIT_TEST(TestBooleanOp6);
    CPPUNIT_TEST(TestBooleanOp7);
    CPPUNIT_TEST(TestBooleanOp8);
    CPPUNIT_TEST(TestBooleanOp9);
    CPPUNIT_TEST(TestBooleanOp10);
    CPPUNIT_TEST(TestBooleanOp11);
    CPPUNIT_TEST(TestBooleanOp12);
    CPPUNIT_TEST(TestBooleanOp13);
    CPPUNIT_TEST(TestBooleanOp14);
    CPPUNIT_TEST(TestBooleanOp15);

    CPPUNIT_TEST_SUITE_END();

public:
    void setUp()
    {
        CRuntimeFixture::Initialise();
    }
    void tearDown()
    {
        CRuntimeFixture::Release();
    }

    void TestSyntax1() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other)
        };
        TokeniseTest("Syntax-1", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax2() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other)
        };
        TokeniseTest("Syntax-2", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax3() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
            SToken("KTHXBYE", TokenType_Other)
        };
        TokeniseTest("Syntax-3", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax4() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
            SToken("", TokenType_StatementDelimiter),
            SToken("KTHXBYE", TokenType_Other)
        };
        TokeniseTest("Syntax-4", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax5() {
        SToken Tokens[] = {
            SToken("\"HAI,...KTHXBYE\"", TokenType_StringLiteral),
            SToken("", TokenType_StatementDelimiter),
            SToken("HAI", TokenType_Other),
            SToken("NO", TokenType_Other),
            SToken("U", TokenType_Other)
        };
        TokeniseTest("Syntax-5", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax6() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
            SToken("KTHXBYE", TokenType_Other),
            SToken("", TokenType_StatementDelimiter),
            SToken("ORLY", TokenType_Other)
        };
        TokeniseTest("Syntax-6", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax7() {
        SToken Tokens[] = {
            SToken("\"Test BTW 123\"", TokenType_StringLiteral),
        };
        TokeniseTest("Syntax-7", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax8() {
        SToken Tokens[] = {
            SToken("\"Test OBTW 123\"", TokenType_StringLiteral),
        };
        TokeniseTest("Syntax-8", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax9() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-9", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax10() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-10", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax11() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-11", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax12() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-12", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax13() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-13", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax14() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-14", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax15() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-15", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax16() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-16", Tokens, sizeof(Tokens) / sizeof(SToken));
    }
    void TestSyntax17() {
        SToken Tokens[] = {
            SToken("HAI", TokenType_Other),
        };
        TokeniseTest("Syntax-17", Tokens, sizeof(Tokens) / sizeof(SToken));
    }

    void TestConditionals1() {
        ExecuteTest("Conditionals-1", "1\n");
    }
    void TestConditionals2() {
        ExecuteTest("Conditionals-2", "2\n");
    }
    void TestConditionals3() {
        ExecuteTest("Conditionals-3", "3\n");
    }
    void TestConditionals4() {
        ExecuteTest("Conditionals-4", "4\n");
    }
    void TestConditionals5() {
        ExecuteTest("Conditionals-5", "5\n");
    }
    void TestConditionals6() {
        ExecuteTest("Conditionals-6", "");
    }
    void TestConditionals7() {
        ExecuteTest("Conditionals-7", "2\n");
    }

    void TestFunctions1() {
        ExecuteTest("FunctionsTest-1", "1\n");
    }
    void TestFunctions2() {
        ExecuteTest("FunctionsTest-2", "1\n");
    }
    void TestFunctions3() {
        ExecuteTest("FunctionsTest-3", "6\n");
    }
    void TestFunctions4() {
        ExecuteTest("FunctionsTest-4", "6\n");
    }
    void TestFunctions5() {
        ExecuteTest("FunctionsTest-5", "5\n");
    }
    void TestFunctions6() {
        ExecuteTest("FunctionsTest-6", "FAIL\n");
    }
    void TestFunctions7() {
        ExecuteTest("FunctionsTest-7", "FAIL\nWIN\nWIN\nFAIL\n");
    }
    void TestFunctions8() {
        ExecuteTest("FunctionsTest-8", "10\n5\n16\n8\n4\n2\n");
    }

    void TestLoops1() {
        ExecuteTest("Loops-1", "0\n1\n2\n3\n4\n");
    }
    void TestLoops2() {
        ExecuteTest("Loops-2", "0\n1\n2\n3\n4\n");
    }
    void TestLoops3() {
        ExecuteTest("Loops-3", "0\n-1\n-2\n-3\n-4\n");
    }
    void TestLoops4() {
        ExecuteTest("Loops-4", "0\n1\n2\n3\n4\n");
    }
    void TestLoops5() {
        ExecuteTest("Loops-5", "0\n1\n2\n3\n4\n");
    }
    void TestLoops6() {
        ExecuteTest("Loops-6", "0\n-1\n-2\n-3\n-4\n");
    }
    void TestLoops7() {
        ExecuteTest("Loops-7", "0\n-1\n-2\n-3\n-4\n");
    }
    void TestLoops8() {
        ExecuteTest("Loops-8", "0\n2\n4\n6\n8\n");
    }
    void TestLoops9() {
        ExecuteTest("Loops-9", "0\n2\n4\n6\n8\n");
    }
    void TestLoops10() {
        ExecuteTest("Loops-10", "0\n2\n4\n6\n8\n");
    }
    void TestLoops11() {
        ExecuteTest("Loops-11", "0\n0\n1\n2\n1\n0\n1\n2\n2\n0\n1\n2\n");
    }

    void TestSwitch1() {
        ExecuteTest("Switch-1", "1\n");
    }
    void TestSwitch2() {
        ExecuteTest("Switch-2", "4\n3\n2\n");
    }
    void TestSwitch3() {
        ExecuteTest("Switch-3", "DEFAULT\n");
    }
    void TestSwitch4() {
        ExecuteTest("Switch-4", "3\n2\n1\nDEFAULT\n");
    }
    void TestSwitch5() {
        ExecuteTest("Switch-5", "");
    }
    void TestSwitch6() {
        ExecuteTest("Switch-6", "11\n");
    }

    void TestVisible1() {
        ExecuteTest("Visible-1", "1\n");
    }
    void TestVisible2() {
        ExecuteTest("Visible-2", "12345\n");
    }
    void TestVisible3() {
        ExecuteTest("Visible-3", "12\n");
    }
    void TestVisible4() {
        ExecuteTest("Visible-4", "1234\n");
    }
    void TestVisible5() {
        ExecuteTest("Visible-5", "12345\n");
    }
    void TestVisible6() {
        ExecuteTest("Visible-6", "1!\n2\n");
    }

    void TestCast1() {
        ExecuteTest("Cast-1", "0\n");
    }
    void TestCast2() {
        ExecuteTest("Cast-2", "0.00\n");
    }
    void TestCast3() {
        ExecuteTest("Cast-3", "FAIL\n");
    }
    void TestCast4() {
        ExecuteTest("Cast-4", "\n");
    }
    void TestCast5() {
        ExecuteTest("Cast-5", "FAIL\n");
    }
    void TestCast6() {
        ExecuteTest("Cast-6", "1\n");
    }
    void TestCast7() {
        ExecuteTest("Cast-7", "WIN\n");
    }
    void TestCast8() {
        ExecuteTest("Cast-8", "FAIL\n");
    }
    void TestCast9() {
        ExecuteTest("Cast-9", "1.50\n");
    }
    void TestCast10() {
        ExecuteTest("Cast-10", "FAIL\n");
    }
    void TestCast11() {
        ExecuteTest("Cast-11", "2.00\n");
    }
    void TestCast12() {
        ExecuteTest("Cast-12", "WIN\n");
    }
    void TestCast13() {
        ExecuteTest("Cast-13", "FAIL\n");
    }
    void TestCast14() {
        ExecuteTest("Cast-14", "1\n");
    }
    void TestCast15() {
        ExecuteTest("Cast-15", "FAIL\n");
    }
    void TestCast16() {
        ExecuteTest("Cast-16", "1\n");
    }
    void TestCast17() {
        ExecuteTest("Cast-17", "0\n");
    }
    void TestCast18() {
        ExecuteTest("Cast-18", "1.00\n");
    }
    void TestCast19() {
        ExecuteTest("Cast-19", "0.00\n");
    }
    void TestCast20() {
        ExecuteTest("Cast-20", "WIN\n");
    }
    void TestCast21() {
        ExecuteTest("Cast-21", "FAIL\n");
    }
    void TestCast22() {
        ExecuteTest("Cast-22", "1\n");
    }
    void TestCast23() {
        ExecuteTest("Cast-23", "WIN\n");
    }
    void TestCast24() {
        ExecuteTest("Cast-24", "WIN\n");
    }

    void TestSmoosh1() {
        ExecuteTest("Smoosh-1", "12345\n");
    }
    void TestSmoosh2() {
        ExecuteTest("Smoosh-2", "12345\n");
    }

    void TestMath1() {
        ExecuteTest("Math-1", "3\n");
    }
    void TestMath2() {
        ExecuteTest("Math-2", "3\n");
    }
    void TestMath3() {
        ExecuteTest("Math-3", "3.50\n");
    }
    void TestMath4() {
        ExecuteTest("Math-4", "1\n");
    }
    void TestMath5() {
        ExecuteTest("Math-5", "1\n");
    }
    void TestMath6() {
        ExecuteTest("Math-6", "1.50\n");
    }
    void TestMath7() {
        ExecuteTest("Math-7", "6\n");
    }
    void TestMath8() {
        ExecuteTest("Math-8", "6\n");
    }
    void TestMath9() {
        ExecuteTest("Math-9", "5.00\n");
    }
    void TestMath10() {
        ExecuteTest("Math-10", "3\n");
    }
    void TestMath11() {
        ExecuteTest("Math-11", "3\n");
    }
    void TestMath12() {
        ExecuteTest("Math-12", "2.50\n");
    }
    void TestMath13() {
        ExecuteTest("Math-13", "3\n");
    }
    void TestMath14() {
        ExecuteTest("Math-14", "3\n");
    }
    void TestMath15() {
        ExecuteTest("Math-15", "2.50\n");
    }
    void TestMath16() {
        ExecuteTest("Math-16", "3\n");
    }
    void TestMath17() {
        ExecuteTest("Math-17", "3\n");
    }
    void TestMath18() {
        ExecuteTest("Math-18", "3.50\n");
    }
    void TestMath19() {
        ExecuteTest("Math-19", "3\n");
    }
    void TestMath20() {
        ExecuteTest("Math-20", "3\n");
    }
    void TestMath21() {
        ExecuteTest("Math-21", "3.50\n");
    }

    void TestBooleanOp1() {
        ExecuteTest("BooleanOp-1", "WIN\nFAIL\nFAIL\nFAIL\n");
    }
    void TestBooleanOp2() {
        ExecuteTest("BooleanOp-2", "WIN\nFAIL\nFAIL\nFAIL\n");
    }
    void TestBooleanOp3() {
        ExecuteTest("BooleanOp-3", "WIN\nFAIL\nFAIL\nFAIL\n");
    }
    void TestBooleanOp4() {
        ExecuteTest("BooleanOp-4", "WIN\nWIN\nWIN\nFAIL\n");
    }
    void TestBooleanOp5() {
        ExecuteTest("BooleanOp-5", "WIN\nWIN\nWIN\nFAIL\n");
    }
    void TestBooleanOp6() {
        ExecuteTest("BooleanOp-6", "WIN\nWIN\nWIN\nFAIL\n");
    }
    void TestBooleanOp7() {
        ExecuteTest("BooleanOp-7", "FAIL\nWIN\nWIN\nFAIL\n");
    }
    void TestBooleanOp8() {
        ExecuteTest("BooleanOp-8", "FAIL\nWIN\nWIN\nFAIL\n");
    }
    void TestBooleanOp9() {
        ExecuteTest("BooleanOp-9", "FAIL\nWIN\nWIN\nFAIL\n");
    }
    void TestBooleanOp10() {
        ExecuteTest("BooleanOp-10", "FAIL\nWIN\n");
    }
    void TestBooleanOp11() {
        ExecuteTest("BooleanOp-11", "FAIL\nWIN\n");
    }
    void TestBooleanOp12() {
        ExecuteTest("BooleanOp-12", "WIN\nFAIL\n");
    }
    void TestBooleanOp13() {
        ExecuteTest("BooleanOp-13", "WIN\nFAIL\n");
    }
    void TestBooleanOp14() {
        ExecuteTest("BooleanOp-14", "WIN\nFAIL\n");
    }
    void TestBooleanOp15() {
        ExecuteTest("BooleanOp-15", "WIN\nFAIL\n");
    }
};
