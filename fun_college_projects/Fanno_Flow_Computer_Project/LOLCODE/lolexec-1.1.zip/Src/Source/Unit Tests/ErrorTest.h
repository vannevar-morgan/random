// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "../Common.h"

#include "../TranslationUnit.h"
#include "../Tokeniser.h"
#include "../Preprocessor.h"
#include "../Parser.h"
#include "../Compiler.h"
#include "../VM.h"
#include "../Main.h"
#include "Runtime.h"

#include <boost/lexical_cast.hpp>

class CErrorTest : public CppUnit::TestFixture, public CRuntimeFixture
{
    CPPUNIT_TEST_SUITE(CErrorTest);

    CPPUNIT_TEST_EXCEPTION(TestC1001_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC1002_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC1003_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC1004_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC1005_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2001_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2001_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2001_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2001_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2002_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2003_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2103_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2204_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2204_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2204_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2205_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2205_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2205_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2205_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2206_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2207_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2208_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_5, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_6, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2301_7, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2303_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2303_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2304_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2304_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2304_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC2304_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3001_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3001_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3002_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3003_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3003_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3004_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3004_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3004_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3004_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3005_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC3005_2, CCompileException);

    CPPUNIT_TEST_EXCEPTION(TestC4001_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_5, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_6, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_7, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_8, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_9, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_10, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_11, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_12, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_13, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_14, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_15, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_16, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_17, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_18, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_19, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_20, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_21, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_22, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_23, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_24, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_25, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4001_26, CCompileException);

    CPPUNIT_TEST_EXCEPTION(TestC4002_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_4, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_5, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_6, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_7, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_8, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_9, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_10, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_11, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_12, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_13, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_14, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_15, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_16, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_17, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_18, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_19, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_20, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_21, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_22, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4002_23, CCompileException);

    CPPUNIT_TEST_EXCEPTION(TestC4003_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4005_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4005_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4005_3, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4007_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4007_2, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4008_1, CCompileException);
    CPPUNIT_TEST_EXCEPTION(TestC4013_1, CCompileException);

    CPPUNIT_TEST_SUITE_END();

private:
    void ExecuteCompileErrorTest(const CString& TestName, ECompileError Expected)
    {
        try
        {
            ExecuteTest("Errors/" + TestName);
        }
        catch(const CCompileException& e)
        {
            if(Expected != e.GetErrorCode())
            {
                using boost::lexical_cast;
                CString Message = "Expected: Compile Error C" + lexical_cast<CString>(Expected) + ": " +
                    GetCompileErrorDesc(Expected) + "\n  Actual  : " + e.what();
                CPPUNIT_FAIL(Message.c_str());
            }
            throw;
        }
    }

public:
    void setUp()
    {
        CRuntimeFixture::Initialise();
    }
    void tearDown()
    {
        CRuntimeFixture::Release();
    }

    void TestC1001_1() {
        ExecuteCompileErrorTest("C1001-1", CompileError_MissingCommentBlockEnd);
    }
    void TestC1002_1() {
        ExecuteCompileErrorTest("C1002-1", CompileError_NestedCommentBlock);
    }
    void TestC1003_1() {
        ExecuteCompileErrorTest("C1003-1", CompileError_MissingStringLiteralEnd);
    }
    void TestC1004_1() {
        ExecuteCompileErrorTest("C1004-1", CompileError_InvalidCommandJoinerMidLine);
    }
    void TestC1005_1() {
        ExecuteCompileErrorTest("C1005-1", CompileError_InvalidCommandJoinerEmptyLine);
    }
    void TestC2001_1() {
        ExecuteCompileErrorTest("C2001-1", CompileError_MissingLoopEnd);
    }
    void TestC2001_2() {
        ExecuteCompileErrorTest("C2001-2", CompileError_MissingLoopEnd);
    }
    void TestC2001_3() {
        ExecuteCompileErrorTest("C2001-3", CompileError_MissingLoopEnd);
    }
    void TestC2001_4() {
        ExecuteCompileErrorTest("C2001-4", CompileError_MissingLoopEnd);
    }
    void TestC2002_1() {
        ExecuteCompileErrorTest("C2002-1", CompileError_UnknownLoopConstruct);
    }
    void TestC2003_1() {
        ExecuteCompileErrorTest("C2003-1", CompileError_MissingLoopLabel);
    }
    void TestC2103_1() {
        ExecuteCompileErrorTest("C2103-1", CompileError_MissingIfBlockEnd);
    }
    void TestC2204_1() {
        ExecuteCompileErrorTest("C2204-1", CompileError_MissingCaseBlockEnd);
    }
    void TestC2204_2() {
        ExecuteCompileErrorTest("C2204-2", CompileError_MissingCaseBlockEnd);
    }
    void TestC2204_3() {
        ExecuteCompileErrorTest("C2204-3", CompileError_MissingCaseBlockEnd);
    }
    void TestC2205_1() {
        ExecuteCompileErrorTest("C2205-1", CompileError_MissingCaseLabel);
    }
    void TestC2205_2() {
        ExecuteCompileErrorTest("C2205-2", CompileError_MissingCaseLabel);
    }
    void TestC2205_3() {
        ExecuteCompileErrorTest("C2205-3", CompileError_MissingCaseLabel);
    }
    void TestC2205_4() {
        ExecuteCompileErrorTest("C2205-4", CompileError_MissingCaseLabel);
    }
    void TestC2206_1() {
        ExecuteCompileErrorTest("C2206-1", CompileError_CaseLabelInterpolation);
    }
    void TestC2207_1() {
        ExecuteCompileErrorTest("C2207-1", CompileError_CaseLabelIsVar);
    }
    void TestC2208_1() {
        ExecuteCompileErrorTest("C2208-1", CompileError_DuplicateCaseLabel);
    }
    void TestC2301_1() {
        ExecuteCompileErrorTest("C2301-1", CompileError_MissingFunctionEnd);
    }
    void TestC2301_2() {
        ExecuteCompileErrorTest("C2301-2", CompileError_MissingFunctionEnd);
    }
    void TestC2301_3() {
        ExecuteCompileErrorTest("C2301-3", CompileError_MissingFunctionEnd);
    }
    void TestC2301_4() {
        ExecuteCompileErrorTest("C2301-4", CompileError_MissingFunctionEnd);
    }
    void TestC2301_5() {
        ExecuteCompileErrorTest("C2301-5", CompileError_MissingFunctionEnd);
    }
    void TestC2301_6() {
        ExecuteCompileErrorTest("C2301-6", CompileError_MissingFunctionEnd);
    }
    void TestC2301_7() {
        ExecuteCompileErrorTest("C2301-7", CompileError_MissingFunctionEnd);
    }
    void TestC2303_1() {
        ExecuteCompileErrorTest("C2303-1", CompileError_MultipleFunctionDefinition);
    }
    void TestC2303_2() {
        ExecuteCompileErrorTest("C2303-2", CompileError_MultipleFunctionDefinition);
    }
    void TestC2304_1() {
        ExecuteCompileErrorTest("C2304-1", CompileError_NestedFunction);
    }
    void TestC2304_2() {
        ExecuteCompileErrorTest("C2304-2", CompileError_NestedFunction);
    }
    void TestC2304_3() {
        ExecuteCompileErrorTest("C2304-3", CompileError_NestedFunction);
    }
    void TestC2304_4() {
        ExecuteCompileErrorTest("C2304-4", CompileError_NestedFunction);
    }
    void TestC3001_1() {
        ExecuteCompileErrorTest("C3001-1", CompileError_InvalidVariableDeclaration);
    }
    void TestC3001_2() {
        ExecuteCompileErrorTest("C3001-2", CompileError_InvalidVariableDeclaration);
    }
    void TestC3002_1() {
        ExecuteCompileErrorTest("C3002-1", CompileError_VariableNotFound);
    }
    void TestC3003_1() {
        ExecuteCompileErrorTest("C3003-1", CompileError_VarNameInUse);
    }
    void TestC3003_2() {
        ExecuteCompileErrorTest("C3003-2", CompileError_VarNameInUse);
    }
    void TestC3004_1() {
        ExecuteCompileErrorTest("C3004-1", CompileError_InvalidVarName);
    }
    void TestC3004_2() {
        ExecuteCompileErrorTest("C3004-2", CompileError_InvalidVarName);
    }
    void TestC3004_3() {
        ExecuteCompileErrorTest("C3004-3", CompileError_InvalidVarName);
    }
    void TestC3004_4() {
        ExecuteCompileErrorTest("C3004-4", CompileError_InvalidVarName);
    }
    void TestC3005_1() {
        ExecuteCompileErrorTest("C3005-1", CompileError_VarNameKeywordConflict);
    }
    void TestC3005_2() {
        ExecuteCompileErrorTest("C3005-2", CompileError_VarNameKeywordConflict);
    }
    void TestC4001_1() {
        ExecuteCompileErrorTest("C4001-1", CompileError_UnexpectedSyntax);
    }
    void TestC4001_2() {
        ExecuteCompileErrorTest("C4001-2", CompileError_UnexpectedSyntax);
    }
    void TestC4001_3() {
        ExecuteCompileErrorTest("C4001-3", CompileError_UnexpectedSyntax);
    }
    void TestC4001_4() {
        ExecuteCompileErrorTest("C4001-4", CompileError_UnexpectedSyntax);
    }
    void TestC4001_5() {
        ExecuteCompileErrorTest("C4001-5", CompileError_UnexpectedSyntax);
    }
    void TestC4001_6() {
        ExecuteCompileErrorTest("C4001-6", CompileError_UnexpectedSyntax);
    }
    void TestC4001_7() {
        ExecuteCompileErrorTest("C4001-7", CompileError_UnexpectedSyntax);
    }
    void TestC4001_8() {
        ExecuteCompileErrorTest("C4001-8", CompileError_UnexpectedSyntax);
    }
    void TestC4001_9() {
        ExecuteCompileErrorTest("C4001-9", CompileError_UnexpectedSyntax);
    }
    void TestC4001_10() {
        ExecuteCompileErrorTest("C4001-10", CompileError_UnexpectedSyntax);
    }
    void TestC4001_11() {
        ExecuteCompileErrorTest("C4001-11", CompileError_UnexpectedSyntax);
    }
    void TestC4001_12() {
        ExecuteCompileErrorTest("C4001-12", CompileError_UnexpectedSyntax);
    }
    void TestC4001_13() {
        ExecuteCompileErrorTest("C4001-13", CompileError_UnexpectedSyntax);
    }
    void TestC4001_14() {
        ExecuteCompileErrorTest("C4001-14", CompileError_UnexpectedSyntax);
    }
    void TestC4001_15() {
        ExecuteCompileErrorTest("C4001-15", CompileError_UnexpectedSyntax);
    }
    void TestC4001_16() {
        ExecuteCompileErrorTest("C4001-16", CompileError_UnexpectedSyntax);
    }
    void TestC4001_17() {
        ExecuteCompileErrorTest("C4001-17", CompileError_UnexpectedSyntax);
    }
    void TestC4001_18() {
        ExecuteCompileErrorTest("C4001-18", CompileError_UnexpectedSyntax);
    }
    void TestC4001_19() {
        ExecuteCompileErrorTest("C4001-19", CompileError_UnexpectedSyntax);
    }
    void TestC4001_20() {
        ExecuteCompileErrorTest("C4001-20", CompileError_UnexpectedSyntax);
    }
    void TestC4001_21() {
        ExecuteCompileErrorTest("C4001-21", CompileError_UnexpectedSyntax);
    }
    void TestC4001_22() {
        ExecuteCompileErrorTest("C4001-22", CompileError_UnexpectedSyntax);
    }
    void TestC4001_23() {
        ExecuteCompileErrorTest("C4001-23", CompileError_UnexpectedSyntax);
    }
    void TestC4001_24() {
        ExecuteCompileErrorTest("C4001-24", CompileError_UnexpectedSyntax);
    }
    void TestC4001_25() {
        ExecuteCompileErrorTest("C4001-25", CompileError_UnexpectedSyntax);
    }
    void TestC4001_26() {
        ExecuteCompileErrorTest("C4001-26", CompileError_UnexpectedSyntax);
    }
    void TestC4002_1() {
        ExecuteCompileErrorTest("C4002-1", CompileError_MissingArg);
    }
    void TestC4002_2() {
        ExecuteCompileErrorTest("C4002-2", CompileError_MissingArg);
    }
    void TestC4002_3() {
        ExecuteCompileErrorTest("C4002-3", CompileError_MissingArg);
    }
    void TestC4002_4() {
        ExecuteCompileErrorTest("C4002-4", CompileError_MissingArg);
    }
    void TestC4002_5() {
        ExecuteCompileErrorTest("C4002-5", CompileError_MissingArg);
    }
    void TestC4002_6() {
        ExecuteCompileErrorTest("C4002-6", CompileError_MissingArg);
    }
    void TestC4002_7() {
        ExecuteCompileErrorTest("C4002-7", CompileError_MissingArg);
    }
    void TestC4002_8() {
        ExecuteCompileErrorTest("C4002-8", CompileError_MissingArg);
    }
    void TestC4002_9() {
        ExecuteCompileErrorTest("C4002-9", CompileError_MissingArg);
    }
    void TestC4002_10() {
        ExecuteCompileErrorTest("C4002-10", CompileError_MissingArg);
    }
    void TestC4002_11() {
        ExecuteCompileErrorTest("C4002-11", CompileError_MissingArg);
    }
    void TestC4002_12() {
        ExecuteCompileErrorTest("C4002-12", CompileError_MissingArg);
    }
    void TestC4002_13() {
        ExecuteCompileErrorTest("C4002-13", CompileError_MissingArg);
    }
    void TestC4002_14() {
        ExecuteCompileErrorTest("C4002-14", CompileError_MissingArg);
    }
    void TestC4002_15() {
        ExecuteCompileErrorTest("C4002-15", CompileError_MissingArg);
    }
    void TestC4002_16() {
        ExecuteCompileErrorTest("C4002-16", CompileError_MissingArg);
    }
    void TestC4002_17() {
        ExecuteCompileErrorTest("C4002-17", CompileError_MissingArg);
    }
    void TestC4002_18() {
        ExecuteCompileErrorTest("C4002-18", CompileError_MissingArg);
    }
    void TestC4002_19() {
        ExecuteCompileErrorTest("C4002-19", CompileError_MissingArg);
    }
    void TestC4002_20() {
        ExecuteCompileErrorTest("C4002-20", CompileError_MissingArg);
    }
    void TestC4002_21() {
        ExecuteCompileErrorTest("C4002-21", CompileError_MissingArg);
    }
    void TestC4002_22() {
        ExecuteCompileErrorTest("C4002-22", CompileError_MissingArg);
    }
    void TestC4002_23() {
        ExecuteCompileErrorTest("C4002-23", CompileError_MissingArg);
    }
    void TestC4003_1() {
        ExecuteCompileErrorTest("C4003-1", CompileError_MissingExpression);
    }
    void TestC4005_1() {
        ExecuteCompileErrorTest("C4005-1", CompileError_NotEnoughArgs);
    }
    void TestC4005_2() {
        ExecuteCompileErrorTest("C4005-2", CompileError_NotEnoughArgs);
    }
    void TestC4005_3() {
        ExecuteCompileErrorTest("C4005-3", CompileError_NotEnoughArgs);
    }
    void TestC4007_1() {
        ExecuteCompileErrorTest("C4007-1", CompileError_NoEntryPoint);
    }
    void TestC4007_2() {
        ExecuteCompileErrorTest("C4007-2", CompileError_NoEntryPoint);
    }
    void TestC4008_1() {
        ExecuteCompileErrorTest("C4008-1", CompileError_InvalidBreak);
    }
    void TestC4013_1() {
        ExecuteCompileErrorTest("C4013-1", CompileError_InvalidType);
    }
};
