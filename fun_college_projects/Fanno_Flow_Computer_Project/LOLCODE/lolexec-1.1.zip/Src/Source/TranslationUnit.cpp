// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "TranslationUnit.h"
#include "Errors.h"
#include <algorithm>

// Convenience
typedef CTranslationUnit::iterator iterator;
typedef CTranslationUnit::const_iterator const_iterator;
typedef CTranslationUnit::size_type size_type;

const size_type CTranslationUnit::npos = CString::npos;

CTranslationUnit::CTranslationUnit(const CString& OriginalCode, const CString& Path)
    : OriginalCode(OriginalCode), Code(OriginalCode), Path(Path)
{
    CodeRemap.resize(Code.length());

    for(size_t i = 0 ; i < Code.length() ; ++i)
    {
        CodeRemap[i] = i;
    }
}

const CString& CTranslationUnit::GetPath() const
{
    return Path;
}

SLocation CTranslationUnit::GetLocationFromIndex(size_t Index) const
{
    SLocation Loc = {1,1};

    if(CodeRemap.empty())
        return Loc;
    Index = std::min(Index, CodeRemap.size() - 1);
    size_t OriginalIndex = CodeRemap[Index];

    for(size_t i = 0 ; i < OriginalIndex ; ++i)
    {
        if(OriginalCode[i] == '\n') {
            Loc.Column = 1;
            ++Loc.Row;
        }
        else
            ++Loc.Column;
    }
    return Loc;
}

CTranslationUnit::TCodeRemap::iterator CTranslationUnit::RemapIter(CString::iterator it)
{
    assert(CodeRemap.size() == Code.length());
    return (std::distance(Code.begin(), it) + CodeRemap.begin());
}
CTranslationUnit::TCodeRemap::const_iterator CTranslationUnit::RemapIter(CString::const_iterator it) const
{
    assert(CodeRemap.size() == Code.length());
    return (std::distance(Code.begin(), it) + CodeRemap.begin());
}

char CTranslationUnit::operator[] (int Index) const
{
    assert(CodeRemap.size() == Code.length());
    return Code[Index];
}

iterator CTranslationUnit::begin()
{
    assert(CodeRemap.size() == Code.length());
    return Code.begin();
}
const_iterator CTranslationUnit::begin() const
{
    assert(CodeRemap.size() == Code.length());
    return Code.begin();
}
iterator CTranslationUnit::end()
{
    assert(CodeRemap.size() == Code.length());
    return Code.end();
}
const_iterator CTranslationUnit::end() const
{
    assert(CodeRemap.size() == Code.length());
    return Code.end();
}

iterator CTranslationUnit::erase(iterator loc)
{
    assert(CodeRemap.size() == Code.length());
    CodeRemap.erase(RemapIter(loc));
    return Code.erase(loc);
}
iterator CTranslationUnit::erase(iterator start, iterator end)
{
    assert(CodeRemap.size() == Code.length());
    CodeRemap.erase(RemapIter(start), RemapIter(end));
    return Code.erase(start, end);
}
CTranslationUnit& CTranslationUnit::erase(size_type index, size_type num)
{
    assert(CodeRemap.size() == Code.length());
    iterator it = begin() + index;
    erase(it, it + num);
    return *this;
}

bool CTranslationUnit::empty() const
{
    assert(CodeRemap.size() == Code.length());
    return Code.empty();
}

size_type CTranslationUnit::length() const
{
    assert(CodeRemap.size() == Code.length());
    return Code.length();
}

size_type CTranslationUnit::find(const CString& str, size_type index) const
{
    assert(CodeRemap.size() == Code.length());
    return Code.find(str, index);
}
size_type CTranslationUnit::find(const char* str, size_type index) const
{
    assert(CodeRemap.size() == Code.length());
    return Code.find(str, index);
}
size_type CTranslationUnit::find(const char* str, size_type index, size_type count) const
{
    assert(CodeRemap.size() == Code.length());
    return Code.find(str, index, count);
}
size_type CTranslationUnit::find(char ch, size_type index) const
{
    assert(CodeRemap.size() == Code.length());
    return Code.find(ch, index);
}

CTranslationUnit& CTranslationUnit::insert(size_type index, const CString& str)
{
    assert(CodeRemap.size() == Code.length());
    CodeRemap.insert(CodeRemap.begin() + index, str.length(), CodeRemap[index]);
    Code.insert(index, str);
    return *this;
}

CTranslationUnit& CTranslationUnit::replace(size_type index, size_type num, const CString& str)
{
    TCodeRemap::iterator Start = CodeRemap.begin() + index;
    if(str.length() < num)
    {
        // Need to erase some elements from CodeRemap
        CodeRemap.erase(Start + str.length(), Start + num);
    }
    else if(str.length() > num)
    {
        // Need to add elements to CodeRemap
        CodeRemap.insert(Start + num, str.length() - num, CodeRemap[index + num]);
    }
    Code.replace(index, num, str);
    return *this;
}