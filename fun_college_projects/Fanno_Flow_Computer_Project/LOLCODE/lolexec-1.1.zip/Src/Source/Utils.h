// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"

void FindAndReplaceAll(const CString& ToFind, const CString& Replacement, CString& Source);


enum ERValueType
{
    RValueType_IntegerLiteral,
    RValueType_FloatLiteral,
    RValueType_BooleanLiteral,
    RValueType_StringLiteral,
    RValueType_Variable,
    RValueTypeCount
};

// Performs no validation at all (is just a dumb check)
ERValueType DetermineRValueType(const SValue& v);

int ParseInteger(const SValue& v, size_t Index, const TTranslationUnitPtr& t);
double ParseFloat(const SValue& v, size_t Index, const TTranslationUnitPtr& t);
bool ParseBool(const SValue& v, size_t Index, const TTranslationUnitPtr& t);
CString ParseString(const SValue& v, size_t Index, const TTranslationUnitPtr& t);
void ValidateVariableName(const CString& Name, size_t Index, const TTranslationUnitPtr& t);

// Converts a string to a RuntimeVarType. Throws if none match.
ERuntimeVarType GetRuntimeVarType(const CString& TypeName, size_t Index, const TTranslationUnitPtr& TranslationUnit);
