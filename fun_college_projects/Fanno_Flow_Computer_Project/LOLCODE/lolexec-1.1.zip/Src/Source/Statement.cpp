// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Statement.h"
#include "Errors.h"
#include "Compiler.h"
#include "Expression.h"
#include "LoopConstructs.h"
#include "Function.h"
#include "SwitchStatement.h"

using boost::intrusive_ptr;

void CStatement::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    // Nothing (by default)
}

void CVisibleStatement::Emit(CEmitContext& ec) const
{
    foreach(const intrusive_ptr<CExpression>& e, Arguments)
    {
        e->Emit(ec);
        ec.AddInstruction(intrusive_ptr<SPrintInstruction>(new SPrintInstruction()));
    }
}

void CConsoleInputExpression::Emit(CEmitContext& ec) const
{
    // Wait for input
    ec.AddInstruction(intrusive_ptr<SKeyboardInputInstruction>(new SKeyboardInputInstruction()));

    // Store into var
    size_t VarIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(VarIndex)));
}

void CImportStatement::Emit(CEmitContext& ec) const
{
    // Nothing
}

void CDeclareVarStatement::Emit(CEmitContext &ec) const
{
    if(InitialValue != NULL)
    {
        InitialValue->Emit(ec);
        size_t VarIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);
        ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(VarIndex)));
    }
    else
    {
        ec.AddInstruction(intrusive_ptr<SLoadUntypedInstruction>(new SLoadUntypedInstruction()));
    }
}

void CDeclareVarStatement::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    // Ensure that the parent block has already been added
    assert(VarMap.find(Parent) != VarMap.end());

    ValidateVariableName(VarName, Index, TranslationUnit);

    // Ensure that this variable name is not already in use
    if(VarMap[Parent].find(VarName) != VarMap[Parent].end())
        throw CSyntaxException(CompileError_VarNameInUse, Index, TranslationUnit);

    VarMap[Parent][VarName] = CurrentIndex;
    ++CurrentIndex;
}

void CAssignVarStatement::Emit(CEmitContext &ec) const
{
    Arg->Emit(ec);
    size_t DestIndex = ec.GetVarIndex(VarName, Parent, Index, TranslationUnit);
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(DestIndex)));
}

void CBreakStatement::Emit(CEmitContext& ec) const
{
    // Keep looking up parents until we find one that's a loop, switch statement, or function
    // If none is found, that means that there is nothing to break out of
    intrusive_ptr<const CBlock> p = Parent;
    bool IsFunction;
    while(true)
    {
        if(boost::dynamic_pointer_cast<const CSimpleLoop>(p) != NULL ||
            boost::dynamic_pointer_cast<const CSwitchStatement>(p) != NULL)
        {
            IsFunction = false;
            break;
        }
        else if(boost::dynamic_pointer_cast<const CFunction>(p) != NULL)
        {
            IsFunction = true;
            break;
        }
        p = p->Parent;
        if(p == NULL)
        {
            // Nothing to break out of
            throw CSyntaxException(CompileError_InvalidBreak, Index, TranslationUnit);
        }
    }

    // Functions need to return, not jump
    if(IsFunction)
    {
        intrusive_ptr<const CFunction> pf = boost::dynamic_pointer_cast<const CFunction>(p);
        size_t NumArgs = pf->Arguments.size();

        // Store untyped var into return field
        ec.AddInstruction(intrusive_ptr<SLoadUntypedInstruction>(new SLoadUntypedInstruction()));
        ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(-NumArgs - 1)));

        // Emit return instruction
        ec.AddInstruction(intrusive_ptr<SReturnInstruction>(new SReturnInstruction()));
    }
    else
    {
        intrusive_ptr<SJumpInstruction> JumpInstr(new SJumpInstruction(0));
        ec.RegisterJumpContext(ec.GetInstructionCount(), JumpInstr, p);
        ec.AddInstruction(JumpInstr);
    }
}

void CReturnStatement::Emit(CEmitContext& ec) const
{
    // Evaluate expression
    Arg->Emit(ec);

    intrusive_ptr<const CBlock> p = Parent;
    assert(p != NULL);
    while(p->Parent != NULL)
        p = p->Parent;

    intrusive_ptr<const CFunction> pf = boost::dynamic_pointer_cast<const CFunction>(p);

    size_t NumArgs = 0;
    if(pf != NULL)
    {
        NumArgs = pf->Arguments.size();
    }

    // Copy var into function return var
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(-NumArgs - 1)));

    // Emit return instruction
    ec.AddInstruction(intrusive_ptr<SReturnInstruction>(new SReturnInstruction()));
}