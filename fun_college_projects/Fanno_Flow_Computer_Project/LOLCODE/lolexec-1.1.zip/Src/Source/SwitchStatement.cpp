// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "SwitchStatement.h"
#include "Errors.h"
#include "Compiler.h"
#include "Expression.h"

void CSwitchStatement::Emit(CEmitContext& ec) const
{
    using boost::intrusive_ptr;
    InstrStartIndex = ec.GetInstructionCount();

    foreach(const SCase& c, Cases)
    {
        // Push IT onto the stack
        ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(ITVarIndex)));

        // Push case label onto the stack (must be a literal)
        switch(DetermineRValueType(c.Label))
        {
        case RValueType_IntegerLiteral:
            {
                int v = ParseInteger(c.Label, Index, TranslationUnit);
                ec.AddInstruction(intrusive_ptr<SLoadIntegerInstruction>(new SLoadIntegerInstruction(v)));
            } break;
        case RValueType_FloatLiteral:
            {
                double v = ParseFloat(c.Label, Index, TranslationUnit);
                ec.AddInstruction(intrusive_ptr<SLoadFloatInstruction>(new SLoadFloatInstruction(v)));
            } break;
        case RValueType_BooleanLiteral:
            {
                bool v = ParseBool(c.Label, Index, TranslationUnit);
                ec.AddInstruction(intrusive_ptr<SLoadBooleanInstruction>(new SLoadBooleanInstruction(v)));
            } break;
        case RValueType_StringLiteral:
            {
                CString v = ParseString(c.Label, Index, TranslationUnit);

                // Search for variable interpolation
                size_t Start = v.find(":{");
                if(Start != CString::npos) // Variable interpolation is not allowed in case labels
                    throw CSyntaxException(CompileError_CaseLabelInterpolation, Index, TranslationUnit);

                ec.AddInstruction(intrusive_ptr<SLoadStringInstruction>(new SLoadStringInstruction(v)));
            } break;
        case RValueType_Variable:
            // Error, must be a literal
            throw CSyntaxException(CompileError_CaseLabelIsVar, Index, TranslationUnit);
            break;
        default:
            throw CException("Unknown rvalue type.");
        }

        // Emit instruction to compare label and IT
        ec.AddInstruction(intrusive_ptr<SEqualsInstruction>(new SEqualsInstruction()));

        // Emit jump instruction
        intrusive_ptr<SJumpEqualInstruction> JumpInstr(new SJumpEqualInstruction(0));
        ec.RegisterJumpContext(ec.GetInstructionCount(), JumpInstr, c.Block, true);
        ec.AddInstruction(JumpInstr);
    }

    if(DefaultCase != NULL)
    {
        // Emit instruction to jump to default case
        intrusive_ptr<SJumpInstruction> JumpInstr(new SJumpInstruction(0));
        ec.RegisterJumpContext(ec.GetInstructionCount(), JumpInstr, DefaultCase, true);
        ec.AddInstruction(JumpInstr);
    }

    // Emit all case blocks IN ORDER, one after another. This is important, otherwise case fallthrough won't work
    // properly.
    foreach(const SCase& c, Cases)
    {
        c.Block->Emit(ec);
    }

    // Emit default case
    if(DefaultCase != NULL)
        DefaultCase->Emit(ec);

    InstrEndIndex = ec.GetInstructionCount();
}
void CSwitchStatement::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    // Resolve normally
    CBlock::ResolveVars(VarMap, CurrentIndex);

    // Resolve blocks
    foreach(const SCase& c, Cases)
    {
        c.Block->ResolveVars(VarMap, CurrentIndex);
    }
    if(DefaultCase != NULL) // default case is optional
        DefaultCase->ResolveVars(VarMap, CurrentIndex);
}

void CSwitchStatement::AddCase(const SValue& Label, const boost::intrusive_ptr<CBlock>& Block)
{
    // Check for duplicate
    foreach(const SCase& c, Cases)
    {
        if(Label == c.Label) // Case label already exists
            throw CSyntaxException(CompileError_DuplicateCaseLabel, Index, TranslationUnit);
    }

    SCase c = {Label, Block};
    Cases.push_back(c);
}