// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Preprocessor.h"
#include "Errors.h"
#include "Tokeniser.h"

// Function declarations
void FindAndReplaceAll(CTranslationUnit& t, const CString& ToFind, const CString& Replacement);


void FindAndReplaceAll(CTranslationUnit& t, const CString& ToFind, const CString& Replacement)
{
    CTranslationUnit::size_type i = 0;
    while(true)
    {
        i = t.find(ToFind, i);
        if(i == CTranslationUnit::npos)
            break;
        t.replace(i, ToFind.length(), Replacement);
        ++i;
    }
}

void Preprocess(CTranslationUnit& t, bool Debug)
{
    // Replace all windows style newlines with unix ones
    FindAndReplaceAll(t, "\r\n", "\n");

    // Comment removal has been moved to parsing stage. This is because this code would incorrectly flag
    // "abcBTW123" as a comment.
    /*
    // Remove multi-line comments
    CTranslationUnit::size_type i;
    while(true)
    {
        i = t.find("OBTW");
        if(i == CTranslationUnit::npos)
            break;

        CTranslationUnit::size_type j = t.find("TLDR", i);
        if(j == CTranslationUnit::npos)
            throw CSyntaxException(CompileError_MissingCommentBlockEnd, i, t);
        t.erase(i, j - i + 4); // +4 so that it removes the TLDR as well
    }

    // Remove single-line comments
    while(true)
    {
        i = t.find("BTW");
        if(i == CTranslationUnit::npos)
            break;

        CTranslationUnit::size_type j = t.find("\n", i);
        size_t NumToErase;
        if(j == CTranslationUnit::npos)
            NumToErase = t.length() - i; // Erase to end-of-file
        else
            NumToErase = j - i;
        t.erase(i, NumToErase);
    }
    */
}