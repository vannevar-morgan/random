// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Compiler.h"
#include "Errors.h"
#include "Parser.h"
#include "Block.h"
#include "Function.h"

CExecutable Compile(const CProgram& Program, bool Debug)
{
    CEmitContext ec(Program);

    ec.CurrentStackFrame = &ec.EntryPointStackFrame;
    Program.EntryPoint->Emit(ec);

    // Emit return instruction
    ec.AddInstruction(boost::intrusive_ptr<SReturnInstruction>(new SReturnInstruction()));

    foreach(const boost::intrusive_ptr<CFunction>& f, Program.Functions)
    {
        assert(ec.StackFrames.find(f->Name) != ec.StackFrames.end());
        ec.CurrentStackFrame = &ec.StackFrames[f->Name];
        f->Emit(ec);
    }

    ec.ResolveJumps();
    ec.ResolveCalls();

    return CExecutable(ec.GetInstructions(), ec.EntryPointStackFrame.InitialStackUsage);
}

CExecutable::CExecutable(const TInstructionContainer& Instructions, size_t EntryStackSize)
    : Instructions(Instructions), EntryStackSize(EntryStackSize)
{
}
const TInstructionContainer& CExecutable::GetInstructions() const
{
    return Instructions;
}
size_t CExecutable::GetEntryStackSize() const
{
    return EntryStackSize;
}


CEmitContext::CEmitContext(const CProgram& p) : CurrentStackFrame(NULL)
{
    boost::intrusive_ptr<const CBlock> NullParent; // Initialised to NULL

    InitialiseStackFrame(p.EntryPoint, EntryPointStackFrame);

    foreach(const boost::intrusive_ptr<CFunction>& Func, p.Functions)
    {
        if(StackFrames.find(Func->Name) != StackFrames.end()) // Duplicate function name
            throw CSyntaxException(CompileError_MultipleFunctionDefinition, Func->Index, Func->TranslationUnit);

        InitialiseStackFrame(Func, StackFrames[Func->Name]);
    }
}

void CEmitContext::InitialiseStackFrame(const boost::intrusive_ptr<const CBlock>& Function, SStackFrame& StackFrame)
{
    // This is what the stack looks like: (growing towards bottom)
    // Frame pointer -> [ Special bookkeeping ]
    //                  [    "IT" variable    ]
    //                  [   Named variables   ]
    //                  [         ...         ]
    //                  [  Unnamed variables  ]
    // Stack pointer -> [         ...         ]
    // 
    // So to resolve named variables, we need to start with an index of 2.
    size_t Index = 2;
    Function->ResolveVars(StackFrame.VarMap, Index); // Works recursively

    StackFrame.Function = Function;

    // Search for largest index. That's our initial stack size
    StackFrame.InitialStackUsage = 2;
    typedef std::pair<boost::intrusive_ptr<const CBlock>, TVarIndexMap> TBlockPair;
    foreach(const TBlockPair& b, StackFrame.VarMap)
    {
        typedef std::pair<CString, TVarIndex> TVarPair;
        foreach(const TVarPair& v, b.second)
        {
            // The cast is needed here, otherwise an unsigned comparison would occur.
            if(v.second > static_cast<TVarIndex>(StackFrame.InitialStackUsage))
                StackFrame.InitialStackUsage = v.second;
        }
    }
}

void CEmitContext::AddInstruction(const boost::intrusive_ptr<IInstruction>& i)
{
    Instructions.push_back(i);
}

const TInstructionContainer& CEmitContext::GetInstructions() const
{
    return Instructions;
}
size_t CEmitContext::GetInstructionCount() const
{
    return Instructions.size();
}

TVarIndex CEmitContext::GetVarIndex(const CString& VarName, const boost::intrusive_ptr<const CBlock>& Parent, size_t Index,
                                 const TTranslationUnitPtr& t) const
{
    assert(CurrentStackFrame != NULL);

    TBlockVarMap::const_iterator BlockIter = CurrentStackFrame->VarMap.find(Parent);
    if(BlockIter == CurrentStackFrame->VarMap.end())
        throw CException("Cannot resolve variable name. Block could not be found.");

    const TVarIndexMap& BlockVarMap = BlockIter->second;
    TVarIndexMap::const_iterator Var = BlockVarMap.find(VarName);
    if(Var == BlockVarMap.end())
        throw CVariableNotFoundException(VarName, Index, t);

    return Var->second;
}

void CEmitContext::RegisterJumpContext(size_t InstructionIndex,
                                       const boost::intrusive_ptr<SJumpInstruction>& JumpInstruction,
                                       const boost::intrusive_ptr<const CBlock>& BlockToJumpTo,
                                       bool JumpToBeginning)
{
    SJumpContext c;
    c.InstructionIndex = InstructionIndex;
    c.JumpInstruction = JumpInstruction;
    c.BlockToJumpTo = BlockToJumpTo;
    c.JumpToBeginning = JumpToBeginning;
    JumpContexts.push_back(c);
}

void CEmitContext::ResolveJumps()
{
    foreach(const SJumpContext& c, JumpContexts)
    {
        if(c.JumpToBeginning)
        {
            size_t Diff = c.BlockToJumpTo->GetInstructionStartIndex() - c.InstructionIndex;
            c.JumpInstruction->Offset = static_cast<int>(Diff);
        }
        else
        {
            size_t Diff = c.BlockToJumpTo->GetInstructionEndIndex() - c.InstructionIndex;
            c.JumpInstruction->Offset = static_cast<int>(Diff);
        }
    }
}

void CEmitContext::RegisterCallContext(size_t InstructionIndex,
                                       const boost::intrusive_ptr<SCallInstruction>& CallInstruction,
                                       const CString& FunctionName,
                                       size_t Index,
                                       const TTranslationUnitPtr& t)
{
    SCallContext c;
    c.InstructionIndex = InstructionIndex;
    c.CallInstruction = CallInstruction;
    c.FunctionName = FunctionName;

    c.Index = Index;
    c.TranslationUnit = t;
    CallContexts.push_back(c);
}
void CEmitContext::ResolveCalls()
{
    foreach(const SCallContext& c, CallContexts)
    {
        std::map<CString, SStackFrame>::const_iterator it = StackFrames.find(c.FunctionName);
        if(it == StackFrames.end()) // It's the job of the parser to ensure that functions exist.
            throw CException("Function not found.");

        size_t Diff = it->second.Function->GetInstructionStartIndex() - c.InstructionIndex;
        c.CallInstruction->Offset = static_cast<int>(Diff);
        c.CallInstruction->InitialStack = it->second.InitialStackUsage;
    }
}