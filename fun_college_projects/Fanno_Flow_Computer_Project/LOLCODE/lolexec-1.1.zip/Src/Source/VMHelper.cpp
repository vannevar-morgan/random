// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "VMHelper.h"

#include "Errors.h"
#include "VMHelper.inl"

#include <cstdio>

void Cast(SRuntimeVar& v, ERuntimeVarType NewType)
{
    switch(v.Type)
    {
    case RuntimeVarType_Untyped:
        switch(NewType)
        {
        case RuntimeVarType_Untyped:
            // Nothing
            break;
        case RuntimeVarType_Integer:
            v.IntegerPart = 0;
            break;
        case RuntimeVarType_Float:
            v.FloatPart = 0.0;
            break;
        case RuntimeVarType_Boolean:
            v.BooleanPart = false;
            break;
        case RuntimeVarType_String:
            v.StringPart.Initialise();
            break;
        default:
            throw CInvalidInstructionException("Unknown runtime variable type.");
        }
        break;
    case RuntimeVarType_Integer:
        {
            int& Val = v.IntegerPart;
            switch(NewType)
            {
            case RuntimeVarType_Untyped:
            case RuntimeVarType_Integer:
                // Nothing
                break;
            case RuntimeVarType_Float:
                v.FloatPart = static_cast<double>(Val);
                break;
            case RuntimeVarType_Boolean:
                v.BooleanPart = (Val != 0);
                break;
            case RuntimeVarType_String:
                v.StringPart.ParseInteger(Val);
                break;
            default:
                throw CInvalidInstructionException("Unknown runtime variable type.");
            }
        } break;
    case RuntimeVarType_Float:
        {
            double& Val = v.FloatPart;
            switch(NewType)
            {
            case RuntimeVarType_Untyped:
                // Nothing
                break;
            case RuntimeVarType_Integer:
                v.IntegerPart = static_cast<int>(Val);
                break;
            case RuntimeVarType_Float:
                // Nothing
                break;
            case RuntimeVarType_Boolean:
                v.BooleanPart = (Val != 0.0);
                break;
            case RuntimeVarType_String:
                v.StringPart.ParseFloat(Val);
                break;
            default:
                throw CInvalidInstructionException("Unknown runtime variable type.");
            }
        } break;
    case RuntimeVarType_Boolean:
        {
            bool& Val = v.BooleanPart;
            switch(NewType)
            {
            case RuntimeVarType_Untyped:
                // Nothing
                break;
            case RuntimeVarType_Integer:
                v.IntegerPart = static_cast<int>(Val ? 1 : 0);
                break;
            case RuntimeVarType_Float:
                v.FloatPart = static_cast<double>(Val ? 1.0 : 0.0);
                break;
            case RuntimeVarType_Boolean:
                // Nothing
                break;
            case RuntimeVarType_String:
                if(Val == true)
                    v.StringPart.Initialise("WIN", 3);
                else
                    v.StringPart.Initialise("FAIL", 4);
                break;
            default:
                throw CInvalidInstructionException("Unknown runtime variable type.");
            }
        } break;
    case RuntimeVarType_String:
        {
            SRuntimeString& Val = v.StringPart;
            switch(NewType)
            {
            case RuntimeVarType_Untyped:
                Val.Release();
                break;
            case RuntimeVarType_Integer:
                {
                    int i = Val.ToInteger();
                    Val.Release();
                    v.IntegerPart = i;
                } break;
            case RuntimeVarType_Float:
                {
                    double d = Val.ToFloat();
                    Val.Release();
                    v.FloatPart = d;
                } break;
            case RuntimeVarType_Boolean:
                {
                    bool b = Val.ToBoolean();
                    Val.Release();
                    v.BooleanPart = b;
                } break;
            case RuntimeVarType_String:
                // Nothing
                break;
            default:
                throw CInvalidInstructionException("Unknown runtime variable type.");
            }
        } break;
    default:
        throw CInvalidInstructionException("Unknown runtime variable type.");
    }
    v.Type = NewType;
}
