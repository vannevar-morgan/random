// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Parser.h"
#include "Errors.h"
#include "Expression.h"
#include "Statement.h"
#include "Block.h"
#include "LoopConstructs.h"
#include "IfStatement.h"
#include "SwitchStatement.h"

class CParser
{
private:
    const TTranslationUnitPtr& t;
    const TTokenContainer& Tokens;
    bool Debug;

    struct SFunctionDecl
    {
        CString Name;
        CArray<CString> Arguments;
        TTokenContainer::const_iterator BodyBegin;
    };
    CArray<SFunctionDecl> FunctionDeclarations;

    //////////////////////////////////////////////////////////////////////////
    // Functors
    //  These static functions are used in parsing of blocks to signal whether the block is at an end or not.
    static bool IsProgramEndFunc(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
        const TTranslationUnitPtr& t)
    {
        if(it == End)
            throw CSyntaxException(CompileError_MissingFunctionEnd, (it-1)->Index, t);
        if(it->Lexeme == "KTHXBYE") {
            ++it;
            return true;
        }
        return false;
    }
    static bool IsFunctionEndFunc(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
        const TTranslationUnitPtr& t)
    {
        if(std::distance(it, End) < 4)
            throw CSyntaxException(CompileError_MissingFunctionEnd, (it-1)->Index, t);
        if(it->Lexeme == "IF" && (it+1)->Lexeme == "U" && (it+2)->Lexeme == "SAY" && (it+3)->Lexeme == "SO") {
            it += 4;
            return true;
        }
        return false;
    }
    static bool IsConditionalBlockEndFunc(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
        const TTranslationUnitPtr& t)
    {
        if(it == End)
            throw CSyntaxException(CompileError_MissingIfBlockEnd, (it-1)->Index, t);
        if(it->Lexeme == "MEBBE" || it->Lexeme == "NO" || it->Lexeme == "OIC") {
            ++it;
            return true;
        }
        return false;
    }
    static bool IsIfBlockEndFunc(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
        const TTranslationUnitPtr& t)
    {
        if(it == End)
            throw CSyntaxException(CompileError_MissingIfBlockEnd, (it-1)->Index, t); // wrong error code
        if(it->Lexeme == "OIC") {
            ++it;
            return true;
        }
        return false;
    }
    static bool IsCaseBlockEndFunc(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
        const TTranslationUnitPtr& t)
    {
        if(it == End)
            throw CSyntaxException(CompileError_MissingCaseBlockEnd, (it-1)->Index, t);
        if(it->Lexeme == "OIC" || it->Lexeme == "OMG" || it->Lexeme == "OMGWTF") {
            ++it;
            return true;
        }
        return false;
    }

    struct SIsLoopEndFunc
    {
    private:
        const CString& Label;
    public:
        SIsLoopEndFunc(const CString& Label) : Label(Label) {}
        bool operator()(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
            const TTranslationUnitPtr& t) const
        {
            if(std::distance(it, End) < 4)
                throw CSyntaxException(CompileError_MissingLoopEnd, (it-1)->Index, t);
            if(it->Lexeme == "IM" && (it+1)->Lexeme == "OUTTA" && (it+2)->Lexeme == "YR" && (it+3)->Lexeme == Label) {
                it += 4;
                return true;
            }
            return false;
        }
    };
    //////////////////////////////////////////////////////////////////////////

    SValue ParseValue(const SToken& Token) const
    {
        return SValue(Token.Type == TokenType_StringLiteral, Token.Lexeme);
    }

    // This is a helper function to validate and ensure that key phrases like "I HAS A" are valid, and throws if
    // they're not. Advances the iterator passed in through the it parameter.
    void ValidatePhrase(TTokenContainer::const_iterator& it, const CString& t1,
        TTokenContainer::const_iterator End) const
    {
        if(it == End || it->Lexeme != t1)
            throw CUnexpectedSyntaxException(it->Lexeme, t1, it->Index, t);
        ++it;
    }
    void ValidatePhrase(TTokenContainer::const_iterator& it, const CString& t1, const CString& t2,
        TTokenContainer::const_iterator End) const
    {
        if(it == End || it->Lexeme != t1)
            throw CUnexpectedSyntaxException(it->Lexeme, t1 + ' ' + t2, it->Index, t);
        ++it;
        if(it == End || it->Lexeme != t2)
            throw CUnexpectedSyntaxException(it->Lexeme, t1 + ' ' + t2, it->Index, t);
        ++it;
    }
    void ValidatePhrase(TTokenContainer::const_iterator& it, const CString& t1, const CString& t2,
        const CString& t3, TTokenContainer::const_iterator End) const
    {
        if(it == End || it->Lexeme != t1)
            throw CUnexpectedSyntaxException(it->Lexeme, t1 + ' ' + t2 + ' ' + t3, it->Index, t);
        ++it;
        if(it == End || it->Lexeme != t2)
            throw CUnexpectedSyntaxException(it->Lexeme, t1 + ' ' + t2 + ' ' + t3, it->Index, t);
        ++it;
        if(it == End || it->Lexeme != t3)
            throw CUnexpectedSyntaxException(it->Lexeme, t1 + ' ' + t2 + ' ' + t3, it->Index, t);
        ++it;
    }
    void ValidatePhrase(TTokenContainer::const_iterator& it, const CString& t1) const
    {
        ValidatePhrase(it, t1, Tokens.end());
    }
    void ValidatePhrase(TTokenContainer::const_iterator& it, const CString& t1, const CString& t2) const
    {
        ValidatePhrase(it, t1, t2, Tokens.end());
    }
    void ValidatePhrase(TTokenContainer::const_iterator& it, const CString& t1, const CString& t2, const CString& t3) const
    {
        ValidatePhrase(it, t1, t2, t3, Tokens.end());
    }

    // This advances the token iterator, and ensures that it does not point at the end, throwing an exception
    // with the specified error code if it does.
    void AdvanceToken(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End,
        ECompileError Code = CompileError_MissingArg) const
    {
        ++it;
        if(it == End)
            throw CSyntaxException(Code, (it-1)->Index, t);
    }

    // In many statements, the "AN" keyword is optional. This function skips past it if it exists.
    void SkipOptionalAn(TTokenContainer::const_iterator& it) const
    {
        if(it->Lexeme == "AN")
            ++it;
    }
    // This version of the function does an additional check to ensure that the advanced-to token is not equal to End.
    void SkipOptionalAn(TTokenContainer::const_iterator& it, TTokenContainer::const_iterator End) const
    {
        if(it->Lexeme == "AN")
            AdvanceToken(it, End);
    }

    // Parses binary operators of the form "<Stem1> <Stem2> <x> [AN] <y>"
    // Where <x> and <y> are expressions and [AN] may be optional, depending on the OptionalAn flag.
    // The type T should have LHS and RHS member variables as well as an appropriate constructor.
    template<typename T>
    boost::intrusive_ptr<T> ParseBinaryOperator(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator End,
        TTokenContainer::const_iterator& ExprEnd,
        const CString& Stem1,
        const CString& Stem2,
        bool OptionalAn,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        TTokenContainer::const_iterator it = Begin;
        assert(it != End);
        assert(Parent != NULL);

        boost::intrusive_ptr<T> Expr(new T(Begin->Index, t, Parent));
        if(!Stem2.empty())
            ValidatePhrase(it, Stem1, Stem2, End);
        else
            ValidatePhrase(it, Stem1, End);

        if(it == End)
            throw CSyntaxException(CompileError_MissingArg, it->Index, t);
        TTokenContainer::const_iterator LHSEnd;
        Expr->LHS = ParseExpression(it, End, LHSEnd, Parent);

        it = LHSEnd;
        if(OptionalAn)
        {
            if(it == End)
                throw CSyntaxException(CompileError_MissingArg, it->Index, t);
            SkipOptionalAn(it);
        }
        else
            ValidatePhrase(it, "AN", End);

        if(it == End)
            throw CSyntaxException(CompileError_MissingArg, it->Index, t);
        TTokenContainer::const_iterator RHSEnd;
        Expr->RHS = ParseExpression(it, End, RHSEnd, Parent);
        it = RHSEnd;

        ExprEnd = it;
        return Expr;
    }

    // Parses binary operators of the form "<Stem1> <Stem2> <x> [AN] <y> ... MKAY"
    // Where <x> and <y> are expressions and [AN] may be optional, depending on the OptionalAn flag.
    // The type T should have an Expressions member variable as well as an appropriate constructor.
    template<typename T>
    boost::intrusive_ptr<T> ParseInfiniteArityOperator(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator End,
        TTokenContainer::const_iterator& ExprEnd,
        const CString& Stem1,
        const CString& Stem2,
        bool OptionalAn,
        size_t MinArgumentCount,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        TTokenContainer::const_iterator it = Begin;
        assert(it != End);
        assert(Parent != NULL);

        boost::intrusive_ptr<T> Expr(new T(Begin->Index, t, Parent));

        if(!Stem2.empty())
            ValidatePhrase(it, Stem1, Stem2, End);
        else
            ValidatePhrase(it, Stem1, End);

        while(it != End && it->Lexeme != "MKAY")
        {
            TTokenContainer::const_iterator MyExprEnd;
            Expr->Expressions.push_back(ParseExpression(it, End, MyExprEnd, Parent));
            it = MyExprEnd;
            if(it == End || it->Lexeme == "MKAY")
                break;

            if(OptionalAn)
            {
                SkipOptionalAn(it);
            }
            else
                ValidatePhrase(it, "AN", End);
        }

        if(Expr->Expressions.size() < MinArgumentCount) // Not enough arguments
            throw CSyntaxException(CompileError_NotEnoughArgs, it->Index, t);

        if(it->Lexeme == "MKAY")
            ++it;
        ExprEnd = it;
        return Expr;
    }

    // When an expression starts, you don't necessarily know when it ends until it's been fully parsed.
    // Begin should point to the start of the expression, End should point one past the last token in the statement.
    // So this function only requires the beginning of the expression as input, and it returns one past the last token
    // of the expression in the ExprEnd parameter. The ExprEnd parameter is otherwise unused.
    boost::intrusive_ptr<CExpression> ParseExpression(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator End,
        TTokenContainer::const_iterator& ExprEnd,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        TTokenContainer::const_iterator it = Begin;
        assert(it != End); // Empty expression?
        assert(Parent != NULL);
        
        // Mathematical operators
        if(it->Lexeme == "SUM")
        {
            return ParseBinaryOperator<CAddExpression>(Begin, End, ExprEnd, "SUM", "OF", false, Parent);
        }
        else if(it->Lexeme == "DIFF")
        {
            return ParseBinaryOperator<CSubtractExpression>(Begin, End, ExprEnd, "DIFF", "OF", false, Parent);
        }
        else if(it->Lexeme == "PRODUKT")
        {
            return ParseBinaryOperator<CMultiplyExpression>(Begin, End, ExprEnd, "PRODUKT", "OF", false, Parent);
        }
        else if(it->Lexeme == "QUOSHUNT")
        {
            return ParseBinaryOperator<CDivideExpression>(Begin, End, ExprEnd, "QUOSHUNT", "OF", false, Parent);
        }
        else if(it->Lexeme == "MOD")
        {
            return ParseBinaryOperator<CModExpression>(Begin, End, ExprEnd, "MOD", "OF", false, Parent);
        }
        else if(it->Lexeme == "BIGGR")
        {
            return ParseBinaryOperator<CMaxExpression>(Begin, End, ExprEnd, "BIGGR", "OF", false, Parent);
        }
        else if(it->Lexeme == "SMALLR")
        {
            return ParseBinaryOperator<CMinExpression>(Begin, End, ExprEnd, "SMALLR", "OF", false, Parent);
        }
        else if(it->Lexeme == "BOTH") // Logical AND -or- equality comparison
        {
            ++it;
            if(it == End)
                throw CUnexpectedSyntaxException((it-1)->Lexeme, it->Index, t);
            if(it->Lexeme == "OF") // Logical AND
            {
                boost::intrusive_ptr<CAndExpression> Expr(new CAndExpression(it->Index, t, Parent));
                AdvanceToken(it, End);
                TTokenContainer::const_iterator LHSEnd;
                Expr->Expressions.push_back(ParseExpression(it, End, LHSEnd, Parent));
                it = LHSEnd;

                if(it == End)
                    throw CSyntaxException(CompileError_MissingArg, it->Index, t);
                SkipOptionalAn(it, End);

                TTokenContainer::const_iterator RHSEnd;
                Expr->Expressions.push_back(ParseExpression(it, End, RHSEnd, Parent));
                it = RHSEnd;

                ExprEnd = it;
                return Expr;
            }
            else if(it->Lexeme == "SAEM") // Equality comparison
            {
                return ParseBinaryOperator<CEqualsExpression>(Begin, End, ExprEnd, "BOTH", "SAEM", true, Parent);
            }
            else
            {
                throw CUnexpectedSyntaxException(it->Lexeme, "\'OF\' or \'SAEM\' keyword.", it->Index, t);
            }
        }
        else if(it->Lexeme == "EITHER") // Logical OR
        {
            boost::intrusive_ptr<COrExpression> Expr(new COrExpression(it->Index, t, Parent));

            ValidatePhrase(it, "EITHER", "OF", End);
            if(it == End)
                throw CSyntaxException(CompileError_MissingArg, it->Index, t);

            TTokenContainer::const_iterator LHSEnd;
            Expr->Expressions.push_back(ParseExpression(it, End, LHSEnd, Parent));
            it = LHSEnd;

            if(it == End)
                throw CSyntaxException(CompileError_MissingArg, it->Index, t);
            SkipOptionalAn(it, End);

            TTokenContainer::const_iterator RHSEnd;
            Expr->Expressions.push_back(ParseExpression(it, End, RHSEnd, Parent));
            it = RHSEnd;

            ExprEnd = it;
            return Expr;
        }
        else if(it->Lexeme == "WON") // Logical XOR
        {
            return ParseBinaryOperator<CXorExpression>(Begin, End, ExprEnd, "WON", "OF", true, Parent);
        }
        else if(it->Lexeme == "ALL") // Infinite arity AND
        {
            return ParseInfiniteArityOperator<CAndExpression>(Begin, End, ExprEnd, "ALL", "OF", true, 2, Parent);
        }
        else if(it->Lexeme == "ANY") // Infinite arity OR
        {
            return ParseInfiniteArityOperator<COrExpression>(Begin, End, ExprEnd, "ANY", "OF", true, 2, Parent);
        }
        else if(it->Lexeme == "NOT") // Boolean NOT
        {
            boost::intrusive_ptr<CNotExpression> Expr(new CNotExpression(it->Index, t, Parent));
            AdvanceToken(it, End);
            Expr->Arg = ParseExpression(it, End, ExprEnd, Parent);
            return Expr;
        }
        else if(it->Lexeme == "DIFFRINT") // Not equals
        {
            return ParseBinaryOperator<CNotEqualsExpression>(Begin, End, ExprEnd, "DIFFRINT", "", true, Parent);
        }
        else if(it->Lexeme == "SMOOSH") // String concatenation
        {
            return ParseInfiniteArityOperator<CConcatExpression>(Begin, End, ExprEnd, "SMOOSH", "", true, 2, Parent);
        }
        else if(it->Lexeme == "MAEK") // Cast
        {
            boost::intrusive_ptr<CCastExpression> Expr(new CCastExpression(it->Index, t, Parent));
            AdvanceToken(it, End);

            TTokenContainer::const_iterator ArgEnd;
            Expr->Arg = ParseExpression(it, End, ArgEnd, Parent);
            it = ArgEnd;

            if(it == End)
                throw CSyntaxException(CompileError_MissingArg, it->Index, t);
            if(it->Lexeme == "A")
                AdvanceToken(it, End);

            Expr->TypeName = it->Lexeme;
            ++it;
            ExprEnd = it;
            return Expr;
        }
        else
        {
            foreach(const SFunctionDecl& FuncDecl, FunctionDeclarations)
            {
                if(it->Lexeme == FuncDecl.Name)
                {
                    // Is a function call
                    boost::intrusive_ptr<CFunctionCallExpression> Expr(new CFunctionCallExpression(it->Index, t, Parent));
                    Expr->FunctionName = FuncDecl.Name;
                    ++it; // AdvanceToken(it, End); // Doesn't work with parameterless functions

                    // Parse function arguments
                    for(size_t i = 0 ; i < FuncDecl.Arguments.size() ; ++i)
                    {
                        if(it == End || it->Type == TokenType_StatementDelimiter)
                            throw CSyntaxException(CompileError_MissingArg, it->Index, t);
                        Expr->Arguments.push_back(ParseExpression(it, End, it, Parent));
                    }
                    ExprEnd = it;
                    return Expr;
                }
            }

            // Check to see if this is a cast
            {
                ++it;
                if(it != End && it->Lexeme == "IS")
                {
                    // This is a cast
                    boost::intrusive_ptr<CCastVarExpression> Expr(new CCastVarExpression(it->Index, t, Parent));
                    Expr->VarName = (it - 1)->Lexeme;

                    ValidatePhrase(it, "IS", "NOW", "A", End);
                    if(it == End)
                        throw CSyntaxException(CompileError_MissingArg, it->Index, t);

                    Expr->TypeName = it->Lexeme;

                    ++it;
                    ExprEnd = it;
                    return Expr;
                }
                else
                    --it;
            }

            // This is a Value expression
            boost::intrusive_ptr<CValueExpression> Expr(new CValueExpression(it->Index, t, Parent));
            Expr->Value = ParseValue(*it);
            ++it;
            ExprEnd = it;
            return Expr;
        }
    }

    boost::intrusive_ptr<CStatement> ParseStatement(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator End,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        assert(Begin != End);
        assert(Parent != NULL);

        TTokenContainer::const_iterator it = Begin;
        if(it->Lexeme == "VISIBLE") // Print
        {
            bool TerminateNewline = true;

            // Deal with optional [!] to suppress newline termination
            {
                TTokenContainer::const_iterator LastToken = End - 1;
                if(LastToken != it && !LastToken->Lexeme.empty())
                {
                    if(LastToken->Type != TokenType_StringLiteral && LastToken->Lexeme.back() == '!')
                    {
                        TerminateNewline = false;

                        // This is a hack! The token needs to be modified because the terminating ! needs to be
                        // removed.
                        const_cast<CString&>(LastToken->Lexeme).pop_back();
                    }
                    if(LastToken->Lexeme.empty())
                        --End;
                }
            }

            boost::intrusive_ptr<CVisibleStatement> Statement(new CVisibleStatement(it->Index, t, Parent));
            AdvanceToken(it, End);
            Statement->Arguments.push_back(ParseExpression(it, End, it, Parent));

            while(it != End)
            {
                if(it->Lexeme == "AN")
                {
                    AdvanceToken(it, End);
                }
                Statement->Arguments.push_back(ParseExpression(it, End, it, Parent));
            }

            if(TerminateNewline) {
                boost::intrusive_ptr<CValueExpression> e(new CValueExpression(it->Index, t, Parent));
                e->Value.Data = "\"\n\"";
                e->Value.IsStringLiteral = true;
                Statement->Arguments.push_back(e);
            }
            return Statement;
        }
        else if(it->Lexeme == "GIMMEH") // Keyboard input
        {
            AdvanceToken(it, End);

            boost::intrusive_ptr<CConsoleInputExpression> Statement(new CConsoleInputExpression(it->Index, t, Parent));
            Statement->VarName = it->Lexeme;

            ++it;
            if(it != End)
                throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t);
            return Statement;
        }
        else if(it->Lexeme == "CAN") // Import
        {
            boost::intrusive_ptr<CImportStatement> Statement(new CImportStatement(it->Index, t, Parent));
            ValidatePhrase(it, "CAN", "HAS");
            if(it == End)
                throw CSyntaxException(CompileError_MissingArg, it->Index, t);

            Statement->Argument = it->Lexeme;

            ++it;
            if(it != End)
                throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t);
            return Statement;
        }
        else if(it->Lexeme == "I") // Variable declaration/definition
        {
            boost::intrusive_ptr<CDeclareVarStatement> Statement(new CDeclareVarStatement(it->Index, t, Parent));
            ValidatePhrase(it, "I", "HAS", "A");
            if(it == End)
                throw CSyntaxException(CompileError_InvalidVariableDeclaration, it->Index, t);
            Statement->VarName = it->Lexeme;
            ++it;
            if(it != End)
            {
                ValidatePhrase(it, "ITZ");
                if(it == End)
                    throw CSyntaxException(CompileError_InvalidVariableDeclaration, it->Index, t);
                Statement->InitialValue = ParseExpression(it, End, it, Parent);

                if(it != End)
                    throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t);
            }
            return Statement;
        }
        else if(it->Lexeme == "GTFO") // Loop break
        {
            return boost::intrusive_ptr<CBreakStatement>(new CBreakStatement(it->Index, t, Parent));
        }
        else if(it->Lexeme == "FOUND") // Return from function
        {
            boost::intrusive_ptr<CReturnStatement> Statement(new CReturnStatement(it->Index, t, Parent));
            ValidatePhrase(it, "FOUND", "YR");
            if(it == End) // Missing expression
                throw CSyntaxException(CompileError_MissingExpression, it->Index, t);
            Statement->Arg = ParseExpression(it, End, it, Parent);
            if(it != End)
                throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t);
            return Statement;
        }
        else
        {
            ++it;

            // Check for assignment
            if(it != End && it->Lexeme == "R")
            {
                AdvanceToken(it, End);
                /*++it;
                if(it == End) // Expected an rvalue here
                    throw CSyntaxException(CompileError_MissingArg, it->Index, t);*/

                boost::intrusive_ptr<CAssignVarStatement> Statement(new CAssignVarStatement(it->Index, t, Parent));
                Statement->VarName = Begin->Lexeme;
                Statement->Arg = ParseExpression(it, End, it, Parent);

                if(it != End)
                    throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t);
                return Statement;
            }
            else
            {
                // This is just a bare expression. This is legal LOLCODE.
                // Place the value of this variable into the implicit IT variable
                it = Begin;
                boost::intrusive_ptr<CAssignVarStatement> Statement(new CAssignVarStatement(it->Index, t, Parent));
                Statement->VarName = "IT";
                Statement->Arg = ParseExpression(it, End, it, Parent);
                return Statement;
            }
        }

        throw CException("Internal error."); // Never gets here
    }

    void SkipStatementDelimiters(TTokenContainer::const_iterator& it) const
    {
        while(it != Tokens.end() && it->Type == TokenType_StatementDelimiter)
            ++it;
    }

    boost::intrusive_ptr<CSimpleLoop> ParseLoop(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator& End,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        assert(Parent != NULL);

        TTokenContainer::const_iterator it = Begin;
        assert(it->Lexeme == "IM");

        TTokenContainer::const_iterator StatementBegin = it;
        TTokenContainer::const_iterator StatementEnd = StatementBegin;
        while(StatementEnd != Tokens.end() && StatementEnd->Type != TokenType_StatementDelimiter)
            ++StatementEnd;

        ValidatePhrase(it, "IM", "IN", "YR", StatementEnd);
        if(it == StatementEnd)
            throw CSyntaxException(CompileError_MissingLoopLabel, it->Index, t);
        if(it == Tokens.end()) // Unexpected EOF
            throw CSyntaxException(CompileError_MissingLoopEnd, it->Index, t);

        const CString& Label = it->Lexeme;
        SIsLoopEndFunc FindEndFunc(Label);

        TTokenContainer::const_iterator BlockBegin;
        TTokenContainer::const_iterator BlockEnd;

        ++it;
        if(it == StatementEnd)
        {
            // This is a simple loop
            BlockBegin = it;
            boost::intrusive_ptr<CSimpleLoop> Loop(new CSimpleLoop(BlockBegin->Index, t, Parent));
            Loop->Block = ParseBlock(BlockBegin, BlockEnd, Loop, FindEndFunc);
            Loop->Label = Label;

            End = BlockEnd;
            return Loop;
        }

        // This is not a simple loop
        const CString& Operation = it->Lexeme;

        AdvanceToken(it, StatementEnd);
        ValidatePhrase(it, "YR", StatementEnd);

        if(it == StatementEnd)
            throw CSyntaxException(CompileError_MissingArg, Begin->Index, t);

        const CString& VariableName = it->Lexeme;

        ++it;
        if(it == StatementEnd)
        {
            // This is an iteration loop (no conditional)
            BlockBegin = it;
            boost::intrusive_ptr<CIterationLoop> Loop(new CIterationLoop(BlockBegin->Index, t, Parent));
            Loop->Label = Label;
            Loop->Block = ParseBlock(BlockBegin, BlockEnd, Loop, FindEndFunc);
            Loop->VarName = VariableName;
            Loop->Operation = Operation;

            End = BlockEnd;
            return Loop;
        }
        else
        {
            // This is a conditional loop (ie. a while or a for loop)
            const CString& Type = it->Lexeme;

            AdvanceToken(it, StatementEnd);

            TTokenContainer::const_iterator ExprBegin = it;

            it = StatementEnd;

            BlockBegin = it;

            boost::intrusive_ptr<IConditionalLoop> Loop;
            if(Type == "TIL")
            {
                // For loop
                Loop.reset(new CForLoop(BlockBegin->Index, t, Parent));
            }
            else if(Type == "WILE")
            {
                // While loop
                Loop.reset(new CWhileLoop(BlockBegin->Index, t, Parent));
            }
            else
            {
                // Unrecognised
                throw CSyntaxException(CompileError_UnknownLoopConstruct, Begin->Index, t);
            }

            Loop->Label = Label;
            Loop->Block = ParseBlock(BlockBegin, BlockEnd, Loop, FindEndFunc);
            Loop->VarName = VariableName;
            Loop->Operation = Operation;

            // Parse loop condition
            TTokenContainer::const_iterator ExprEnd;
            Loop->Condition = ParseExpression(ExprBegin, StatementEnd, ExprEnd, Loop);
            if(ExprEnd != StatementEnd)
                throw CUnexpectedSyntaxException(ExprEnd->Lexeme, Begin->Index, t);

            End = BlockEnd;
            return Loop;
        }

        throw CException("Internal error."); // Never gets here
    }

    // Begin should point into the start of the if statement.
    // The input value of End can be undefined, the function doesn't use it.
    // The function returns one past the last token of the if statement in the End parameter.
    boost::intrusive_ptr<CIfStatement> ParseIfStatement(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator& End,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        assert(Parent != NULL);

        TTokenContainer::const_iterator it = Begin;
        assert(it->Lexeme == "O");

        TTokenContainer::const_iterator BlockBegin;
        TTokenContainer::const_iterator BlockEnd;

        ValidatePhrase(it, "O", "RLY?");
        SkipStatementDelimiters(it);
        if(it == Tokens.end()) // Unexpected EOF
            throw CSyntaxException(CompileError_MissingIfBlockEnd, it->Index, t);

        // YA RLY block is not optional
        ValidatePhrase(it, "YA", "RLY");
        SkipStatementDelimiters(it);
        if(it == Tokens.end()) // Unexpected EOF
            throw CSyntaxException(CompileError_MissingIfBlockEnd, it->Index, t);

        BlockBegin = it;

        // Find end of block (either by MEBBE, NO WAI, or OIC)
        boost::intrusive_ptr<CIfStatement> IfStatement(new CIfStatement(BlockBegin->Index, t, Parent));
        IfStatement->TrueBlock = ParseBlock(BlockBegin, BlockEnd, Parent, IsConditionalBlockEndFunc);
        it = BlockEnd - 1;

        if(it->Lexeme == "OIC") {
            End = BlockEnd;
            return IfStatement;
        }

        // Parse any else-if blocks
        while(it->Lexeme == "MEBBE")
        {
            ++it;
            if(it == Tokens.end()) // Unexpected EOF
                throw CSyntaxException(CompileError_MissingIfBlockEnd, it->Index, t);

            // Parse the conditional for this else-if block
            boost::intrusive_ptr<CExpression> Conditional;
            {
                // Find the end of the statement
                TTokenContainer::const_iterator StatementBegin = it;
                TTokenContainer::const_iterator StatementEnd = StatementBegin;
                while(StatementEnd != Tokens.end() && StatementEnd->Type != TokenType_StatementDelimiter)
                    ++StatementEnd;
                Conditional = ParseExpression(StatementBegin, StatementEnd, it, Parent);
            }

            BlockBegin = it;

            boost::intrusive_ptr<CElseIfBlock> ElseIfBlock(
                new CElseIfBlock(*ParseBlock(BlockBegin, BlockEnd, Parent, IsConditionalBlockEndFunc))
                );
            it = BlockEnd - 1;
            ElseIfBlock->Conditional = Conditional;
            IfStatement->ElseIfBlocks.push_back(ElseIfBlock);
        }

        // Parse else block, if it exists
        if(it->Lexeme == "NO")
        {
            ValidatePhrase(it, "NO", "WAI");

            if(it == Tokens.end()) // Unexpected EOF
                throw CSyntaxException(CompileError_MissingIfBlockEnd, it->Index, t);
            BlockBegin = it;

            // Find end of block (can only end with "OIC" in an else if ("NO WAI") block)
            IfStatement->FalseBlock = ParseBlock(BlockBegin, BlockEnd, Parent, IsIfBlockEndFunc);
            it = BlockEnd - 1;
        }
        else
        {
            assert(it->Lexeme == "OIC");
        }
        End = BlockEnd + 1; // Skip past OIC
        return IfStatement;
    }

    bool IsCaseBlockEnd(const CString& Lexeme) const
    {
        return (Lexeme == "OIC" || Lexeme == "OMG" || Lexeme == "OMGWTF");
    }

    // Works similarly to ParseIfStatement.
    boost::intrusive_ptr<CSwitchStatement> ParseSwitchStatement(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator& SwitchEnd,
        const boost::intrusive_ptr<const CBlock>& Parent) const
    {
        assert(Parent != NULL);

        TTokenContainer::const_iterator it = Begin;
        TTokenContainer::const_iterator End = Tokens.end();
        assert(it->Lexeme == "WTF?");

        boost::intrusive_ptr<CSwitchStatement> Switch(new CSwitchStatement(Begin->Index, t, Parent));

        // Parse cases
        AdvanceToken(it, End);
        SkipStatementDelimiters(it);
        while(it->Lexeme != "OIC")
        {
            bool IsDefault;
            SValue Label;
            if(it->Lexeme == "OMG")
            {
                // Case
                IsDefault = false;

                // Parse literal
                AdvanceToken(it, End);
                if(IsCaseBlockEnd(it->Lexeme) || it->Type == TokenType_StatementDelimiter) // No literal found
                    throw CSyntaxException(CompileError_MissingCaseLabel, it->Index, t);
                Label = ParseValue(*it);
            }
            else if(it->Lexeme == "OMGWTF")
            {
                // Default case
                IsDefault = true;
            }
            else
                throw CUnexpectedSyntaxException(it->Lexeme, "OMG or OMGWTF", it->Index, t);

            AdvanceToken(it, End);

            // Find end of block
            TTokenContainer::const_iterator BlockBegin = it;
            TTokenContainer::const_iterator BlockEnd;

            boost::intrusive_ptr<CBlock> Block = ParseBlock(BlockBegin, BlockEnd, Switch, IsCaseBlockEndFunc);

            if(IsDefault)
                Switch->DefaultCase = Block;
            else
                Switch->AddCase(Label, Block);

            it = BlockEnd - 1; // This should always be a dereferenceable iterator
            SkipStatementDelimiters(it);
        }

        SwitchEnd = it + 1;
        return Switch;
    }

    template<typename TFunc>
    boost::intrusive_ptr<CBlock> ParseBlock(
        TTokenContainer::const_iterator Begin,
        TTokenContainer::const_iterator& End,
        const boost::intrusive_ptr<const CBlock>& Parent,
        TFunc Func) const
    {
        boost::intrusive_ptr<CBlock> Block(new CBlock(Begin->Index, t, Parent));

        // Loop through every token and parse
        TTokenContainer::const_iterator it = Begin;
        while(true)
        {
            SkipStatementDelimiters(it);

            if(Func(it, Tokens.end(), t))
            {
                // This is end-of-block
                End = it;
                break;
            }

            // Check to see if this token denotes something special - like a loop or branching construct for example.
            if(it->Lexeme == "O") // If statement
            {
                TTokenContainer::const_iterator StatementEnd;
                Block->Statements.push_back(ParseIfStatement(it, StatementEnd, Block));
                it = StatementEnd;
            }
            else if(it->Lexeme == "IM") // Loop
            {
                TTokenContainer::const_iterator LoopEnd;
                Block->Statements.push_back(ParseLoop(it, LoopEnd, Block));
                it = LoopEnd;
            }
            else if(it->Lexeme == "WTF?") // Switch statement
            {
                TTokenContainer::const_iterator SwitchEnd;
                Block->Statements.push_back(ParseSwitchStatement(it, SwitchEnd, Block));
                it = SwitchEnd;
            }
            else
            {
                // This is a regular statement
                // Find the end of the statement
                TTokenContainer::const_iterator StatementBegin = it;
                TTokenContainer::const_iterator StatementEnd = StatementBegin;
                while(StatementEnd != Tokens.end() && StatementEnd->Type != TokenType_StatementDelimiter)
                    ++StatementEnd;

                // Create statement
                if(StatementBegin != StatementEnd)
                    Block->Statements.push_back(ParseStatement(StatementBegin, StatementEnd, Block));
                it = StatementEnd;
            }
        }

        return Block;
    }

    TTokenContainer::const_iterator FindFunctionEnd(TTokenContainer::const_iterator Begin) const
    {
        TTokenContainer::const_iterator it = Begin;
        while(std::distance(it, Tokens.end()) >= 4)
        {
            if(it->Lexeme == "IF" && (it+1)->Lexeme == "U" && (it+2)->Lexeme == "SAY" && (it+3)->Lexeme == "SO")
                return (it + 4);
            if(it->Lexeme == "HAI" || it->Lexeme == "HOW") // Cannot nest functions
                throw CSyntaxException(CompileError_NestedFunction, it->Index, t);
            ++it;
        }

        // No end of function found
        throw CSyntaxException(CompileError_MissingFunctionEnd, Begin->Index, t);
    }

public:
    CProgram Parse()
    {
        if(Tokens.empty()) // Empty program
            throw CSyntaxException(CompileError_NoEntryPoint, 0, t);

        TTokenContainer::const_iterator it = Tokens.begin();
        TTokenContainer::const_iterator End = Tokens.end();

        CString LanguageVersion;
        TTokenContainer::const_iterator EntryPointBegin;
        bool FoundEntryPoint = false;
        SkipStatementDelimiters(it);

        // 1st pass: scan through and gather entry point body begin/end, and any function declarations
        while(it != End)
        {
            if(it->Lexeme == "HAI")
            {
                // Can only have one entry point
                if(FoundEntryPoint)
                    throw CSyntaxException(CompileError_MultipleFunctionDefinition, it->Index, t);

                ++it;
                if(it == End || it->Type == TokenType_StatementDelimiter)
                {
                    // Default to version 1.2
                    LanguageVersion = "1.2";
                }
                else
                {
                    LanguageVersion = it->Lexeme;

                    AdvanceToken(it, End, CompileError_MissingFunctionEnd);
                    if(it->Type != TokenType_StatementDelimiter)
                        throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t);
                }

                AdvanceToken(it, End, CompileError_MissingFunctionEnd);

                EntryPointBegin = it;

                // Search for "KTHXBYE"
                while(it->Lexeme != "KTHXBYE")
                {
                    if(it->Lexeme == "HAI" || it->Lexeme == "HOW") // Cannot nest functions
                        throw CSyntaxException(CompileError_NestedFunction, it->Index, t);
                    AdvanceToken(it, End, CompileError_MissingFunctionEnd);
                }
                ++it;

                FoundEntryPoint = true;
            }
            else if(it->Lexeme == "HOW") // Function declaration
            {
                SFunctionDecl Func;
                ValidatePhrase(it, "HOW", "DUZ", "I");
                if(it == End) // Unexpected EOF
                    throw CSyntaxException(CompileError_MissingFunctionEnd, (it-1)->Index, t);

                Func.Name = it->Lexeme;

                AdvanceToken(it, End, CompileError_MissingFunctionEnd);

                // Parse function arguments
                while(it != End && it->Type != TokenType_StatementDelimiter)
                {
                    ValidatePhrase(it, "YR", End);
                    if(it == End) // Unexpected EOF
                        throw CSyntaxException(CompileError_MissingFunctionEnd, (it-1)->Index, t);
                    if(it->Type == TokenType_StatementDelimiter) // Missing argument
                        throw CSyntaxException(CompileError_MissingArg, it->Index, t);
                    Func.Arguments.push_back(it->Lexeme);
                    ++it;
                }

                Func.BodyBegin = it;
                it = FindFunctionEnd(it);

                FunctionDeclarations.push_back(Func);
            }
            else
                throw CUnexpectedSyntaxException(it->Lexeme, it->Index, t); // Unrecognised
            SkipStatementDelimiters(it);
        }

        if(!FoundEntryPoint) // No HAI found, no entry point
            throw CSyntaxException(CompileError_NoEntryPoint, 0, t);

        // 2nd pass: parse the entry point and all collected functions
        CProgram Program;
        boost::intrusive_ptr<const CBlock> NullParent; // Initialised to NULL
        TTokenContainer::const_iterator BlockEnd; // Unused
        Program.EntryPoint = ParseBlock(EntryPointBegin, BlockEnd, NullParent, IsProgramEndFunc);

        foreach(const SFunctionDecl& FuncDecl, FunctionDeclarations)
        {
            boost::intrusive_ptr<CFunction> Func(new CFunction(FuncDecl.BodyBegin->Index, t, NullParent));
            Func->Arguments = FuncDecl.Arguments;
            Func->Name = FuncDecl.Name;
            Func->Body = ParseBlock(FuncDecl.BodyBegin, BlockEnd, Func, IsFunctionEndFunc);
            Program.Functions.push_back(Func);
        }

        return Program;
    }

    CParser(const TTranslationUnitPtr& t, const TTokenContainer& Tokens, bool Debug)
        : t(t), Tokens(Tokens), Debug(Debug) {};
};

CProgram Parse(const TTranslationUnitPtr& t, const TTokenContainer& Tokens, bool Debug)
{
    CParser p(t, Tokens, Debug);
    return p.Parse();
}

