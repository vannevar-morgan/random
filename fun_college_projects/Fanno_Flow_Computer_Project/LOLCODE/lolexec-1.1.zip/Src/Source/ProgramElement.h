// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
//

#pragma once

#include "Common.h"
#include "Compiler.h"

// Forward declarations
class CTranslationUnit;
class CBlock;

class CStatement
{
public:
    const CTranslationUnit& TranslationUnit;
    size_t Index;

    CStatement(size_t Index, const CTranslationUnit& TranslationUnit)
        : TranslationUnit(TranslationUnit), Index(Index) {}

    virtual void Emit(CEmitContext& ec) const = 0;
    
    // This is a no-op by default unless it's overridden by a derived class. This is because it doesn't really make
    // sense to be resolving variables unless you're a block (or a construct containing blocks) or a declare var
    // commmand (or a construct containing declare var commands).
    // 
    // If a derived class overrides this, it should scan itself for any variable declarations and add
    // them to the var map. If there are any blocks (or constructs that contain blocks), they are recursively
    // added to the map as well.
    virtual void ResolveVars(TBlockVarMap& VarMap, const boost::shared_ptr<const CBlock>& Parent,
        size_t& CurrentIndex) const;
};