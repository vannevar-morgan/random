// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Block.h"
#include "Errors.h"
#include "Compiler.h"

void CBlock::Emit(CEmitContext& ec) const
{
    InstrStartIndex = ec.GetInstructionCount();

    if(Parent == NULL)
    {
        // This is a top-level block. Initialise implicit "IT" variable
        ec.AddInstruction(boost::intrusive_ptr<SLoadUntypedInstruction>(new SLoadUntypedInstruction()));
        ec.AddInstruction(boost::intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(ITVarIndex)));
    }

    foreach(const boost::intrusive_ptr<CStatement>& s, Statements)
    {
        s->Emit(ec);
    }
    InstrEndIndex = ec.GetInstructionCount();
}
void CBlock::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    size_t OriginalIndex = CurrentIndex;

    boost::intrusive_ptr<const CBlock> This = boost::intrusive_ptr<const CBlock>(this);

    // Ensure that we haven't already been added to the map
    assert(VarMap.find(This) == VarMap.end());

    // Add to map
    TBlockVarMap::iterator it = VarMap.insert(std::make_pair(This, TVarIndexMap())).first;

    // We need to inherit all the variables in the scope of our parent
    if(Parent != NULL) // Parent can be NULL if this is a top-level block
    {
        // Ensure that our parent has already been added
        assert(VarMap.find(Parent) != VarMap.end());

        // Copy over all the parent's vars into our map
        const TVarIndexMap& ParentVars = VarMap.find(Parent)->second;
        it->second.insert(ParentVars.begin(), ParentVars.end());
    }
    else
    {
        // This is a top-level block - which means that we need to add the implicit "IT" variable
        assert(it->second.find("IT") == it->second.end());
        it->second["IT"] = ITVarIndex;
    }

    foreach(const boost::intrusive_ptr<CStatement>& s, Statements)
    {
        s->ResolveVars(VarMap, CurrentIndex);
    }

    // Let vars go out of scope
    CurrentIndex = OriginalIndex;
}