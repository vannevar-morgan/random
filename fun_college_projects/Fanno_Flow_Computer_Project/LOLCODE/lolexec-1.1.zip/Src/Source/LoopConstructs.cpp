// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "LoopConstructs.h"
#include "Errors.h"
#include "Compiler.h"
#include "Expression.h"

void CSimpleLoop::Emit(CEmitContext& ec) const
{
    InstrStartIndex = ec.GetInstructionCount();

    // Emit block
    Block->Emit(ec);

    // Emit instruction to jump back to top of loop
    size_t Diff = InstrStartIndex - ec.GetInstructionCount();
    int Offset = static_cast<int>(Diff);
    ec.AddInstruction(boost::intrusive_ptr<SJumpInstruction>(new SJumpInstruction(Offset)));

    InstrEndIndex = ec.GetInstructionCount();
}

void CSimpleLoop::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    // Resolve normally
    CBlock::ResolveVars(VarMap, CurrentIndex);

    // Resolve block
    Block->ResolveVars(VarMap, CurrentIndex);
}

void CIterationLoop::ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const
{
    size_t OriginalIndex = CurrentIndex;

    boost::intrusive_ptr<const CBlock> This = boost::intrusive_ptr<const CBlock>(this);

    // Ensure that we haven't already been added to the map
    assert(VarMap.find(This) == VarMap.end());

    assert(Parent != NULL); // A loop can't be a top level block
    assert(Statements.empty()); // A loop block itself shouldn't contain any statements - only a block

    // Add to map
    TBlockVarMap::iterator it = VarMap.insert(std::make_pair(This, TVarIndexMap())).first;

    // We need to inherit all the variables in the scope of our parent
    // Ensure that our parent has already been added
    assert(VarMap.find(Parent) != VarMap.end());

    // Copy over all the parent's vars into our map
    const TVarIndexMap& ParentVars = VarMap.find(Parent)->second;
    it->second.insert(ParentVars.begin(), ParentVars.end());

    // Add VarName
    assert(VarMap.find(This) != VarMap.end());
    VarMap[This][VarName] = CurrentIndex;
    ++CurrentIndex;

    // Resolve block
    Block->ResolveVars(VarMap, CurrentIndex);

    // Let vars go out of scope
    CurrentIndex = OriginalIndex;
}

void CIterationLoop::EmitInitialise(CEmitContext& ec) const
{
    using boost::intrusive_ptr;

    // Get local loop counter variable
    boost::intrusive_ptr<const CBlock> This = boost::intrusive_ptr<const CBlock>(this);
    size_t VarIndex = ec.GetVarIndex(VarName, This, Index, TranslationUnit);

    // Assign initial value of 0 to loop counter
    ec.AddInstruction(intrusive_ptr<SLoadIntegerInstruction>(new SLoadIntegerInstruction(0)));
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(VarIndex)));
}

void CIterationLoop::EmitBody(CEmitContext& ec) const
{
    using boost::intrusive_ptr;

    // Get local loop counter variable
    boost::intrusive_ptr<const CBlock> This = boost::intrusive_ptr<const CBlock>(this);
    size_t VarIndex = ec.GetVarIndex(VarName, This, Index, TranslationUnit);

    // Emit block
    Block->Emit(ec);

    // Emit code to execute conditional expression
    if(Operation == "UPPIN")
    {
        // Increment
        ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(VarIndex)));
        ec.AddInstruction(intrusive_ptr<SIncrementInstruction>(new SIncrementInstruction()));
    }
    else if(Operation == "NERFIN")
    {
        // Decrement
        ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(VarIndex)));
        ec.AddInstruction(intrusive_ptr<SDecrementInstruction>(new SDecrementInstruction()));
    }
    else
    {
        // Unary function

        // There's only 1 argument: the loop counter
        // Nothing needs to be done with the arguments since the loop var will already be on top of the stack.

        // TODO: Perform checking for functions arguments! Currently this allows mismatched parameter counts!

        // Clear a space for the return value
        ec.AddInstruction(intrusive_ptr<SLoadUntypedInstruction>(new SLoadUntypedInstruction()));
        ec.AddInstruction(intrusive_ptr<SLoadVarInstruction>(new SLoadVarInstruction(VarIndex)));

        // Call function
        intrusive_ptr<SCallInstruction> CallInstr(new SCallInstruction(0,0));
        ec.RegisterCallContext(ec.GetInstructionCount(), CallInstr, Operation, Index, TranslationUnit);
        ec.AddInstruction(CallInstr);

        // Our responsibility to pop the function argument after we're done
        ec.AddInstruction(intrusive_ptr<SPopInstruction>(new SPopInstruction()));
    }

    // Copy result back into loop counter variable
    ec.AddInstruction(intrusive_ptr<SStoreVarInstruction>(new SStoreVarInstruction(VarIndex)));
}

void CIterationLoop::Emit(CEmitContext& ec) const
{
    InstrStartIndex = ec.GetInstructionCount();

    EmitInitialise(ec);

    size_t JumpTopIndex = ec.GetInstructionCount();
    EmitBody(ec);

    // Emit instruction to jump back to top of loop
    size_t Diff = JumpTopIndex - ec.GetInstructionCount();
    int Offset = static_cast<int>(Diff);
    ec.AddInstruction(boost::intrusive_ptr<SJumpInstruction>(new SJumpInstruction(Offset)));

    InstrEndIndex = ec.GetInstructionCount();
}

template<typename TJumpInstr>
void IConditionalLoop::EmitCommon(CEmitContext& ec) const
{
    using boost::intrusive_ptr;

    InstrStartIndex = ec.GetInstructionCount();

    EmitInitialise(ec);

    size_t JumpTopIndex = ec.GetInstructionCount();

    // Emit loop conditional
    Condition->Emit(ec);

    // Cast the conditional result to a bool
    ec.AddInstruction(intrusive_ptr<SCastInstruction>(new SCastInstruction(RuntimeVarType_Boolean)));

    // Jump to end of block if conditional evaluated to true/false (depending on what TJumpInstr does)
    intrusive_ptr<TJumpInstr> JumpInstr(new TJumpInstr(0));
    ec.RegisterJumpContext(ec.GetInstructionCount(), JumpInstr, intrusive_ptr<const IConditionalLoop>(this));
    ec.AddInstruction(JumpInstr);

    EmitBody(ec);

    // Emit instruction to jump back to top of loop
    size_t Diff = JumpTopIndex - ec.GetInstructionCount();
    int Offset = static_cast<int>(Diff);
    ec.AddInstruction(intrusive_ptr<SJumpInstruction>(new SJumpInstruction(Offset)));

    InstrEndIndex = ec.GetInstructionCount();
}

void CWhileLoop::Emit(CEmitContext& ec) const
{
    EmitCommon<SJumpNotEqualInstruction>(ec);
}

void CForLoop::Emit(CEmitContext& ec) const
{
    EmitCommon<SJumpEqualInstruction>(ec);
}

