// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Utils.h"
#include "Errors.h"

#include <boost/lexical_cast.hpp>

using boost::intrusive_ptr;

void FindAndReplaceAll(const CString& ToFind, const CString& Replacement, CString& Source)
{
    CString::size_type i = 0;
    while(true)
    {
        i = Source.find(ToFind, i);
        if(i == CString::npos)
            break;
        Source.replace(i, ToFind.length(), Replacement);
        ++i;
    }
}


ERValueType DetermineRValueType(const SValue& v)
{
    if(v.IsStringLiteral)
        return RValueType_StringLiteral;
    if(v.Data == "WIN" || v.Data == "FAIL")
        return RValueType_BooleanLiteral;
    if(v.Data.find('.') != CString::npos && v.Data.find_first_not_of(".-1234567890") == CString::npos)
        return RValueType_FloatLiteral;
    if(v.Data.find_first_not_of("-1234567890") == CString::npos)
        return RValueType_IntegerLiteral;
    return RValueType_Variable;
}

int ParseInteger(const SValue& v, size_t Index, const TTranslationUnitPtr& t)
{
    try
    {
        return boost::lexical_cast<int>(v.Data);
    }
    catch (const boost::bad_lexical_cast&)
    {
        throw CSyntaxException(CompileError_InvalidIntegerLiteral, Index, t);
    }
}

double ParseFloat(const SValue& v, size_t Index, const TTranslationUnitPtr& t)
{
    try
    {
        return boost::lexical_cast<double>(v.Data);
    }
    catch (const boost::bad_lexical_cast&)
    {
        throw CSyntaxException(CompileError_InvalidFloatLiteral, Index, t);
    }
}

bool ParseBool(const SValue& v, size_t Index, const TTranslationUnitPtr& t)
{
    if(v.Data == "WIN")
        return true;
    else if(v.Data == "FAIL")
        return false;
    else
        throw CSyntaxException(CompileError_InvalidBooleanLiteral, Index, t);
}

CString ParseString(const SValue& v, size_t Index, const TTranslationUnitPtr& t)
{
    assert(DetermineRValueType(v) == RValueType_StringLiteral);

    CString Arg = v.Data;
    for(size_t i = 0 ; i < Arg.size() ; ++i)
    {
        if(Arg[i] == ':')
        {
            if(i + 1 == Arg.size())
                break;
            switch(Arg[i+1])
            {
            case ')': // newline
                Arg.replace(i, 2, "\n");
                break;
            case '>': // tab
                Arg.replace(i, 2, "\t");
                break;
            case 'o': // beep
                Arg.replace(i, 2, "\b");
                break;
            case '\"': // double quote
                Arg.replace(i, 2, "\"");
                break;
            case ':': // colon
                Arg.replace(i, 2, ":");
                break;
            case '(':
                {
                    size_t i2 = Arg.find(')', i);
                    if(i2 == CString::npos) {
                        Logger.LogCompilerWarning(CompileWarning_InvalidEscapeSequence, Index + i, t);
                        Arg.erase(i, 1);
                        break;
                    }
                    Arg.erase(i, i2 - i + 1);
                    Logger.LogCompilerWarning(CompileWarning_UnicodeCodePointConv, Index + i, t);
                } break;
            case '[':
                {
                    size_t i2 = Arg.find(']', i);
                    if(i2 == CString::npos) {
                        Logger.LogCompilerWarning(CompileWarning_InvalidEscapeSequence, Index + i, t);
                        Arg.erase(i, 1);
                        break;
                    }
                    Arg.erase(i, i2 - i + 1);
                    Logger.LogCompilerWarning(CompileWarning_UnicodeNormativeConv, Index + i, t);
                } break;
            case '{': // Variable interpolation
                // This is handled elsewhere, this function doesn't have enough information to resolve this
                break;
            default:
                Arg.erase(i, 1);
                Logger.LogCompilerWarning(CompileWarning_InvalidEscapeSequence, Index + i, t);
            }
        }
    }
    /*FindAndReplaceAll(":)", "\n", Arg); // newline
    FindAndReplaceAll(":>", "\t", Arg); // tab
    FindAndReplaceAll(":o", "\b", Arg); // beep
    FindAndReplaceAll(":\"", "\"", Arg); // double quote
    FindAndReplaceAll("::", ":", Arg); // colon
    while(true)
    {
        size_t i1 = Arg.find(":(");
        if(i1 == CString::npos)
            break;
        size_t i2 = Arg.find(')', i1);
        if(i2 == CString::npos)
            throw CSyntaxException(CompileError_InvalidEscapeSequence, Index, t);
        Arg.erase(i1, i2 - i1 + 1);
        Logger.LogCompilerWarning("Conversion from hex number into Unicode code point not supported. Ignoring escape sequence.", Index, t);
    }
    while(true)
    {
        size_t i1 = Arg.find(":[");
        if(i1 == CString::npos)
            break;
        size_t i2 = Arg.find(']', i1);
        if(i2 == CString::npos)
            throw CSyntaxException(CompileError_InvalidEscapeSequence, Index, t);
        Arg.erase(i1, i2 - i1 + 1);
        Logger.LogCompilerWarning("Resolution to Unicode normative names is not supported. Ignoring escape sequence.", Index, t);
    }*/
    return Arg;
}

void ValidateVariableName(const CString& Name, size_t Index, const TTranslationUnitPtr& t)
{
    if(Name.empty())
        return;
    if(isdigit(Name[0]))
        throw CSyntaxException(CompileError_InvalidVarName, Index, t);
    foreach(char c, Name)
    {
        if(!isalnum(c) && c != '_')
            throw CSyntaxException(CompileError_InvalidVarName, Index, t);
    }

    // Check to ensure that it does not conflict with reserved language keywords
    if(Name != "IT") // Even though IT is a reserved keyword, it is a valid variable name
    {
        for(int i = 0 ; i < KeywordCount ; ++i)
        {
            if(Name == Keywords[i])
                throw CSyntaxException(CompileError_VarNameKeywordConflict, Index, t);
        }
    }
}

ERuntimeVarType GetRuntimeVarType(const CString& TypeName, size_t Index, const TTranslationUnitPtr& TranslationUnit)
{
    if(TypeName == "NOOB")
        return RuntimeVarType_Untyped;
    else if(TypeName == "NUMBR")
        return RuntimeVarType_Integer;
    else if(TypeName == "NUMBAR")
        return RuntimeVarType_Float;
    else if(TypeName == "TROOF")
        return RuntimeVarType_Boolean;
    else if(TypeName == "YARN")
        return RuntimeVarType_String;
    else
        throw CSyntaxException(CompileError_InvalidType, Index, TranslationUnit);
}