// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#include "Errors.h"
#include <boost/lexical_cast.hpp>

using boost::lexical_cast;

CString FormatCompileError(const char* Type, ECompileError Code, size_t Index,
                           const TTranslationUnitPtr& TranslationUnit, const SLocation& Location)
{
    return TranslationUnit->GetPath() + " (" + lexical_cast<CString>(Location.Row) + ',' +
        lexical_cast<CString>(Location.Column) + ") : " + Type + " error C" + lexical_cast<CString>(Code) + ": " +
        GetCompileErrorDesc(Code);
}

//////////////////////////////////////////////////////////////////////////
// Internal errors
CException::CException(const char* Message) : Message(Message)
{}

const char* CException::what() const throw()
{
    return Message;
}

//////////////////////////////////////////////////////////////////////////
// User input errors
CArgumentException::CArgumentException(const char* Message) : CException(Message)
{}

//////////////////////////////////////////////////////////////////////////
// Runtime execution errors

const char* GetRuntimeErrorDesc(ERuntimeError Code)
{
    switch(Code)
    {
    case RuntimeError_UntypedMathOp:
        return "Cannot perform mathematical operation on an untyped variable.";
    case RuntimeError_InvalidMathOpType:
        return "Cannot perform mathematical operation on incompatible variable types.";
    case RuntimeError_BadCast:
        return "Cannot cast to new type.";
    default:
        return "No error description.";
    }
}

CRuntimeException::CRuntimeException(ERuntimeError Code) : Code(Code)
{}
CRuntimeException::CRuntimeException(const char* Message, ERuntimeError Code) : CException(Message), Code(Code)
{}

ERuntimeError CRuntimeException::GetErrorCode() const
{
    return Code;
}
const char* CRuntimeException::what() const throw()
{
    FormattedMessage = "Runtime error #" + lexical_cast<CString>(Code) + ": " + GetRuntimeErrorDesc(Code);
    return FormattedMessage.c_str();
}

CInvalidInstructionException::CInvalidInstructionException() : CRuntimeException(RuntimeError_InvalidInstruction)
{}
CInvalidInstructionException::CInvalidInstructionException(const char* Message)
    : CRuntimeException(Message, RuntimeError_InvalidInstruction)
{}

//////////////////////////////////////////////////////////////////////////
// Compile errors

CCompileException::CCompileException(ECompileError Code,
                                     size_t Index,
                                     const TTranslationUnitPtr& TranslationUnit)
    : Code(Code), Index(Index), TranslationUnit(TranslationUnit), Location(TranslationUnit->GetLocationFromIndex(Index))
{}
CCompileException::CCompileException(const char* Message,
                                     ECompileError Code,
                                     size_t Index,
                                     const TTranslationUnitPtr& TranslationUnit)
    : CException(Message), Code(Code), Index(Index), TranslationUnit(TranslationUnit),
    Location(TranslationUnit->GetLocationFromIndex(Index))
{}

ECompileError CCompileException::GetErrorCode() const
{
    return Code;
}
const SLocation& CCompileException::GetLocation() const
{
    return Location;
}
size_t CCompileException::GetIndex() const
{
    return Index;
}
const TTranslationUnitPtr& CCompileException::GetTranslationUnit() const
{
    return TranslationUnit;
}
const char* CCompileException::what() const throw()
{
    FormattedMessage = FormatCompileError("compile", Code, Index, TranslationUnit, Location);
    return FormattedMessage.c_str();
}


const char* CVariableNotFoundException::what() const throw()
{
    FormattedMessage = FormatCompileError("compile", Code, Index, TranslationUnit, Location) + '\'' + VarName + '\'';
    return FormattedMessage.c_str();
}


const char* CSyntaxException::what() const throw()
{
    FormattedMessage = FormatCompileError("syntax", Code, Index, TranslationUnit, Location);
    return FormattedMessage.c_str();
}


const char* CUnexpectedSyntaxException::what() const throw()
{
    FormattedMessage = FormatCompileError("syntax", Code, Index, TranslationUnit, Location) + '\'' + Unexpected + '\'';

    if(!Expected.empty())
    {
        FormattedMessage += " Expected: " + Expected;
    }
    return FormattedMessage.c_str();
}


const char* GetCompileErrorDesc(ECompileError Code)
{
    switch(Code)
    {
    case CompileError_MissingCommentBlockEnd:
        return "Unexpected end of file found in comment block. Did you forget a \'TLDR\'?";
    case CompileError_NestedCommentBlock:
        return "Nested comment block found. Comment blocks cannot be nested.";
    case CompileError_MissingStringLiteralEnd:
        return "Unexpected end of file reached inside string literal. Expected ending \'\"\'.";
    case CompileError_InvalidCommandJoinerMidLine:
        return "Invalid line continuation. Line continuations may only occur at the end of a line.";
    case CompileError_InvalidCommandJoinerEmptyLine:
        return "Invalid line continuation. A line continuation cannot be followed by an empty line.";

    case CompileError_MissingLoopEnd:
        return "Unexpected end of file found in loop.";
    case CompileError_UnknownLoopConstruct:
        return "Unknown loop type. Valid tokens are \'TIL\' and \'WILE\'";
    case CompileError_MissingLoopLabel:
        return "Missing loop label.";

    case CompileError_MissingIfBlockEnd:
        return "Unexpected end of file reached inside if statement block.";

    case CompileError_MissingCaseBlockEnd:
        return "Unexpected end of file reached inside switch statement.";
    case CompileError_MissingCaseLabel:
        return "Missing case label. Expected a literal here.";
    case CompileError_CaseLabelInterpolation:
        return "Variable interpolation is not allowed in case labels, only literals.";
    case CompileError_CaseLabelIsVar:
        return "Case label is a variable. Only literals are allowed as case labels.";
    case CompileError_DuplicateCaseLabel:
        return "Case label already in use.";

    case CompileError_MissingFunctionEnd:
        return "Unexpected end of file reached inside function body.";
    case CompileError_MultipleFunctionDefinition:
        return "Multiple function definition. This function is already defined.";
    case CompileError_NestedFunction:
        return "Cannot nest function definitions. Function definitions must be placed at global scope.";

    case CompileError_InvalidVariableDeclaration:
        return "Invalid variable declaration.";
    case CompileError_VariableNotFound:
        return "Variable not found in scope: ";
    case CompileError_VarNameInUse:
        return "Variable name is already in use.";
    case CompileError_InvalidVarName:
        return "Invalid variable name. Variable names can only contain alphanumeric characters (A-Z, a-z, 0-9) or underscores (_).";
    case CompileError_VarNameKeywordConflict:
        return "Variable name conflicts with a reserved language keyword.";

    case CompileError_UnexpectedSyntax:
        return "Unexpected: ";
    case CompileError_MissingArg:
        return "Argument missing.";
    case CompileError_MissingExpression:
        return "Expression missing.";
    case CompileError_NotEnoughArgs:
        return "Number of arguments supplied does not meet minimum number required.";
    case CompileError_NotImplemented:
        return "Not implemented: ";
    case CompileError_NoEntryPoint:
        return "Program has no entry point.";
    case CompileError_InvalidBreak:
        return "Nothing to break out of. GTFO is only valid within an enclosing loop, function, or switch statement.";
    case CompileError_InvalidIntegerLiteral:
        return "Invalid integer literal.";
    case CompileError_InvalidFloatLiteral:
        return "Invalid float literal.";
    case CompileError_InvalidBooleanLiteral:
        return "Invalid boolean literal. Valid: WIN (true), FAIL (false).";
    case CompileError_InvalidStringLiteral:
        return "Invalid string literal";
    case CompileError_InvalidType:
        return "Unrecognised type. Valid types are: NOOB (untyped), NUMBR (integer), NUMBAR (float), TROOF (boolean), YARN (string).";
    default:
        return "No error description.";
    }
}
const char* GetCompileWarningDesc(ECompileWarning Code)
{
    switch(Code)
    {
    case CompileWarning_InvalidEscapeSequence:
        return "Invalid escape sequence. Ignoring.";
    case CompileWarning_UnicodeCodePointConv:
        return "Conversion from hex number into Unicode code point not supported. Ignoring escape sequence.";
    case CompileWarning_UnicodeNormativeConv:
        return "Resolution to Unicode normative names is not supported. Ignoring escape sequence.";
    default:
        return "No error description.";
    }
}