// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "Block.h"

// Loops act sort of different with regards to scoping and blocking rules. A loop itself "is-a" block, but only so that
// it can contain another block as its child and so that loop counters (if any) remain local to the loop. The actual
// loop body is contained in the Block member variable. The loop itself, even though it's a block, shouldn't contain
// any statements.
class CSimpleLoop : public CBlock
{
public:
    CString Label;
    boost::intrusive_ptr<CBlock> Block;

    CSimpleLoop(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CBlock(Index, TranslationUnit, Parent) {}

    virtual void Emit(CEmitContext& ec) const;
    virtual void ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const;
};

class CIterationLoop : public CSimpleLoop
{
protected:
    // Emits instructions required to initialise loop counter.
    void EmitInitialise(CEmitContext& ec) const;

    void EmitBody(CEmitContext& ec) const;

public:
    CString VarName;
    CString Operation;

    CIterationLoop(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CSimpleLoop(Index, TranslationUnit, Parent) {}

    virtual void Emit(CEmitContext& ec) const;
    void ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const;
};

class IConditionalLoop : public CIterationLoop
{
protected:
    template<typename TJumpInstr>
    void EmitCommon(CEmitContext& ec) const;

public:
    boost::intrusive_ptr<CExpression> Condition;

    IConditionalLoop(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CIterationLoop(Index, TranslationUnit, Parent) {}

    virtual void Emit(CEmitContext& ec) const = 0;
};

class CWhileLoop : public IConditionalLoop
{
public:
    CWhileLoop(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : IConditionalLoop(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
class CForLoop : public IConditionalLoop
{
public:
    CForLoop(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : IConditionalLoop(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};
