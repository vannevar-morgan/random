// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
//

#include "ProgramElement.h"
#include "Errors.h"
#include "Compiler.h"

void CStatement::ResolveVars(TBlockVarMap& VarMap,
                                  const boost::shared_ptr<const CBlock>& Parent,
                                  size_t& CurrentIndex) const
{
    // Nothing (by default)
}