// LOLCODE Interpreter
// 
// (c) Adrian Tsai 2008
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
// 

#pragma once

#include "Common.h"
#include "Compiler.h"
#include "Expression.h"
#include "RefCounted.h"

// Forward declarations
class CBlock;

class CStatement : public IEmittable, public IRefCounted
{
public:
    boost::intrusive_ptr<const CBlock> Parent;
    const TTranslationUnitPtr& TranslationUnit;
    size_t Index;

    CStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : TranslationUnit(TranslationUnit), Index(Index), Parent(Parent) {}

    // This is a no-op by default unless it's overridden by a derived class. This is because it doesn't really make
    // sense to be resolving variables unless you're a block (or a construct containing blocks) or a declare var
    // commmand (or a construct containing declare var commands).
    // 
    // If a derived class overrides this, it should scan itself for any variable declarations and add
    // them to the var map. If there are any blocks (or constructs that contain blocks), they are recursively
    // added to the map as well.
    virtual void ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const;
};


class CVisibleStatement : public CStatement
{
public:
    CArray< boost::intrusive_ptr<CExpression> > Arguments;

    CVisibleStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// ie. GIMMEH
// This is ill-defined in the spec
class CConsoleInputExpression : public CStatement
{
public:
    CString VarName;

    CConsoleInputExpression(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

class CImportStatement : public CStatement
{
public:
    CString Argument;

    CImportStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

class CDeclareVarStatement : public CStatement
{
public:
    CString VarName;
    boost::intrusive_ptr<CExpression> InitialValue;

    CDeclareVarStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
    void ResolveVars(TBlockVarMap& VarMap, size_t& CurrentIndex) const;
};

class CAssignVarStatement : public CStatement
{
public:
    CString VarName;
    boost::intrusive_ptr<CExpression> Arg;

    CAssignVarStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// Breaks out of a loop
class CBreakStatement : public CStatement
{
public:
    CBreakStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};

// Returns out of a function
class CReturnStatement : public CStatement
{
public:
    boost::intrusive_ptr<CExpression> Arg;

    CReturnStatement(size_t Index, const TTranslationUnitPtr& TranslationUnit, const boost::intrusive_ptr<const CBlock>& Parent)
        : CStatement(Index, TranslationUnit, Parent) {}

    void Emit(CEmitContext& ec) const;
};